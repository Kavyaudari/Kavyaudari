#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
char postfix[30];
float s[20];
int top=-1;
void push(float ch)
{
top++;
s[top]=ch;
}
float pop()
{
float x;
x=s[top];
top--;
return x;
}
void main()
{
float op1,op2;
int i;
printf("enter the postfix expression");
scanf("%s",postfix);
for(i=0;postfix[i]!='\0';i++)
{
if(isdigit(postfix[i]))
{
push(postfix[i]-48);
}
else
{
op2=pop();
op1=pop();
switch(postfix[i])
{
case '+':push(op1+op2);
break;
case '-':push(op1-op2);
break;
case '*':push(op1*op2);
break;
case '/':if(op2==0)
printf("equal to zero");
else
push((float)(op1/op2));
break;
default:printf("wrong");
}
}
}
printf("result=%f\n",s[top]);
}


