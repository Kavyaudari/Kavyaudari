import shape.tri;
import shape.sq;
import shape.circ;
public class ex8_2
{
public static void main(String args[])
{
tri t1=new tri();
sq s1=new sq();
circ c1=new circ();
t1.area(5,8);
t1.perimeter(6,9,7);
s1.area(6);
s1.perimeter(5);
c1.area(5);
c1.perimeter(7);
}
}

