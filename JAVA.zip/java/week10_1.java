class Myexception extends Exception
{
public Myexception(String message)
{
super(message);
}
}
class week10_1
{
public static void main(String args[])
{
try
{
throw new Myexception("exception occurs ");
}
catch(Exception e)
{
System.out.println(e);
}
finally
{
System.out.println("this is final block ");
}
}
}

