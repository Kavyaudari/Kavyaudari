/*class my extends Exception
{
private String str;
my(String str)
{
this.str=str;
}
void print()
{
System.out.println(str);
}
}
class ex9_7
{
public static void main(String args[])
{
try
{
throw new my("exception");
}
catch(my e)
{
e.print();
}
}
}*/
/*
class ex9_7
{
public static void main(String args[])
{
try{
String str="hello";
int i=Integer.parseInt(str);
}
catch(Exception e)
{
System.out.println(e);
}
}
}
*/
/*
class ex9_7
{
public static void main(String args[])
{
try
{
Class.forName("hello");
}
catch(Exception e)
{
System.out.println(e);
}
}
}
*/
/*
class ex9_7
{
public static void main(String args[])
{
try 
{
one();
}
catch(Exception e)
{
System.out.println("main" +e);
}
}
static void one() throws Exception
{
try
{
two();
}
catch(Exception e)
{
System.out.println("one " );
throw e;
}
}
static void two() throws Exception
{
throw new Exception("two ");
}
}

*/

