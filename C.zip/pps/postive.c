//greatest
#include<stdio.h>
int main()
{
int a;
printf("enter a value");
scanf("%d",&a);
if(a>=0)
{
printf("a is positive=%d",a);
}
else
if(a<0)
{
printf("a is negative=%d",a);
}
/*else
{
printf("a is equal to zero=%d",a);
}*/
return 0;
}

