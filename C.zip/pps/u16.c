//min max of array
#include<stdio.h>
int main()
{
int n,i,min,max;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
min=a[0];
max=a[0];
for(i=0;i<n;i++)
{
if(min>a[i])
{
min=a[i];
}
if(max<a[i])
{
max=a[i];
}
}
printf("%d",min);
printf("%d",max);
}
