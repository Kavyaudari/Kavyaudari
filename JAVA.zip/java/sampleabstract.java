//abstraction
import java.util.*;
/*
abstract class animal//hiding the impelementation details 
{
abstract void sound();
void print()//normal form
{
System.out.println("animals lover");
}
animal()//constructor
{
System.out.println("animals");
}
}
class dog extends  animal//child
{
void sound()
{
System.out.println("dogs barks");
}
dog()
{
super();//used to print constructor in abstract
}
}
class lion extends animal
{
lion()
{
super();//used to print constructor in abstract
}
void sound()
{
System.out.println("lion roars");
}
}
class sampleabstract{
public static void main(String args[])
{
dog d=new dog();
lion l=new lion();
d.sound();
l.sound();
d.print();//prints animal lover
}
}*/

abstract class shape
{
abstract double area();//hiding data double is datatype
abstract double perimeter();
void print()
{
System.out.println("kavya udari");
}
}
class rect extends shape
{
float l,b;
//calling constructor to assign values to l and b
rect()
{
Scanner in=new Scanner(System.in);
System.out.println("enter the values of l and b");
l=in.nextFloat();
b=in.nextFloat();
}
double area()
{
return(l*b);
}
double perimeter()
{
return(2*(l+b));
}
}
class circle extends shape
{
float r;
//calling constructor to assign values to l and b
circle()
{
Scanner in=new Scanner(System.in);
System.out.println("enter the values of r");
r=in.nextFloat();
}
double area()
{
return(3.14*r*r);
}
double perimeter()
{
return(2*3.14*r);
}
}
class sq extends shape
{
float s;
//calling constructor to assign values to l and b
sq()
{
Scanner in=new Scanner(System.in);
System.out.println("enter the value of s");
s=in.nextFloat();
}
double area()
{
return(s*s);
}
double perimeter()
{
return(4*s);
}
}
class sampleabstract
{
public static void main(String args[])
{
rect r=new rect();
circle c=new circle();
sq s=new sq();
//rectangle
System.out.println("area of rect"+r.area());
System.out.println("perimeter of rect"+r.perimeter());
//circle
System.out.println("area of circle"+c.area());
System.out.println("perimeter of circle"+c.perimeter());
//square
System.out.println("area of sq"+s.area());
System.out.println("perimeter of sq"+s.perimeter());
r.print();
}
}

