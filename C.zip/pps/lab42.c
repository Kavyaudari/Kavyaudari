//palindrome
#include<stdio.h>
int main()
{
int n,rev=0,t,r;
printf("enter the n value");
scanf("%d",&n);
t=n;
while(n>0)
{
r=n%10;
rev=(rev*10)+r;
n=n/10;
}
if(t=rev)
{
printf("it is a palindrome");
}
}

