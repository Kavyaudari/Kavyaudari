//copy array
#include<stdio.h>
int main()
{
int n,i,b[10];
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++);
{
printf("a[%d]=%d\n",i,n);
}
for(i=0;i<n;i++)
{
b[i]=a[i];
}
for(i=0;i<n;i++)
{
printf("b[%d]=%d\n",i,a[i]);
}
}
