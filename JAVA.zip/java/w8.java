import family.name;
public class w8
{
public static void main(String args[])
{
name n=new name();
n.display();
}
}

