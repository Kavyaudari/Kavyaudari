#include<stdio.h>
int main()
{
int a,b,sum,sub,mult,div,mod;
printf("enter a,b values\n");
scanf("%d%d\n",&a,&b);
 sum=a+b;
 printf("addition of %d %d=%d\n",a,b,sum);
 }
