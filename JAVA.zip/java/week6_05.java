import java.util.*;
class vehicle
{
int vno;
int ino;
String color;
double fuel;
void getInfo(int vno,int ino,String color)
{
this.vno=vno;
this.ino=ino;
this.color=color;
}
void getConsumption(double fuel)
{
this.fuel=fuel;
}
void displayConsumption()
{
System.out.println("the fuel of the vehcle " +fuel);
}
void display()
{
System.out.println("vehicle no="+vno);
System.out.println("insurance no="+ino);
System.out.println("color= "+color);
}
}
class two extends vehicle
{
double mt;
double avg;
void info(double mt,double avg)
{
this.mt=mt;
this.avg=avg;
}
double maintanance()
{
return mt;
}
double average()
{
return avg;
}
}
class four extends vehicle
{
double mt;
double avg;
void info(double mt,double avg)
{
this.mt=mt;
this.avg=avg;
}
double maintanance()
{
return mt;
}
double average()
{
return avg;
}
}
class week6_05
{
public static void main(String args[])
{
two t=new two();
Scanner in=new Scanner(System.in);
System.out.println("enter the details of two wheeler");
int vno=in.nextInt();
int ino=in.nextInt();
String color=in.next();
double fuel=in.nextDouble();
t.getInfo(vno,ino,color);
t.getConsumption(fuel);
t.displayConsumption();
t.display();
System.out.println("enter the maintanenace and avg values of two wheeler ");
double mt=in.nextDouble();
double avg=in.nextDouble();
t.info(mt,avg);
System.out.println(t.maintanance());
System.out.println(t.average());
}
}

