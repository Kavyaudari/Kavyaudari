//a building has 10 floors height of 3 meters
//s=distance
//a=gravitation
//t=time
#include<stdio.h>
#include<math.h>
int main()
{
int s;
float a,t;
s=30;//10*3
a=9.8;
t=sqrt(2*s/a);
printf("time is =%f",t);
return 0;
}

