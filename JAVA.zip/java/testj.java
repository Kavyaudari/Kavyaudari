//polymoprphism
import java.util.*;
class adder
{
int add(int a,int b)
{
int t=a+b;
return(t);
}
float add(float a,float b)
{
float t=a+b;
return(t);
}
float add(int a,int b,float c)
{
float t=a+b+c;
return(t);
}
int add(int a,int b,int c)
{
int  t=a+b+c;
return(t);
}
}
class testj
{
public static void main(String args[])
{
adder a1=new adder();
Scanner in=new Scanner(System.in);
System.out.println("enter the values");
int a=in.nextInt();
int b=in.nextInt();
int c=in.nextInt();
float x=in.nextFloat();
float y=in.nextFloat();
float z=in.nextFloat();
System.out.println(a1.add(a,b));
System.out.println(a1.add(x,y));
System.out.println(a1.add(a,b,z));
System.out.println(a1.add(a,b,c));
}
}


