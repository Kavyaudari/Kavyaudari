//increment and decrement
#include<stdio.h>
int main()
{
int y=2;
printf("%d%d%d",++y,y,y--);
return 0;
}
