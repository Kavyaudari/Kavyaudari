import java.util.*;
class circle
{
double r;
circle(double r)
{
this.r=r;
}
void area()
{
System.out.println("area= " +(3.13*r*r));
}
void perimeter()
{
System.out.println("peri= " +(2*3.14*r));
}
}
class ex5_2
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter ");
double rad=in.nextDouble();
circle c1=new circle(rad);
c1.area();
c1.perimeter();
}
}
 
