//character
#include<stdio.h>
int main()
{
char s[10];
char ch;
int i;
printf("enter a character");
scanf("%c",&ch);
printf("enter a string");
scanf("%s",s);
for(i=0;s[i]!='\0';i++)
{
if(ch==s[i])
{
printf("%c is present %d",ch,i);
break;
}
}
if(ch!=s[i])
{
printf("it is not present");
}
}

