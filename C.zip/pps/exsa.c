#include<stdio.h>
#include<stdlib.h>
#define n 5
int s[n];
int top=-1;
void push(int);
void pop();
void display();
void push(int x)
{
if(top>n)
{
printf("overflow");
}
else if(top==-1)
{
top=0;
s[top]=x;
}
else
{
top++;
s[top]=x;
}
}
void pop()
{
int x;
if(top==-1)
printf("underflow");
else
{
x=s[top];
top--;
printf("%d",x);
}
}
void display()
{
if(top==-1)
{
printf("underflow");
}
else
{
int i;
for(i=top;i>=0;i--)
{
printf("%d",s[i]);
}
}
}
void main()
{
int ch,ele;
printf("\n1=push\n2=pop\n3=display");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the ele");
scanf("%d",&ele);
push(ele);
break;
case 2:pop();
break;
case 3:display();
break;
default:printf("wrong");
break;
}
}
}
