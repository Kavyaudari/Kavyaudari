//basic pointer
#include<stdio.h>
int main()
{
int n;
printf("n");
scanf("%d",&n);
int *p=&n;
printf("%d",&p);
}
