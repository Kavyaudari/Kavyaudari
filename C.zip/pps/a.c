//area of circle
#include<stdio.h>
float main()
{
 float r,a,c;
 printf("enter r,a value");
 scanf("%f%f",&r,&a);
 c=a*r*r;
 printf("%f",c);
 return 0;
}

