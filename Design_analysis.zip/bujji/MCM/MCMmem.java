import java.util.*;
import java.math.*;
class mem{
int dp[][];
int a[];
int n;
Scanner in=new Scanner(System.in); 
public mem(int n)
{
this.n=n;
a=new int[n];
dp=new int[n][n];
System.out.println("Enter the array");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
for(int i=0;i<n;i++)
{
for(int j=0;j<n;j++)
{
dp[i][j]=-1;
}
}
}


int mcm(int i,int j)
{
if(dp[i][j]!=-1)
{
return dp[i][j];
}
if(i==j)
{
return dp[i][j]=0;
}
int min=Integer.MAX_VALUE;
for( int k=i;k<j;k++)
{
int val=mcm(i,k)+mcm(k+1,j)+a[i-1]*a[k]*a[j];
if(val<min)
{
min=val;
}
}
return dp[i][j]=min;
}
}
class test{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n");
int n;
n=in.nextInt();
matrix m=new matrix(n);
System.out.println(m.mcm(1,n-1));
}
}


