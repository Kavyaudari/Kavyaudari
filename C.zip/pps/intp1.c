#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<math.h>
char s[30];
char po[39];
int top=-1;
void push(float ch)
{
top++;
s[top]=ch;
}
float pop()
{
float x;
x=s[top];
top--;
}
void main()
{
float op1,op2;
int i;
printf("enter the exp");
scanf("%s",po);
for(i=0;po[i]!='\0';i++)
{
if(isdigit(po[i]))
{
push(po[i]-48);
}
else
{
op2=pop();
op1=pop();
switch(po[i])
{
case '+':push(op1+op2);
break;
case '-':push(op1-op2);
break;
case '*':push(op1*op2);
break;
case '/':if(op2==0)
printf("null");
else
{
push((float)(op1/op2));
}
case '^':push(pow(op1,op2));
break;
default:printf("w");
break;
}
}
}
printf("%d",s[top]);
}
