import java.util.*;
interface fare
{
void getAmount(int k,int f);
}
class bus implements fare
{
public void getAmount(int k,int f)
{
System.out.println("the fare amount for bus is = " +(k*f));
}
}
class train implements fare
{
public void getAmount(int k,int f)
{
System.out.println("the fare amount for train is = " +(k*f));
}
}
class week7_6
{
public static void main(String args[])
{
fare b=new bus();
Scanner in=new Scanner(System.in);
System.out.println("enter the no of kilometers ,fare per kilometer of a bus ");
int k1,f1;
k1=in.nextInt();
f1=in.nextInt();
System.out.println("total amount= " +(k1*f1));
fare t=new train();
System.out.println("enter the no of kilometers ,fare per kilometer of a bus ");
int k2,f2;
k2=in.nextInt();
f2=in.nextInt();
System.out.println("total amount= " +(k2*f2));
}
}



