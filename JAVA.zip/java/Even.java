import java.util.*;
class Even{
public static void main(String args[])
{
System.out.println("enter the number");
Scanner in=new Scanner(System.in);
int x=in.nextInt();
if(x%2==0)
{
System.out.println("even");
}
else
{
System.out.println("odd");
}
}
}

