//using if else statements greater among two
#include<stdio.h>
int main()
{
int a=4,b=5;
if(a>b)
{
printf("a is greater");
}
else
{
printf("b is greater");
}
return 0;
}
