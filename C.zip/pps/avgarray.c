//array
#include<stdio.h>
int main()
{
int n,min,max,i,s=0, avg;
printf("enter the size of an array");
scanf("%d",&n);
int a[n];
printf("enter the elements of array");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
s=s+a[i];
}
min=a[0];
max=a[0];
for(i=0;i<n;i++)
{
if(min>a[i])
{
min=a[i];
}
if(max<a[i])
{
max=a[i];
}
}
avg=(float)s/n;
printf("max=%d",max);
printf("min=%d",min);
printf("avg=%d",avg);
}
