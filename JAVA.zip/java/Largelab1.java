import java.util.*;
class Largelab1
{
public static void main(String args[])
{
int c=0;
int largest=0;int smallest=0;
while(c<5)
{
c++;
System.out.println("enter the number");
Scanner in=new Scanner(System.in);
int num=in.nextInt();
if(num>largest)
{
largest=num;
}
if(num<smallest)
{
smallest=num;
}
}
System.out.println(largest);
System.out.println(smallest);
}
}
