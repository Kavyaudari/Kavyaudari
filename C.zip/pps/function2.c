//without arguments and with return type
#include<stdio.h>
#include<math.h>
int p();
int main()
{ 
int z;
z=p();
printf("%d",z);
}
int p()
{
int a,b,c;
printf("enter a,b values");
scanf("%d%d",&a,&b);
c=pow(a,b);
return(c);
}
