#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*temp,*f=0,*r=0;
void eq()
{
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
new->next=0;
if(f==0&&r==0)
{
f=r=new;
}
else
{
r->next=new;
r=new;
}
}
void dq()
{
temp=f;
if(f==0&&r==0)
{
printf("empty");
}
else if(f==r)
{
printf("%d",f->data);
free(temp);
}
else
{
printf("%d",f->data);
f=f->next;
free(temp);
}
}
void dis()
{
temp=f;
if(f==0&&r==0)
{
printf("empty");
}
else
{
while(temp!=0)
{
printf("%d",temp->data);
temp=temp->next;
}
}
}
void main()
{
int ch;
printf("\n1=eq\n2=dq\n3=dis");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1://printf("enter the ele");
//scanf("%d",&ele);
eq();
break;
case 2:dq();
break;
case 3:dis();
break;
default:printf("wrong");
break;
}
}
}
