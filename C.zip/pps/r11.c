//eve s odd s
#include<stdio.h>
int main()
{
int n,e=0,o=0,i;
printf("n");
scanf("%d",&n);
{
for(i=1;i<=n;i++)
{
if(i%2==0)
{
e=e+i;
}
else
{
o=o+i;
}
}
printf("%d %d" ,e,o);
}
}
