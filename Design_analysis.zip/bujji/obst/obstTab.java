import java.util.*;
import java.math.*;
class tree{
	int n;
	int a[],freq[];
	int dp[][];
	 Scanner sc=new Scanner(System.in);
	public tree(int n){
		this.n=n;
		dp=new int[n+2][n+2];

		a=new int[n+1];
        	freq=new int[n+1];
        	System.out.println("enter key values:");
        	for(int i=1;i<=n;i++)
        	{
           		a[i]=sc.nextInt();
         	}
         	System.out.println("enter freq for corresponding key values:");
         	for(int i=1;i<=n;i++)
        	{
           		freq[i]=sc.nextInt();
         	}
	}
	 int sum(int i,int j)
	 {
	 int s=0;
	 for(int k=i;k<=j;k++)
	 {
		s=s+freq[k];
	}
	return s;
	}

	int obst(int i, int j){
        for(int l=0; l<j; l++){
            for(int row=i; row<=j-l; row++){
                int col = l+row;
                int min = Integer.MAX_VALUE;
                if(row > col){
                    dp[row][col] = 0;
                    continue;
                }
                if(row == col){
                    dp[row][col] = freq[row];
                    continue;
                }
                for(int k=row; k<=col; k++){
                    int val = dp[row][k-1] + dp[k+1][col] + sum(row, col);
                    if(val < min){
                        min = val;
                    }
                }
                dp[row][col] = min;
            }
        }
        return dp[1][n];
    }
 }
class test{
    public static void main(String args[]){
      
        Scanner sc=new Scanner(System.in);
        int n;
        System.out.println("enter array sized:");
        n=sc.nextInt();
        tree b=new tree(n);
        
       System.out.println(b.obst(1,n));
      }
}
