import java.util.*;
class account
{
String account_name;
int account_no;
double amount,withdraw,deposit;
account(String s,double a,int i,double w, double d )
{
account_name=s;
account_no=i;
amount=a;
withdraw=w;
deposit=d;
}
void debit(double w)
{
if(amount>w)
{
amount=(amount-w);
System.out.println("withdrawed "+withdraw);
double m=(amount-withdraw)+deposit;
System.out.println("current balance"+m);
}
else
{
System.out.println("insufficent amount");
System.out.println("amount"+amount);
}
}
void credit(double d)
{
amount=(amount+d);
System.out.println("account name"+account_name);
System.out.println("account no"+account_no);
System.out.println("debited amount"+deposit);
}
}
class week5_3
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the details");
System.out.println("1.accoun name 2.account no 3.amount 4.withdrawed 5.deposit");
String name=in.next();
int i=in.nextInt();
double a=in.nextDouble();
double w=in.nextDouble();
double d=in.nextDouble();
System.out.println("account details are");
account A=new account(name,a,i,w,d);
A.credit(d);
A.debit(w);
}
}

