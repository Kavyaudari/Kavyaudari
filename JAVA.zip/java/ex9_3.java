class ex9_3
{
public static void main(String args[])
{
try
{
one();
}
catch(Exception e)
{
System.out.println("main"+e);
}
}
static void one() throws Exception
{
try
{
two();
}
catch(Exception e)
{
System.out.println("one ");
throw e;
}
}
static void two() throws Exception
{
throw new Exception("two");
}
}

