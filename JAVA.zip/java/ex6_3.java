import java.util.*;
class emp
{
String fname;
String lname;
void getFname(String fname)
{
this.fname=fname;
System.out.println(fname);
}
void getLname(String lname)
{
this.lname=lname;
System.out.println(lname);
}
}
class cemp extends emp
{
String dept;
String design;
String fullname;
void displayFullname(String f)
{
fullname =f;
System.out.println(f);
}
void Depart(String d)
{
dept=d;
System.out.println(d);
}
void Desg(String des)
{
design=des;
System.out.println(des);
}
}
class remp extends emp
{
String dept;
String design;
String fullname;
void displayFullname(String f)
{
fullname =f;
System.out.println(f);
}
void Depart(String d)
{
dept=d;
System.out.println(d);
}
void Desg(String des)
{
design=des;
System.out.println(des);
}
}
class ex6_3
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the deatils emp");
String fname=in.next();
String lname=in.next();
emp e1=new emp();
e1.getFname(fname);
e1.getLname(lname);
System.out.println("enter the deatils for cemp");
String dept=in.next();
String fullname=in.next();
String design=in.next();
cemp c1=new cemp();
c1.displayFullname(fullname);
c1.Depart(dept);
c1.Desg(design);
System.out.println("enter the deatils for remp");
String dept1=in.next();
String fullname1=in.next();
String design1=in.next();
remp r1=new remp();
r1.displayFullname(fullname1);
r1.Depart(dept1);
r1.Desg(design1);
}
}

