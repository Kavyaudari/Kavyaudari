//inheritance
import java.util.*;
class shape
{
int radius;
double area();
void display()
{
System.out.println("inheritance");
}
}
class circle extends shape
{
Scanner in=new Scanner(System.in);
int radius=in.nextInt();
double area()
{
return(3.14*radius*radius);
}
}
class mt2inherit
{
public static void main(String args[])
{
circle c=new circle();
System.out.println(c.area());
c.display();
}
}

