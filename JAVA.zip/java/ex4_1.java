import java.util.*;
class ex4_1
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the names ");
String s1=in.next();
String s2=in.next();
if(s1.compareTo(s2)>0)
{
System.out.println("s1>s2");
}
else if(s1.compareTo(s2)<0)
{
System.out.println("s2>s1");
}
else
{
System.out.println("equal");
}
}
}


