//abstrction
import java.util.*;
abstract class shapes
{
abstract double area();
}
class circle extends shapes
{
double rad;
circle(double rad)
{
this.rad=rad;
System.out.println("radius ="+rad);
}
double area()
{
return(3.14*rad*rad);
}
}
class rectangle extends shapes
{
int l,b;
rectangle(int l,int b)
{
this.l=l;
this.b=b;
System.out.println("length ="+l);
System.out.println("breadth ="+b);
}
double area()
{
return(l*b);
}
}
class testk
{
public static void main(String args[])
{
shapes s;
Scanner in=new Scanner(System.in);
System.out.println("enter the values");
double rad=in.nextDouble();
int l=in.nextInt();
int b=in.nextInt();
s=new circle(rad);
s=new rectangle(l,b);
System.out.println(s.area());
System.out.println(s.area());
}
}

