#include<stdio.h>
#include<stdlib.h>
void push(int);
void display();
void peek();
void pop();
struct node
{
int data;
struct node*next;
}*top=0,*new,*temp;
void push(int ele)
{
new=malloc(sizeof(struct node));
new->data=ele;
new->next=top;
top=new;
}
void display()
{
temp=top;
if(top==0)
{
printf("stack is empty\n");
}
else
{
while(temp!=0)
{
printf("%d",temp->data);
temp=temp->next;
}
}
}
void peek()
{
if(top==0)
{
printf("empty stack\n");
}
else
{
printf("%d",top->data);
}
}
void pop()
{
temp=top;
if(top==0)
{
printf("underflow\n");
}
else
{
printf("popped element is %d",top->data);
top=top->next;
free(temp);
}
}
int main()
{
int ch,ele;
while(ch!=5)
{
printf("\n1=push\n2=display\n3=peek\n4=pop\n");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the element to be push");
scanf("%d",&ele);
push(ele);
break;
case 2:display();
break;
case 3:peek();
break;
case 4:pop();
break;
default:printf("wrong");
break;
}
}
}

