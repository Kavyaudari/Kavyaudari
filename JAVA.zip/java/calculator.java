import java.util.*;
class calculator
{
public static void main(String args[])
{
System.out.println("enter the values a ,b to perform operations ");
Scanner in=new Scanner(System.in);
int a=in.nextInt();
int b=in.nextInt();
System.out.println("enter to perform \n 1:sum\n2:sub\n3:mult\n4:div\n5:modulo");
int n=in.nextInt();
switch(n)
{
case 1: System.out.println("addition ="+(a+b));
break;
case 2: System.out.println("subtraction ="+(a-b));
break;
case 3: System.out.println("multiplication="+(a*b));
break;
case 4: System.out.println("division ="+(a/b));
break;
case 5:System.out.println("modulo="+(a%b));
break;
}
}
}

