import java.util.*;
class hamil{
    int adj[][];
    int a[];
    Scanner sc=new Scanner(System.in);
    public hamil(int n)
    {
        this.n=n;
        a=new int[n];
        adj=new int[n][n];
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
{
    a[i]=in.nextInt();
}
        }
    }

void fill(int k,int n)
{
    if(n==k)
    {
        for(int i=0;i<n;i++)
        {
            System.out.println(a[i]);
        }
        System.out.println();
        return;
    }
    for( int i=1;i<n;i++)
    {
        isSafe(k,i)
        {
            a[k]=i;
            fill(k+1,n);
        }
    }
    a[0]=0;

    
}


boolean isSafe(int k,int i)
{
    for(int j=0;j<k;j++)
    {
        if(a[j]==i)
        return false;
        if(adj[k-1][j]!=1)
        return false;
        if(k==n-1 && adj[j][a[0]]!=1)
        return false;

    }
    return true;
}
}

class hamiltonion
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
hamil h=new hamil(n);
h.fill(1,n);
}
}