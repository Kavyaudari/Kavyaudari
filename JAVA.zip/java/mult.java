package calculator;
public class mult
{
public int a;
public int b;
public void set(int a,int b)
{
this.a=a;
this.b=b;
}
public void display()
{
System.out.println("multiplition="+a*b);
}
}

