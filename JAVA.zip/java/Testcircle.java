import java.util.*;
class Circle
{
int radius;
double area;
double circum;
void Circle()
{
area=3.14*radius*radius);
circum=(2*3.14*radius);
}
}
class Circle
{
public static void main(String args[])
{
System.out.println("area of a circle");
Scanner in=new Scanner(System.in);
System.out.println("enter the radius");
c1.radius=in.nextInt();
Circle c1=new Circle();
c1.Circle(radius);
System.out.println(c1.area);
System.out.println(c1.circum);
}
}
