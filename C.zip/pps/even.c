//positive or negative
#include<stdio.h>
int main()
{
 int n;
 printf("enter the value of n");
 scanf("%d",&n);
 if(n>0){
 printf("%d is a postive\n",n);
 }
 else if(n<0){
 printf("%d is a negative\n",n);
 }
 else{
 printf("zero\n");
 }
 //even or odd
 if(n%2==0){
 printf("%d is a even\n",n);
 }
 else{
 printf("%d is odd\n",n);
 }
 return 0;
}
