//using void
#include<stdio.h>
void a(void);
void b(void);
int main()
{
int x=3,y=5;
a();
printf("%d%d",x,y);
}
void a()
{
int x=8,y=9;
x++;
y--;
printf("%d%d",x,y);
b();
}
void b()
{
printf("kavy");
}
