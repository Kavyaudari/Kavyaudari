import java.util.*;
class pro
{
int p_id;
String p_name;
int price;
int tprice(int q)
{
return(q*price);
}
}
class ex3_2
{
public static void main(String args[])
{
 pro p[]=new pro[3];
 p[0]=new pro();
 p[1]=new pro();
 p[2]=new pro();
 Scanner in=new Scanner(System.in);
 System.out.println("enter the details ");
 for(int i=0;i<3;i++)
 {
p[i].p_id=in.nextInt();
p[i].p_name=in.next();
p[i].price=in.nextInt();
}
int t=0;
int x;
do
{
System.out.println("enter the id and qty");
int id=in.nextInt();
 int qty=in.nextInt();
 switch(id)
 {
case 1:t+=p[0].tprice(qty);
break;
case 2:t+=p[1].tprice(qty);
break;
case 3:t+=p[2].tprice(qty);
break;
default:System.out.println("do you want other ");
}
x=in.nextInt();
}
while(x==1);
System.out.println("total= " +t);
}
}

