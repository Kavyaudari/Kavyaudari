//encapuslation
import java.util.*;
class student
{
private int id;
private String name;
void set(int id,String name)
{
this.id=id;
this.name=name;}
int getId()
{
return(id);
}
String getName()
{
return(name);
}
}
class testn
{
public static void main(String args[])
{
student s=new student();
Scanner in=new Scanner(System.in);
System.out.println("enter the id ,name");
int id=in.nextInt();
String name=in.next();
s.set(id,name);
System.out.println(s.getId()+s.getName());
}
}


