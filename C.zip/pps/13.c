//coordinates
#include<stdio.h>
int main()
{
int x,y;
printf("enter x,y values");
scanf("%d%d",&x,&y);
if(x>0&&y>0)
{
printf("%d and %d are lies in first coordinate",x,y);
}
else if(x<0&&y>0)
{
printf("%d and %d are lies in second coordinate",x,y);
}
else if(x<0&&y<0)
{
printf("%d and %d are lies in third coordinate",x,y);
}
else if(x>0&&y<0)
{
printf("%d and %d are lies in fourth coordinate",x,y);
}
else
{
printf("%d and %d are lies in origin",x,y);
}
return 0;
}
