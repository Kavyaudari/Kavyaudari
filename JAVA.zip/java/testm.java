//INTERFACE
import java.util.*;
interface  class print
{
void print1();
void draw1();
}
class c implements print
{
void print1()
{
System.out.println("hello");
}
void draw1()
{
System.out.println("kavya");
}
}
class testm
{
public static void main(String args[]);
{
print c1=new c();
c1.print();
c1.draw();
}
}

