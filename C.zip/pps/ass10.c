//factorial
#include<stdio.h>
int main()
{
int i,fact=1,num;
printf("enter the value of num");
scanf("%d",&num);
for(i=1;i<=num;i++){
fact=fact*i;
}
printf("factorial of %d=%d",num,fact);
return 0;
}
