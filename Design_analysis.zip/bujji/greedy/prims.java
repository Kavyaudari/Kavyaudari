import java.util.*;
class prims
{
int n;
int a[][];
int p[];
Scanner in=new Scanner(System.in);
prims(int n)
{
this.n=n;
a=new int[n][n];
p=new int[n];

for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
System.out.println(i+"row"+j+"col");
if(i!=j)
{
a[i][j]=a[j][i]=in.nextInt();
}
}
}
}
int prim(int v[],int n)
{
int k=n-1;
int cost=0;
int c=-1;
int d=-1;
while(k>0)
{
int min=Integer.MAX_VALUE;
for(int i=0;i<n;i++)
{
if(v[i]==1)
{
for(int j=0;j<n;j++)
{
if(v[j]!=1&&a[i][j]!=0)
{
if(a[i][j]<min)
{
min=a[i][j];
d=i;
c=j;
}
}
}
}
}
if(c==-1)
break;
v[c]=1;
p[c]=d;
cost+=a[d][c];
k--;
}
print(p,a);
return cost;
}
void print(int p[],int a[][])
{
     System.out.println("Edge \tWeight");
        for (int i = 0; i < n; i++)
            System.out.println(p[i] + " - " + i + "\t"
                               + a[i][p[i]]);
    }
}

class test
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n=in.nextInt();
int v[];
v=new int[n];
v[0]=1;
prims p=new prims(n);
System.out.println(p.prim(v,n));
}
}

