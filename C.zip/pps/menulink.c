#include<stdio.h>
#include<stdlib.h>
//linked list node
struct node
{
int info;
struct node *link;
};
struct node*start=NULL;
//fun to create list with n nodesintially
void createlist()
{
if(start==NULL)
{
int n;
printf("enter the number of nodes:  ");
scanf("%d",&n);
if(n!=0){
int data;
struct node *newnode;
struct node *temp;
newnode=malloc(sizeof(struct node));
start=newnode;//start=header
temp=start;
printf("enter the number to be insersted :  ");
scanf("%d",&data);
start->info=data;
for(int i=2;i<=n;i++)
{
newnode=malloc(sizeof(struct node));
temp->link=newnode;
printf("enter the number to be inserted:  ");
scanf("%d",&data);
newnode->info=data;
temp=temp->link;
}
}
printf("the list is created");
}
else 
printf("list is already created");
}
//function traverse the list 
void traverse()
{
struct node *temp;
//list is empty
if(start==NULL)
printf("list is empty");
//else print
else {
temp=start;
while(temp!=NULL)
{
printf("Data=%d\n",temp->info);
temp=temp->link;
}
}
}
void insertbeg()
{
int data;
struct node *temp;
temp=malloc(sizeof(struct node));
printf("enter the number to be inserted");
scanf("%d",&data);
temp->info=data;
//pointer temp will be assigned to start
temp->link=start;
start=temp;
}
//inserting at end
void insertend()
{
int data;
struct node *temp,*head;
temp=malloc(sizeof(struct node));
//enter the num
printf("enter the number to be inserted: ");
scanf("%d",&data);
//changes the links
temp->link=0;
temp->info=data;
head=start;
while(head->link!=NULL)
{
head=head->link;
}
head->link=temp;
}
void insertpos()
{
struct node *temp,*newnode;
int pos,data,i=0;
newnode=malloc(sizeof(struct node));
//enter the pos and data
printf("enter the position and data: ");
scanf("%d %d",&pos ,&data);
//change links
temp=start;
newnode->info=data;
newnode->link=0;
while(i<pos-1)
{
temp=temp->link;
i++;
}
newnode->link=temp->link;
temp->link=newnode;
}
//funtions to delete 
void deletebeg()
{
struct node *temp;
if(start==NULL)
{
printf("list is empty");
}
else {
temp=start;
start=start->link;
free(temp);
}
}
void deleteend()
{
struct node *temp,*prevnode;
if(start=NULL)
{
printf("empty");
}
else 
{
temp=start;
while(temp->link!=0)
{
prevnode=temp;
temp=temp->link;
}
free(temp);
prevnode->link=0;
}
}
void deletepos()
{
struct node *temp,*position;
int i=1,pos;
//empty
if(start==NULL)
{
printf("list is empty");
}
else 
{
printf("enter the index: ");
//position to be deleted
scanf("%d",&pos);
position=malloc(sizeof(struct node));
temp=start;
//traverse till postion
while(i<pos-1)
{
temp=temp->link;
i++;
}
//change links
position=temp->link;
temp->link=position->link;
//free memory
free(position);
}
}
//driver CODe
int main()
{
int choice;
while(1)
{
printf("\n\t1 To see the list\n");
printf("\n\t2 For insertion at staring\n");
printf("\n\t3 For insertion at end \n ");
printf("\n\t4 For insertion at pos \n");
printf("\n\t5 For deletion at beg \n");
printf("\n\t6 For deletion at end \n");
printf("\n\t7 For deletion at pos \n");
printf("\n\t8 To exit \n");
printf("\n enter the choice:  \n");
scanf("%d",&choice);
switch(choice)
{
case 1:
traverse();
break;
case 2:
insertbeg();
break;
case 3:
insertend();
break;
case 4:
insertpos();
break;
case 5:
deletebeg();
break;
case 6:
deleteend();
break;
case 7:
deletepos();
break;
case 8:
exit(1);
break;
default:
printf("incorrect choice\n");
}
}
return 0;
}




