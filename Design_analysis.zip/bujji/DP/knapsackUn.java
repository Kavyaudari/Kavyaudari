import java.math.*;
import java.util.*;
class knapsack{
    int n;
    int wt[];
    int val[];
    int w;
    Scanner in=new Scanner(System.in);
    public knapsack(int n,int w)
    {
        this.w=w;
        this.n=n;
        wt= new int[n];
        val=new int[n];
        for(int i=0;i<n;i++)
        {
        System.out.println("enter the weight of "+(i+1)+ "item ");
        wt[i]=in.nextInt();
        }
        for(int i=0;i<n;i++)
        {
        System.out.println("enter the value of "+(i+1)+ "item ");
        val[i]=in.nextInt();
        }
    }
    int ks(int n,int w)
    {
        if(n==0||w==0)
        return 0;
        if(wt[n-1]<=w)
        return Math.max(val[n-1]+ks(n,w-wt[n-1]),ks(n-1,w));
        else 
        return ks(n-1,w);
    }
}
     

class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of items");
        int n=in.nextInt();
        System.out.println("enter the weight of the bag");
        int w=in.nextInt();
        knapsack k=new knapsack(n,w);
        System.out.println("the max value of bag:"+k.ks(n,w));
        
    
    }
}
