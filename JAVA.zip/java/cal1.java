package motu;
public class cal1
{
public int add(int a,int b)
{
return (a+b);
}
public int sub(int a,int b)
{
return (a-b);
}
public int mult(int a,int b)
{
return (a*b);
}
}
 
