import java.util.*;
class matrix{
int a[];
int n;
int k;
int min=Integer.MAX_VALUE;
Scanner in=new Scanner(System.in);
public matrix(int n)
{
this.n=n;
a=new int[n];
System.out.println("enter the sizes of matrix");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
}
int mcm(int i,int j)
{
int val;
int b,c;
if(i==j)
{
return 0;
}
for(int k=i;k<j;k++)
{
b=mcm(i,k)+mcm(k+1,j);
c=a[i-1]*a[j]*a[k];
val=c+b;
if(val<min)
{
min=val;
}}
return min;

}
}


class test{
public static void main(String args[])
{
int n;
Scanner in=new Scanner(System.in);
System.out.println("Enter the size of array");
n=in.nextInt();
matrix m=new matrix(n);
System.out.println(m.mcm(1,n-1));
}
}




