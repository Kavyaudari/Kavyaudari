#include<stdio.h>
#include<stdlib.h>
#define n 5
int q[n];
int f=-1;
int r=-1;
void eq(int );
int dq();
void dis();
void eq(int x)
{
if(r>n)
{
printf("overflow");
}
else if(f==-1||r==-1)
{
f=0,r=0;
q[r]=x;
}
else
{
r++;
q[r]=x;
}
}
int dq()
{
if(f==-1||r==-1)
{
printf("empty");
}
else if(f==0&&r==0)
{
f=r=-1;
}
else
{
printf("%d",q[f]);
f++;
}
}
void dis()
{
if(f==-1||r==-1)
{
printf("empty");
}
else
{
int i;
for(i=f;i<=r;i++)
{
printf("%d",q[i]);
}
}
}
void main()
{
int ch,ele;
printf("\n1=eq\n2=dq\n3=dis");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the ele");
scanf("%d",&ele);
eq(ele);
break;
case 2:dq();
break;
case 3:dis();
break;
default:printf("wrong");
break;
}
}
}
