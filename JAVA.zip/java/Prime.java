import java.util.*;
class Prime
{
public static void main(String args[])
{
System.out.println("checking given number is prime number or not");
Scanner in=new Scanner(System.in);
System.out.println("enter the number"); 
int x=in.nextInt();
int i,j;
int count=0;
for(i=2;i<=x;i++)
{
if(x%i==0)
{
count=1;
for(j=2;j<=i/2;j++)
{
if(i%j==0)
{
count=0;
break;
}
}
if(count==1)
{
System.out.println(i);
}
}
}
}
}



