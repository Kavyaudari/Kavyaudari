import java.util.*;
class subset{
    int arr[];
    int n;
    int sum;
    int s[][];
    Scanner in=new Scanner(System.in);
    subset(int n,int sum)
    {
        this.n=n;
        this.sum=sum;
        arr=new int[n];
        s=new int[n+1][sum+1];
    
    System.out.println("enter the values of arrays");

    for(int i=0;i<n;i++)
    {
        arr[i]=in.nextInt();

    }
}
    int ss(int n,int sum)
    {
        for(int i=0;i<=n;i++)
        {
            for(int j=0;j<=sum;j++)
            {
                if(j==0)
                {
                    s[i][j]=1;
                    continue;
                }
                if(i==0)
                {
                    s[i][j]=0;
                    continue;
                }
                if(arr[i-1]<=j)
                {
                    if(s[i-1][j-arr[i-1]]!=0||s[i-1][j]!=0)
                    {
                         s[i][j]=1;
                    }
                    else
                     s[i][j]=0;
                }
                else
                {
                     s[i][j]=s[i-1][j];
                }
            }
        }
            return s[n][sum];

        
    }
}
class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of items");
        int n=in.nextInt();
        System.out.println("enter the sum  value of the subset");
        int sum=in.nextInt();
        subset s=new subset(n,sum);
       
        if(s.ss(n,sum)==0)
        {
        System.out.println("false");
        }
        else
           System.out.println("true");
        

        
    
    }
}
