//indirect
#include<stdio.h>
#include<stdlib.h>
void pps(void);
int x=0;
void main()
{
if(x==6)
exit(0);
pps();
}
void pps(void)
{
printf("%d",x);
x++;
main();
}
