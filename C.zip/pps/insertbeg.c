
#include<stdio.h>
#include<stdlib.h>
struct node
{
int num;
struct node *nextptr;//next
}*stnode;//header
void createNodelist(int n);
void displaylist();
void insert(struct node *);
int main()
{
int n;
printf("input the number of nodes:\n");
scanf("%d",&n);
createNodelist(n);
printf("data entered");
displaylist();
return 0;
}
void createNodelist(int n)
{
struct node *fnNode,*tmp;//new node
int num,i;
stnode=(struct node *)malloc(sizeof(struct node));
if(stnode==NULL){
printf("memeory cannot be allocated");
}
else
{
printf("input :  ");
scanf("%d",&num);
stnode->num=num;
stnode->nextptr=NULL;
tmp=stnode;
for(i=2;i<=n;i++)
{
fnNode=(struct node *)malloc(sizeof(struct node));
if(fnNode==NULL)
{
printf("memory not allocated");
break;
}
else
{
printf("input data for node %d :  ",i);
scanf("%d",&num);
fnNode->num=num;
fnNode->nextptr=NULL;
tmp->nextptr=fnNode;
tmp=tmp->nextptr;
}
}
}
}
void displaylist()
{
struct node *tmp;
if(stnode==NULL)
{
printf("list is empty");
}
else 
{
tmp=stnode;
while(tmp!=NULL)
{
printf("data=%d\n",tmp->num);
tmp=tmp->nextptr;
}
}
}
/*void insert(struct node *stnode)
{
struct node *fnNode;
int numb;
printf("enter the data: ");
scanf("%d",&numb);
fnNode=(struct node *)malloc(sizeof(struct node));
fnNode->num=numb;
fnNode->nextptr=stnode;
stnode=fnNode;
return ;
}*/
