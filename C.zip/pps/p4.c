//without arguments and return type
#include<stdio.h>
void fact(void);
int main()
{
fact();
}
void fact()
{
int a,b,c;
printf("enter the values");
scanf("%d%d",&a,&b);
c=a*b;
printf("%d",c);
}
