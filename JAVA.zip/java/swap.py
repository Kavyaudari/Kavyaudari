a=input("enter the value of a=")
b=input("enter the value of b=")
temp=a
a=b
b=temp
print("a= " +a)
print("b= "+b)


