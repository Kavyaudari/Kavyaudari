#include<stdio.h>
#include<stdlib.h>
#define n 5
int q[n];
int front=-1,rear=-1;
void bfs(int [][n],int[]);
void eq(int);
int dq();
int main()
{
int graph[n][n],i,j;
int v[n]={0};
printf("enter the elements");
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
scanf("%d",&graph[i][j]);
}
}
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
printf("%d",graph[i][j]);
}
printf("\n");
}
bfs(graph,v);
}
void bfs(int graph[][n],int v[])
{
front=0,rear=0;
eq(0);
v[0]=1;
while(front!=rear)
{
int c=q[front];
printf("%d",q[front]);
dq();
for(int i=0;i<n;i++)
{
if(graph[c][i]==1&&v[i]==0)
{
eq(i);
v[i]=1;
}
}
}
}
void eq(int x)
{
q[rear]=x;
rear++;
}
int dq()
{
int x;
x=q[front];
front++;
return(x);
}

