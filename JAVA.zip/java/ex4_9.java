import java.util.*;
class ex4_9
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter str");
String s=in.next();
String s1=s.toLowerCase();
System.out.println(s1);
}
}

