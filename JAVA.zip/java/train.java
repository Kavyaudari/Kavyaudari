import java.util.*;
class ticket
{
static int tb;
ticket(int y)
{
tb=y;
}
int cb=0;
synchronized public void allot(int y)
{
System.out.println("total =" +(tb-cb));
if(cb<=tb&&(tb-cb)!=0)
{
System.out.println(y+"berth ");
System.out.println(y+ "ticket");
}else
{
System.out.println("not ");
if(cb==tb)
{
}
else
{
cb++;
}
}
}
}
class person extends  Thread
{
int y;
ticket t;
person(int y ,ticket t)
{
this.y=y;
this.t=t;
}
public void run()
{
t.allot(y);
}
}
class train
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter no passengers");
int n=in.nextInt();
person p[]=new person[n+1];
System.out.println("enter berths");
int b=in.nextInt();
ticket t=new ticket(b);
for(int i=1;i<=n;i++)
{p[i]=new person(i,t);
p[i].start();
}
}
}

