class Pen{//blueprint of pen theat means properties and methods 
String color;
String type;//properties
public void write()//calling function
{
System.out.println("writing");
}
}
//now we need make objects;
public class Oops{
public static void main(String args[])//main fun
{
Pen pen1=new Pen();
pen1.color="black";
//properties are acessed with dot
pen1.type="meow";
pen1.write();
}
}
