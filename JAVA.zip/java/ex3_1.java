import java.util.*;
class emp
{
int id;
String name;
int sal;
String dept;
void display()
{
System.out.println("the details are = " +id +name +sal +dept);
}
}
class ex3_1
{
public static void main(String args[])
{
emp e[]=new emp[3];
e[0]=new emp();
e[1]=new emp();
e[2]=new emp();
Scanner in=new Scanner(System.in);
System.out.println("enter the details");
for(int i=0;i<3;i++)
{
e[i].id=in.nextInt();
e[i].name=in.next();
e[i].sal=in.nextInt();
e[i].dept=in.next();
}
System.out.println("enter the id ");
int s=in.nextInt();
for(int i=0;i<3;i++)
{
if(e[i].id==s)
{
e[i].display();
break;
}
}
}
}

