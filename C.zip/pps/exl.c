#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*head,*ptr,*ptr1;
struct node *create()
{
int n;
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&n);
if(n==-1)
{
return 0;
}
else {
new->data=n;
}
}
void inbeg()
{
ptr=head;
new=create();
if(ptr==0)
{
new->next=0;
head=new;
}

else
{
new->next=head;
head=new;
}
}
void inend()
{
ptr=head;
new=create();
if(ptr==0)
{
new->next=0;
head=new;
}
else
{
while(ptr->next!=0)
{
ptr=ptr->next;
}
new->next=0;
ptr->next=new;
}
}
void inpo()
{
ptr=head;
new=create();
if(ptr==0)
{
new->next=0;
head=new;
}
else
{
int p,i;
printf("enter the pos");
scanf("%d",&p);
for(i=1;i<p-1;i++)
{
ptr=ptr->next;
}
new->next=ptr->next;
ptr->next=new;
}
}
void delbeg()
{
ptr=head;
if(ptr==0)
{
printf("empty");
}
else
{
head=ptr->next;
free(ptr);
}
}
void delend()
{
ptr=head;
if(ptr==0)
printf("nul");
else
{
while(ptr->next!=0)
{
ptr1=ptr;
ptr=ptr->next;
}
ptr1->next=0;
free(ptr);
}
}
void delpo()
{
ptr=head;
int p,i;
printf("enter the po");
scanf("%d",&p);
if(ptr==0)
printf("null");
else
{
for(i=1;i<p-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
ptr->next=ptr1->next;
free(ptr1);
}
}
void traverse()
{
ptr=head;
if(ptr==0)
printf("null");
else
{
while(ptr!=0)
{
printf("%d",ptr->data);
ptr=ptr->next;
}
}
}
void main()
{
int ch;
printf("\n1=inbeg\n2=end\n3=pos\n4=delbeg\n5=end\n6=pos\n7=tra");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:inbeg();
break;
case 2:inend();
break;
case 3:inpo();
break;
case 4:delbeg();
break;
case 5:delend();
break;
case 6:delpo();
break;
case 7:traverse();
break;
default:printf("k");
break;
}
}
}
