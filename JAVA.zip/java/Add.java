import java.util.*;
//import java.lang.*;
public class Add{
public static void main(String args[])
{
System.out.println("adding two numbers by taking user input");
Scanner in=new Scanner(System.in);
System.out .println("enter the first number");
int a=in.nextInt();
System.out.println("enter the second number");
int b=in.nextInt();
int sum=a+b;
System.out.println("the sum=");
System.out.println(sum);
}
}


