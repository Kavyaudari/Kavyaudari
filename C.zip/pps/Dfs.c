#include<stdio.h>
#include<stdlib.h>
#define max 20
int adj[max][max];
int stack[max];
int visited[max]={0};
int top=-1;
void addedge(int s,int d)
{
adj[s][d]=1;
adj[d][s]=1;
}
void bfs(int start)
{
int v;
stack[top++]=start;
while(top>=0)
{
v=stack[top--];
if(visited[v]==0)
{
printf("%d",v);
visited[v]=1;
for(int i=0;i<max;i++)
{
if(adj[v][i]==1 && !visited[i])
{
stack[top++]=i;
}
}
}
}
}
int main()
{
for(int i=0;i<max;i++)
{
for(int j=0;i<max;j++)
{
adj[i][j]=0;
}
}
addedge(0,1);
addedge(0,2);
addedge(1,2);
addedge(1,3);
addedge(2,3);
addedge(3,4);
printf("DFS\n");
bfs(0);
printf("\n");
}


