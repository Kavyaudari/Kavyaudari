#include<stdlib.h>
#include<stdio.h>
struct node
{
int data;
struct node *left;
struct node *right;
} *root=NULL,*temp;
struct node *create(int x)
{
temp=malloc(sizeof(struct node));
temp->data=x;
temp->left=NULL;
temp->right=NULL;
return(temp);
}
struct node *insert(struct node *root,int x)
{
if(root==NULL)
return create(x);
else if(x<root->data)
root->left=insert(root->left,x);
else if(x>root->data)
root->right=insert(root->right,x);
return root;
}
struct node *search(struct node *root,int x)
{
if(root==NULL)
return NULL;
else
{
if(root->data==x)
return root;
else if(root->data>x)
return search(root->left,x);
else  if(root->data<x)
return search(root->right,x);
}
}
void inorder(struct node *temp)
{
if(temp!=NULL)
{
inorder(temp->left);
printf("%d  ",temp->data);
inorder(temp->right);
}
}
void main()
{
int x,n;
printf("enter the -1 to stop");
printf("enter the data");
scanf("%d",&x);
root=create(x);
while(x!=-1)
{
insert(root,x);
printf("enter the data");
scanf("%d",&x);
}
inorder(root);
printf("enter the ele to be searched");
scanf("%d",&n);
if(search(root,n)==NULL)
printf("not found");
else
printf("found");
}

