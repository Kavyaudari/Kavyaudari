class week5_static 
{
static
{
System.out.println("iam static block");
}
static void display()
{
System.out.println("static method");
}
 static int a=5;
 public static void main(String args[])
 {
 System.out.println(week5_static.a);
 week5_static.display();
 }
 }
 

