//inheritance
import java.util.*;
class employee
{
float salary;
void display(float salary)
{
this.salary=salary;
System.out.println("salary ="+salary);
}
}
class e extends employee
{
float bonus;
void print(float bonus)
{
this.bonus=bonus;
System.out.println("bonus="+bonus);
float total;
total=bonus+salary;
System.out.println("total ="+total);
}
}
class testi
{
public static void main(String args[])
{
e e1=new e();
Scanner in=new Scanner(System.in);
System.out.println("enter the values");
float s=in.nextFloat();
float b=in.nextFloat();
e1.display(s);
e1.print(b);
}
}



