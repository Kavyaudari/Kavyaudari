//without arguments and without return type
#include<stdio.h>
void fun(void);
void main()
{
fun();
}
void fun()
{
int a=2,b=3,c;
c=a*b;
printf("c=%d",c);
}

