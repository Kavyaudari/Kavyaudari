#include<stdio.h>
#include<stdlib.h>
struct node()
{
int data;
struct node *next;
}*header,ptr,*new;
int read()
{
int a;
printf("enter the data\n");
scanf("%d",&a):
return a;
}
void insertbeg()
{
new=malloc(sizeof(struct node));
int a=read();
new->data=a;
ptr=header;
if(ptr==NULL)
{
new->next=NULL:
header=new;
}
else
{
new->next=NULL;
header=new;
}
}

