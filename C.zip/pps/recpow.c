//power using recurrsion
#include<stdio.h>
int p(int,int);
int main()
{
int a,base,c;
printf("enter the value of a,base");
scanf("%d%d",&a,&base);
c=p(a,base);
printf("%d",c);
}
int p(int x, int y)
{
if(x!=0)
return(y*p(x-1,y));
else
return(1);
}
