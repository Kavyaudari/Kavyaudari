#include<stdio.h>
#include<stdlib.h>
#define n 5
int q[5];
int front=-1;
int rear=-1;
void enqueue(int x)
{
if(front==-1&&rear==-1)
{
front=rear=0;
q[rear]=x;
}
else if((rear+1)%n==front)
{
printf("queue is full");
}
else
{
rear=(rear+1)%n;
q[rear]=x;
}
}
void dequeue()
{
if(front==-1&&rear==-1)
printf("queue is fill");
else if(rear==front)
{
printf("%d",q[front]);
rear=front=0;
}
else
{
printf("%d",q[front]);
front=(front+1)%n;
}
}
void display()
{
int i=front;
if(front==-1&&rear==-1)
{
printf("queue is empty");
}
else
{
printf("queue is   ");
while(i!=rear)
{
printf("%d",q[i]);
i=(i+1)%n;
}
printf("%d",q[rear]);
}
}
void peek()
{
printf("%d",q[front]);
}
int main()
{
int ch,ele;
printf("\n1=enqueue\n2=dequeue\n3=display\n4=peek");
while(ch!=5)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the element");
scanf("%d",&ele);
enqueue(ele);
break;
case 2:dequeue();
break;
case 3:display();
break;
case 4:peek();
break;
default:printf("wrong");
break;
}
}
}
