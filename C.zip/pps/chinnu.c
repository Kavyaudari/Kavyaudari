//infix to postfix expression evaluation
#include<stdio.h>
#include<stdlib.h>
#define max 20
char stack[100];
int top=-1;
void push(char ele)
{
if(top==max-1)
{
printf("stack is underflow");
return;
}
stack[top]=ele;
}
char pop()
{
if(top<0)
{
printf("stack is underflow");
return;
}
return stack[top--];
}
int getp(char x)
{
if(x=='+'||x=='-')
{
return 1;
}
if(x=='*'||x=='/')
{
return 2;
return 0;
}
}
void inpo(char inexp[])
{
char c;
int i;
for(i=0;inexp[1]!='\0';i++)
{
if(isalnum(inexp[i]))
printf("%c",inexp[i]);
else if(inexp[i]=='(')
push(inexp[i]);
else if(inexp[i]==')')
{
while((c=pop(i)!='('))
printf("%c",c);
}
else
{
while(getp(stack[top])>=getp(inexp[i]))
printf("%c",pop());
push(inexp[i]);
}
}
while(top>=0)
{
printf("%c",pop());
}
}
int main()
{
char inexp[20];
printf("enter expression \n");
scanf("%s",inexp);
inpo(inexp);
return 0;
}

