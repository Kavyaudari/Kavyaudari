//associativity
#include<stdio.h>
int main()
{
int a=10,b=2,x=0;
x=a+b*a+10/2*a;
printf("%d",x);
}
