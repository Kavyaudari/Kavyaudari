//positive or negative and even or odd
#include<stdio.h>
int main()
{
int n;
printf("enter n value");
scanf("%d",&n);
if(n>0)
printf("positive ");
else if(n<0)
printf("negative");
//else if 
//printf("zero");
 if(n%2==0)
printf("even");
else
printf("odd");
}
