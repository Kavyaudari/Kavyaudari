//char 
#include<stdio.h>
int main()
{
char str[10];
char ch;
int i;
printf("enter any cha");
scanf("%c",&ch);
printf("enter any string");
scanf("%s",str);
for(i=0;str[i]!='\0';i++)
{
if(ch==str[i])
{
printf("%c is present in %d",ch,i);
break;
}
}
if(ch!=str[i])
{
printf("not present");
}
}
