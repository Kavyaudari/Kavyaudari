#include<stdio.h>
int linear(int [],int,int);
int main()
{
int n,i,k;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("array elements\n");
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
printf("\n enter the seraching element\n");
scanf("%d",&k);
int l=linear(a,n,k)
{
if(l==-1)
{
printf("element is not found");
}
else
{
printf("element is found at %d position",l);
}
return 0;
}
int linear(int a[],int n,int k)
{
for(i=0;i<n;i++)
{
if(a[i]==k)
{
return i;
}
}
return -1;
}
}
