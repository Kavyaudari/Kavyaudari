#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *prev,*next;
}*new,*ptr,*ptr1,*ptr2,*head;
void insertbeg();
void insertend();
void insertpos();
void delebeg();
void deleend();
void delepos();
void traverse();
int main()
{
int ch;
printf("enter the choice:\n1=insertbeg\n2=insertend\n3=insertpos\n4=delebeg\n5=deleend\n6=delepos\n7=traverse");
while(ch!=8)
{
printf("enter the choice");

scanf("%d",&ch);
switch(ch)
{
case 1:insertbeg();
break;
case 2:insertend();

break;
case 3:insertpos();

break;
case 4:delebeg();

break;
case 5:deleend();

break;
case 6:delepos();

break;
case 7:traverse();
break;
default:printf("enter the correct choice\n");
break;
}
}
}
void insertbeg()
{
new=malloc(sizeof(struct node *));
printf("enter the data\n");
scanf("%d",&new->data);
if(head==NULL)
{
new->next=NULL;
new->prev=NULL;
head=new;
}
else
{
ptr=head;
new->next=ptr;
ptr->prev=new;
new->prev=NULL;
head=new;
}
}
void insertend()
{
ptr=head;
new=malloc(sizeof(struct node *));
printf("enter the data\n");
scanf("%d",&new->data);
if(head==NULL){
new->next=NULL;
new->prev=NULL;
head=new;
}
else
{
while(ptr->next!=NULL)
{
ptr=ptr->next;
}
ptr->next=new;
new->prev=ptr;
new->next=NULL;
}
}
void insertpos()
{
int p,i;
printf("enter the position\n");
scanf("%d",&p);
new=malloc(sizeof(struct node *));
printf("enter the data\n");
scanf("%d",&new->data);
if(head==NULL){
new->next=NULL;
new->prev=NULL;
head=new;
}
/*else if(ptr->next==NULL)
{
ptr=head;
new->next=ptr;
ptr->prev=NULL;
head=new;
}*/
else
{
ptr=head;
for(i=1;i<p-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
new->next=ptr1;
ptr1->prev=new;
ptr->next=new;
new->prev=ptr;
}
}
void delebeg()
{
if(head==NULL){
printf("empty list\n");
}
else
{
ptr=head;
head=ptr->next;
head->prev=NULL;
free(ptr);
}
}
void deleend()
{
if(head==NULL){
printf("empty list\n");
}
else
{
ptr=head;
while(ptr->next!=NULL)
{
ptr=ptr->next;
}
ptr1=ptr->prev;
ptr1->next=NULL;
free(ptr);
}
}
void delepos()
{ptr=head;
if(head==NULL){
printf("empty list\n");
}
else
{
int p,i;
printf("enter the post");
scanf("%d",&p);
for(i=1;i<p-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
ptr2=ptr1->next;
ptr->next=ptr2;
ptr2->prev=ptr;
free(ptr1);
}
}
void traverse()
{
ptr=head;
if(head==NULL){
printf("empty list\n");
}
else
{
while(ptr->next!=NULL)
{
printf("%d",ptr->data);
ptr=ptr->next;
}
printf("%d",ptr->data);
printf("\n");
}
}


