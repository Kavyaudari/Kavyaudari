//table
#include<stdio.h>
int main()
{ 
printf("7*1=7\n");
printf("7*2=14\n");
printf("7*3=21\n");
printf("7*4=28\n");
printf("7*5=35\n");
printf("7*6=42\n");
printf("7*7=49\n");
printf("7*8=56\n");
printf("7*9=63\n");
printf("7*10=70\n");
return 0;
}

