import java.util.*;
import java.lang.Math;
class Calciif{
public static void main(String args[])
{
System.out.println("working calci by taking user input");
Scanner in=new Scanner(System.in);
System.out.println("enter the first number");
int x=in.nextInt();
System.out.println("enter the second number");
int y=in.nextInt();
int z;
System.out.println("enter the operator");
char op=in.next().charAt(0);
if(op=='+')
{
z=x+y;
System.out.println(z);
}
else if(op=='-')
{
z=x-y;
System.out.println(z);
}
else if(op=='*')
{
z=x*y;
System.out.println(z);
}
else if(op=='/')
{
z=x/y;
System.out.println(z);
}
else if(op=='k')
{
System.out.println(Math.pow(x,y));
}
else if(op=='%')
{
z=x%y;
System.out.println(z);
}
else 
{
System.out.println("wrong operator");
}
}
}



