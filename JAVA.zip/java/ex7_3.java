import java.util.*;
interface payable
{
void getAmount(int m,int n);
}
class emp implements payable
{
public void getAmount(int m ,int n)
{
System.out.println("payment= " +(m*100));
System.out.println("invoice= "+((m*100)+n));
}
}
class ex7_3
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int m=in.nextInt();
int n=in.nextInt();
payable p1=new emp();
p1.getAmount(m,n);
}
}
