#include<stdio.h>

int graph[100][100],n;
int visited[100];
int visit_count=1;
int stack[100],top=-1;
int flag=0;
void enter_data2()
{
int i,j;
n=7;

for(i=0;i<n;i++)
visited[i]=0;
visited[0]=1;

for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
graph[i][j]=0;
}
}
graph[0][1]=1; 
graph[0][2]=1;
graph[1][3]=1;
graph[1][4]=1;
graph[2][5]=1;
graph[2][6]=1;
}
int is_stack_empty()
{
if(top==-1)
return 1;
else
return 0;
}

void push(int ele)
{
if(top==n-1)
{
printf("Stack overflow");
}
else
{
top++;
stack[top]=ele;
//printf("\n%d pushed",ele);
}
}

int pop()
{
int ele;
if(top==-1)
printf("Stack underflow");
else
{
ele=stack[top];
top--;
//printf("\nPopping %d",ele);
return(ele);
}
}

int all_visited()
{
if(visit_count==n)
return 1;
else
return 0;
}

void enter_data()
{
int i,j;
printf("Enter no of nodes");
scanf("%d",&n);

for(i=0;i<n;i++)
visited[i]=0;
visited[0]=1;
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
printf("Connection:%d-%d",i+1,j+1);
scanf("%d",&graph[i][j]);
}
}
}

void check(int t)
{
int i;
//printf("\nChecking for %d",t);
for(i=0;i<n;i++)
	{
	if((graph[t][i]==1)&&(visited[i]==0))
	{
	visited[i]=1;
	visit_count++;
	flag=1;
	printf("\n%d visited\n",i);
	push(i);
	break;
	}
	}
	
	if(flag==1)
	{
	flag=0;
	check(i);
	}
	else
	{
	
	
	if(is_stack_empty()==0)
	{
	check(pop());
	}
	}
	
	

}

void traverse()
{
int i,t;
printf("Nodes visits are as follows");
printf("\n0 visited\n");
push(0);
t=0;
check(0);
}




void main()
{
enter_data();
traverse();
}

