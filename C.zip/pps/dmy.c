//days months years
#include<stdio.h>
int main()
{
int days,years,months,o;
printf("enter the number of days");
scanf("%d",&days);
years=days/365;
months=(days-years*365)/30;
o=(days-years*365-months*30);
printf("years=%d",years);
printf("\nmonths=%d",months);
printf("\no=%d",0);
return 0;
}
