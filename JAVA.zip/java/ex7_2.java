import java.util.*;
abstract class emp
{
abstract void getAmount(int p,int q);
}
class he extends emp
{
public void getAmount(int m,int wage)
{
System.out.println("hourly emp= " +(m*wage));
}
}
class we extends emp
{
public void getAmount(int w,int wages)
{
System.out.println("weekely emp= "+ (w*wages));
}
}
class ex7_2
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int a=in.nextInt();
int b=in.nextInt();
int c=in.nextInt();
int d=in.nextInt();
emp e1=new he();
e1.getAmount(a,b);
emp e2=new we();
e2.getAmount(c,d);
}
}


