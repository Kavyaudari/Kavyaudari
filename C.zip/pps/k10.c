//ponter usb
#include<stdio.h>
int main()
{
int n,i;
printf("enter the size");
scanf("%d",&n);
int a[n];
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
int *p,*q;
p=&a[0];
q=&a[4];
q-p;
printf("%d",a[i]);
}

