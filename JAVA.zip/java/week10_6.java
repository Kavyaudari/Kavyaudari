class myexception extends Exception
{
private String s;
public myexception(String s)
{
this.s=s;
}
public void print()
{
System.out.println(s);
}
}
public class week10_6
{
public static void main(String args[])
{
try
{
throw new Exception("this is exception ");
}
catch(Exception e)
{
e.print();
}
}
}
