import java.util.*;
/*class test3_1
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the number of employees ");
int n=in.nextInt();
System.out.println("enter the details of all employees ");
String name[]=new String[n];
int id[]=new int[n];
String gender[]=new String[n];
String add[]=new String[n];
double salary[]=new double[n];
String desc[]=new String[n];
System.out.println("details are name,id,gender,address,salary,desc ");
for(int i=0;i<n;i++)
{
System.out.println("enter the details " +i+1);
name[i]=in.next();
id[i]=in.nextInt();
gender[i]=in.next();
add[i]=in.next();
salary[i]=in.nextDouble();
desc[i]=in.next();
}
System.out.println("enter the id ");
int ID=in.nextInt();
System.out.println("the deatils are ");
for(int i=0;i<n;i++)
{
if(ID==id[i])
{
System.out.println("name= "+name[i]);
System.out.println("id= "+id[i]);
System.out.println("gender= "+gender[i]);
System.out.println("add= "+add[i]);
System.out.println("salary= "+salary[i]);
System.out.println("desc= "+desc[i]);
}
}
}
}*/
class test3_1
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the number od employees are there ");
int n=in.nextInt();
System.out.println("enter the details ");
int id[]=new int[n];
String name[]=new String[n];
double salary[]=new double[n];
String add[]=new String[n];
String gender[]=new String[n];
String desc[]=new String[n];
for(int i=0;i<n;i++)
{
System.out.println("enter the details of " +(i+1));
id[i]=in.nextInt();
name[i]=in.next();
salary[i]=in.nextInt();
add[i]=in.next();
gender[i]=in.next();
desc[i]=in.next();
}
System.out.println("enter the id number ");
int Id=in.nextInt();
for(int i=0;i<n;i++)
{
if(Id==id[i])
{
System.out.println(" id = "+id[i]);
System.out.println("name = "+name[i]); 
System.out.println("salary = "+salary[i]);
System.out.println("add = "+add[i]);
System.out.println("gender ="+gender[i]); 
System.out.println("desc ="+desc[i]);
}
}
}
}

