#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*ptr,*ptr1,*head;
void insertbeg();
void insertend();
void insertpos();
void delebeg();
void deleend();
void delepos();
void traverse();
int main()
{
int ch;
printf("enter the choice:\n1=insertbeg\n2=insertend\n3=insertpos\n4=deletebeg\n5=deleteend\n6=deletepos\n7=traverse");
while(ch!=8)
{
printf("enter the choice");

scanf("%d",&ch);
switch(ch)
{
case 1:insertbeg();
break;
case 2:insertend();

break;
case 3:insertpos();

break;
case 4:delebeg();

break;
case 5:deleend();

break;
case 6:delepos();

break;
case 7:traverse();
break;
default:printf("enter thcorrect choice\n");
break;
}
}
}
void insertbeg()
{
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
ptr=head;
if(ptr==NULL)
{
new->next=NULL;
head=new;
}
else
{
new->next=NULL;
head=new;
}
}
void insertend()
{
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
ptr=head;
if(ptr==NULL)
{
new->next=NULL;
head=new;
}
else
{
while(ptr->next!=NULL)
{
ptr=ptr->next;
}
new->next=NULL;
ptr->next=new;
}
}
void insertpos()
{
int p;
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
printf("enter the position");
scanf("%d",&p);
ptr=head;
for(int i=1;i<p-1;i++)
{
ptr=ptr->next;
}
new->next=ptr->next;
ptr->next=new;
}
void delebeg()
{
ptr=head;
head=ptr->next;
free(ptr);
}
void deleend()
{
ptr=head;
while(ptr->next!=NULL)
{
ptr1=ptr;
ptr=ptr->next;
}
ptr1->next=NULL;
free(ptr);
}
void delepos()
{
int p;
printf("enter the position");
scanf("%d",&p);
ptr=head;
for(int i=1;i<p-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
ptr->next=ptr1->next;
}
void traverse()
{
ptr=head;
if(ptr==NULL)
{
printf("NO list");
}
while(ptr!=NULL)
{
printf("%d  ",ptr->data);
ptr=ptr->next;
}

printf("\n");
}

