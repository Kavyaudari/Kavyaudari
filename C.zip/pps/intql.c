#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*front=0,*rear=0,*ptr;
void eq()
{
new=malloc(sizeof(struct node));
new->next=0;
printf("enter the data");
scanf("%d",&new->data);
if(front==0&&rear==0)
{
front=rear=new;
}
else
{
rear->next=new;
rear=new;
}
}
void dq()
{
ptr=front;
if(front==0&&rear==0)
{
printf("null");
}
else if(front==rear)
{
printf("%d",rear->data);
free(ptr);
}
else
{
printf("%d",front->data);
front=front->next;
free(ptr);
}
}
void di()
{
ptr=front;
if(front==0&&rear==0)
printf("nulll");
else{
while(ptr->next!=0)
{
printf("%d",ptr->data);
ptr=ptr->next;
}
printf("%d",ptr->data);
}
}
void main()
{
int ch,x;
printf("\n1=eq\n2=dq\n3=di");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:eq();
break;
case 2:dq();
break;
case 3:di();
break;
default:printf("wrong");
break;
}
}
}


