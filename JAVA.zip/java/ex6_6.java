import java.util.*;
class vehicle
{
int vno;
int ino;
String color;
double fuel;
void set(int vno,int ino,String color)
{
this.vno=vno;
this.ino=ino;
this.color=color;
}
void getCons(double fuel)
{
this.fuel=fuel;
}
void displayCons()
{
System.out.println(fuel);
}
void display()
{
System.out.println(vno);
System.out.println(ino);
System.out.println(color);
}
}
class two extends vehicle
{
double mt;
double avg;
void get(double mt,double avg)
{
this.mt=mt;
this.avg=avg;
}
void maintain()
{
System.out.println(mt);
}
void average()
{
System.out.println(avg);
}
}
class geared extends two
{
String type;
String name;
geared(String type ,String name)
{
this.type=type;
this.name=name;
}
void gettype()
{
System.out.println(type);
}
void getname(){
System.out.println(name);
}
}
class nongeared extends two
{
String type;
String name;
nongeared(String type ,String name)
{
this.type=type;
this.name=name;
}
void gettype()
{
System.out.println(type);
}
void getname(){
System.out.println(name);
}
}
class ex6_6
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
two t1=new two();
int vno=in.nextInt();
int ino=in.nextInt();
String color=in.next();
double fuel=in.nextDouble();
t1.set(vno,ino,color);
t1.getCons(fuel);
t1.displayCons();
t1.display();
double mt=in.nextDouble();
double avg=in.nextDouble();
t1.get(mt,avg);
t1.maintain();
t1.average();
String type=in.next();
String name=in.next();
geared g1=new geared(type,name);
g1.gettype();
g1.getname();
String type1=in.next();
String name1=in.next();
nongeared g2=new nongeared(type1,name1);
g2.gettype();
g2.getname();
}
}





