#include<stdio.h>
#include<stdlib.h>
/*struct node
{
int data;
struct node *next;
}*head,*new,*ptr,*ptr1;
int read()
{
int a;
printf("enter the data\n");
scanf("%d",&a);
return a;
}
void insertbeg()
{
new=malloc(sizeof(struct node));
int a=read();
new->data=a;
ptr=head;
if(ptr==0)
{
new->next=0;
head=new;
}
else
{
new->next=ptr->next;
ptr=new;
}
}
void insertend()
{
new=malloc(sizeof(struct node));
int a=read();
new->data=a;
ptr=head;
if(ptr==0){
new->next=0;
head=new;
}
else
{
while(ptr!=0)
{
ptr=ptr->next;
}
new->next=0;
ptr->next=new;
}
}
void insertpos()
{
int a=read();
ptr=head;
int p,i;
new=malloc(sizeof(struct node));
new->data=a;
printf("enter the pos\n");
scanf("%d\n",&p);
for(i=1;i<p-1;i++)
{
ptr=ptr->next;
}
new->next=ptr->next;
ptr->next=new;
}
void deletebeg()
{
ptr=head;
head=ptr->next;
free(ptr);
}
void deleteend()
{
ptr=head;
while(ptr!=0){
ptr1=ptr;
ptr=ptr->next;
}
ptr1->next=0;
free(ptr);
}
void deletepos()
{
int p;
int i;
ptr=head;
printf("enter the pos\n");
scanf("%d\n",&p);
for(i=1;i<p-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
ptr->next=ptr1->next;
}
void traverse()
{
ptr=head;
if(ptr==0)
{
printf("no list\n");
}
while(ptr!=NULL)
{
printf("%d\n",ptr->data);
ptr=ptr->next;
}
}*/
int main()
{
int ch;
printf("enter the choice:\n1=insertbeg\n2=insertend\n3=insertpos\n4=deletebeg\n5=deleteend\n6=deletepos\n7=traverse");
while(ch!=8)
{
printf("enter the choice");

scanf("%d",&ch);
switch(ch)
{
case 1:insertbeg();
break;
case 2:traverse();

break;
case 3:insertend();

break;
case 4:insertpos();

break;
case 5:deletebeg();

break;
case 6:
deleteend();

break;
case 7:deletepos();

break;
default:printf("enter thcorrect choice\n");
break;
}
}
}
struct node
{
int data;
struct node *next;
}*head,*new,*ptr,*ptr1;
int read()
{
int a;
printf("enter the data\n");
scanf("%d",&a);
return a;
}
void insertbeg()
{
new=malloc(sizeof(struct node));
int a=read();
new->data=a;
ptr=head;
if(ptr==0)
{
new->next=0;
head=new;
}
else
{
new->next=ptr->next;
ptr=new;
}
}
void traverse()
{
ptr=head;
if(ptr==0)
{
printf("no list\n");
}
else
{
while(ptr!=0)
{
printf("%d\n",ptr->data);
ptr=ptr->next;
}
}
}
void insertend()
{
new=malloc(sizeof(struct node));
int a=read();
new->data=a;
ptr=head;
if(ptr==0){
new->next=0;
head=new;
}
else
{
while(ptr!=0)
{
ptr=ptr->next;
}
new->next=0;
ptr->next=new;
}
}
void insertpos()
{
int a=read();
ptr=head;
int p,i;
new=malloc(sizeof(struct node));
new->data=a;
printf("enter the pos\n");
scanf("%d\n",&p);
for(i=1;i<p-1;i++)
{
ptr=ptr->next;
}
new->next=ptr->next;
ptr->next=new;
}
void deletebeg()
{
ptr=head;
head=ptr->next;
free(ptr);
}
void deleteend()
{
ptr=head;
while(ptr!=0){
ptr1=ptr;
ptr=ptr->next;
}
ptr1->next=0;
free(ptr);
}
void deletepos()
{
int p;
int i;
ptr=head;
printf("enter the pos\n");
scanf("%d\n",&p);
for(i=1;i<p-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
ptr->next=ptr1->next;
}




