//palindrome
#include<stdio.h>
int main()
{
int num,rev=0,temp,r;
printf("enter the value if num");
scanf("%d",&num);
temp=num;
while(num>0)
{
r=num%10;
rev=(rev*10)+r;
num=num/10;
}
if(temp==rev)
printf("%d is a palindrome",temp);
else
printf("%d is not a palindrome",temp);
return 0;
}
