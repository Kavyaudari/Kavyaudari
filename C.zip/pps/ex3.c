#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*tail,*temp,*prev;
struct node *create()
{
new=malloc(sizeof(struct node));
int n;
printf("enter the data");
scanf("%d",&n);
if(n==-1)
return 0;
else
{
new->data=n;
}
}
void inbeg()
{
new=create();
if(tail==0)
{
tail=new;
tail->next=new;
}
else
{
new->next=tail->next;
tail->next=new;
}
}
void inend()
{
new=create();
if(tail==0)
{
tail=new;
tail->next=new;
}
else
{
new->next=tail->next;
tail->next=new;
tail=new;
}
}
void inpo()
{
temp=tail->next;
int p,i;
printf("enter the pos");
scanf("%d",&p);
new=create();
if(tail==0)
{
tail=new;
tail->next=new;
}
else
{
for(i=0;i<p-1;i++)
{
temp=temp->next;
}
new->next=temp->next;
temp->next=new;
}
}
void trav()
{
temp=tail->next;
if(tail==0)
printf("null");
else
{
do
{
printf("%d",temp->data);
temp=temp->next;
}while(temp!=tail->next);
}
}
void delbeg()
{
temp=tail->next;
if(tail==0)
printf("null");
else
{
tail->next=temp->next;
free(temp);
}
}
void delend()
{
temp=tail->next;
if(tail==0)
printf("null");
else
{
while(temp->next!=tail->next)
{
prev=temp;
temp=temp->next;
}
prev->next=tail->next;
tail=prev;
free(temp);
}
}
void delpo()
{
int p,i;
printf("enter the pos");
scanf("%d",&p);
temp=tail->next;
if(tail==0)
printf("null");
else
{
for(i=1;i,p-1;i++)
{
temp=temp->next;
}
prev=temp->next;
temp->next=prev->next;
}
}


void main()
{
int ch;
printf("\n1=beg\n2=end\n3=pos\n4=trav\n5=beg\n6=end\n7=pos");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:inbeg();
break;
case 2:inend();
break;
case 3:inpo();
break;
case 4:trav();
break;
case 5:delbeg();
break;
case 6:delend();
break;
case 7:delpo();
break;
default:printf("invalid");
break;
}
}
}
