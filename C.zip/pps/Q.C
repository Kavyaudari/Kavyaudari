#include<stdio.h>
#include<stdlib.h>
#define N 7;
int q[N];
int rear=-1;
int front=-1;
void enqueue(int ele)
{
if(rear>N-1)
{
printf("overflow");
}
else if(rear==-1)
{
front=0;
rear=0;
q[rear]=ele;
rear++;
}
else
{
q[rear]=ele;
rear++;
}
}
int dequeue()
{
if(front==-1&&rear==-1)
{
printf("underflow");
}
else if(front==rear)
{
printf("%d",q[front]);
front=rear=-1;
}
else
{
printf("%d",q[front]);
front++;
}
}
void display()
{
int i;
if(front==-1&&rear==-1)
{
printf("no elements to be printed");
}
else
{
for(i=front;i<=rear;i++)
{
printf("%d",q[front]);
}
}
}
int main()
{
int ch,ele;
printf("\n1enqueue\n2dequeue\n3display");
while(ch!=4)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the element");
scanf("%d",&ele);
enqueue(ele);
break;
case 2:dequeue();
break;
case 3:display();
break
default:printf("invalid");
break;
}
}
}




