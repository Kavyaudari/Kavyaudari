print("first program")
print("what to print")
print("print('what to print ')")

