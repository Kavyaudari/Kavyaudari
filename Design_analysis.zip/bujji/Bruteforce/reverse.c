#include<stdio.h>
#include<string.h>
int main()
{
char a[100];
char b[100];
printf("enter the string ");
scanf("%s",a);
printf("enter the substring ");
scanf("%s",b);
char r[100];
int n=strlen(b);
int m=strlen(a);
//reverse(b,n);
//printf("%s",b);

/*void reverse( char b[],int n)
{

int temp;
int i,j;
for( i=0,j=n-1;i<=j;i++,j--)
{
temp=b[i];
b[i]=b[j];
b[j]=temp;

}
//printf("%s",b);

}*/

int temp;
int i,j;
for( i=0,j=n-1;i<=j;i++,j--)
{
temp=b[i];
b[i]=b[j];
b[j]=temp;
}
printf("%s",b);

for(int i=0;i<=m-n;i++)
{
if(a[i]==b[0])
{
 int flag=0;
for(int j=0;j<n;j++)
{
if(b[j]!=a[i+j])
{
flag=1;
break;
}
}
if(flag==0)
{
printf("%d\n",i);
}
}
}
}




