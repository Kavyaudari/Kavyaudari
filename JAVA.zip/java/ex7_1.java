import java.util.*;
abstract class shape
{
abstract void area(int r,int a);
abstract void volume(int r ,int a);
}
class cal extends shape
{
public void area(int r,int a)
{
System.out.println("circle= " +(3.14*r*r));
System.out.println("surface area of cube = " +(6*a*a));
System.out.println("s a of sphere= " +(4*3.14*r*r));
}
public void volume(int r,int a)
{
System.out.println("cube = " +(a*a*a));
System.out.println("sphere= " +((4/3)*3.14*r*r*r));
}
}
class ex7_1
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int r=in.nextInt();
int a=in.nextInt();
shape s1=new cal();
s1.area(r,a);
s1.volume(r,a);
}
}

