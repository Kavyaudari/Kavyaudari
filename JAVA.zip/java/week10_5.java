class week10_5
{
public static void main(String args[])
{
System.out.println("hello");
try
{
String s="kavya";
int i=Integer.parseInt(s);
}
catch(Exception e)
{
System.out.println(e);
}
System.out.println("hello ");
}
}

