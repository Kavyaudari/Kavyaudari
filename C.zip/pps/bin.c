#include<stdio.h>
int binary(int[],int,int);
int main()
{
int n,i,j,k,t;
printf("enter array size\n");
scanf("%d",&n);
int a[n];
printf("enter array elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
for(j=i+1;j<n;j++)
{
if(a[i]>a[j])
{
t=a[i];
a[i]=a[j];
a[j]=t;
}
}
}
printf("elements after sorting");
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
printf("enter searching element");
scanf("%d",&k);
int b=binary(a,n,k);
if (b==-1)
{
printf("element not found");
}
else
{
printf("found at%d position",b);
}
return 0;
}
int binary(int a[],int n,int k)
{
int low=0,high=n-1,mid;
while(low<mid)
{
mid=high+low/2;
if(a[mid]==k)
{
return mid;
}
else if(k>a[mid])
{
low=mid+1;
}
else
{
high=mid-1;
}
return -1;
}
}

