//cricket
#include<stdio.h>
struct cricket
{
char name[20];
int score;
int sum;
}player[7];
int main()
{
int i;
int sum=0;
for(i=0;i<7;i++)
{
scanf(" %s %d",player[i].name,&player[i].score);
}
for(i=0;i<7;i++)
{
sum=sum+player[i].score;
}
printf("%d",sum);
}

