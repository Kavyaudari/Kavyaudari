//binary search
#include<stdio.h>
int main()
{
int a[100],num,n,i,first,midd,last;
printf("enter size\n");
scanf("%d",&n);
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("enter the element u want to seacrch");
scanf("%d",&num);
first=0;
last=n-1;
midd=(first+last)/2;
while(first<=last)
{
if(a[midd]<num)
{
first=midd+1;
}
else if(a[midd]==num)
{
printf("%d",midd);
break;
}
else
{
last=midd-1;
midd=(first+last)/2;
}
}
if(first>last)
{
printf("element naot found");
}
}
