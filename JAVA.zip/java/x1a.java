package kavya;
public class x1a
{
public void m1()
{
System.out.println("1st program ");
}
}

