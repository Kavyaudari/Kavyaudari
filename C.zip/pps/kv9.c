#include<stdio.h>
int main()
{
int n,i,j;
int k=1;
printf("enter the number");
scanf("%d",&n);
for(i=0;i<=n;i++)
{
for(j=0;j<=i;j++)
{
printf("%d",k++);
}
printf("\n");
}
}
