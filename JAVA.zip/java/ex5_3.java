/*class ex5_3
{
int age=23;
void change(int age)
{
age=age+10;
System.out.println(age);
}
public static void main(String args[])
{
ex5_3 e1=new ex5_3();
System.out.println(e1.age);
e1.change(10);
System.out.println(e1.age);
}
}*/
class ex5_3
{
int age=23;
void change(ex5_3 e1)
{
age=age+10;
System.out.println(age);
}
public static void main(String args[])
{
ex5_3 e1=new ex5_3();
System.out.println(e1.age);
e1.change(e1);
System.out.println(e1.age);
}
}
 
