#include<stdio.h>
#include<stdlib.h>
void merge(int a[],int,int,int);
void ms(int a[],int low,int high)
{
int mid;
if(low<high)
{
mid=(low+high)/2;
ms(a,low,mid);
ms(a,mid+1,high);
merge(a,low,mid,high);
}
}
void merge(int a[],int low,int mid ,int high)
{
int i,j,k;
i=low;
j=mid+1;k=low;
int b[30];
while(i<=mid&&j<=high)
{
if(a[i]<=a[j])
{
b[k]=a[i];
k++;
i++;
}
else
{
b[k]=a[j];
k++;
j++;
}
}
while(i<=mid)
{
b[k]=a[i];
k++;
i++;
}
while(j<=high)
{
b[k]=a[j];
k++;
j++;
}
for(k=low;k<=high;k++)
{
a[k]=b[k];
}
}
int main()
{
int n,i;
printf("enter the size");
scanf("%d",&n);
int a[n];
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
ms(a,0,n-1);
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
printf("\n");
}


