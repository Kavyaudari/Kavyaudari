//factorial
#include<stdio.h>
int fact(int);
int main()
{
int f=1,n;
printf("enter n value");
scanf("%d",&n);
f=fact(n);
printf("%d",f);
}
int fact(int x)
{
int y=1,i;
for(i=1;i<=x;i++)
{
y=y*i;
}
return(y);
}
