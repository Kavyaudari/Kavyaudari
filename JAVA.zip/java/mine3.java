class my extends Exception
{
private String str;
my(String str)
{
this.str=str;
}
void print()
{
System.out.println(str);
}
}
class mine3
{
public static void main(String args[])
{
try
{
throw new my("exception ");
}
catch(my e)
{
e.print();
}
}}

