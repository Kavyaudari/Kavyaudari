import java.util.*;
class roots
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the values of a,b,c for a qudratic equation");
int a,b,c;
a=in.nextInt();
b=in.nextInt();
c=in.nextInt();
int d;
d=b*b-4*a*c;
double r1;
double r2;
r1=(-b+(Math.sqrt(d))/(2*a));
r2=(-b-(Math.sqrt(d))/(2*a));
if(d==0)
{
System.out.println("roots are real and equal to zero");
System.out.println(r1);
System.out.println(r2);
}   
else if(d>0)
{
System.out.println("roots are real and distinct ");
System.out.println(r1);
System.out.println(r2);
}
else
{
System.out.println("roots are real and imaginary ");
System.out.println(r1);
System.out.println(r2);
}
}
}

