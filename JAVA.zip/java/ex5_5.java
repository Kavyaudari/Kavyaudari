/*class a
{
int x=20;
}
class b extends a
{
int x=45;
void display()
{
System.out.println(super.x);
System.out.println(x);
}
}
class ex5_5
{
public static void main(String args[])
{
b b1=new b();
b1.display();
}
}
*/
class ex5_5
{
static int a=57;
static void display()
{
System.out.println("static method ");
}
static 
{
System.out.println("static block");
}
public static void main(String args[])
{
System.out.println(ex5_5.a);
ex5_5.display();
}
}


