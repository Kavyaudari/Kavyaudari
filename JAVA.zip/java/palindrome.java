import java.util.*;
class palindrome
{
public static void main(String args[])
{
System.out.println("enter the number");
Scanner in=new Scanner(System.in);
int a=in.nextInt();
int temp=a;
int sum=0;
while(a>0)
{
sum=sum*10;
int rem=a%10;
sum=rem+sum;
a=a/10;
}
if(temp==sum)
{
System.out.println("palindrome "+sum);
}
else
{
System.out.println("not a palindrome "+sum);
}
}
}


