import java.util.*;
interface studfee
{
void getAmount(int clgfee);
void getFname(String fname);
void getLname(String lname);
void getAddress(String address);
void getContact(int contact);
}
class hosteler implements studfee
{
public void getAmount(int clgfee)
{
int hfee=5000;
System.out.println("fee= " +(hfee+clgfee));
}
public void getFname(String fname)
{
System.out.println("name= " +fname);
}
public void getLname(String lname)
{
System.out.println(lname);
}
public void getAddress(String address)
{
System.out.println(address);
}
public void getContact(int n)
{
System.out.println(n);
}
}
class nonhostel implements studfee
{
public void getAmount(int clgfee)
{
//int hfee=5000;
System.out.println("fee= " +(clgfee));
}
public void getFname(String fname)
{
System.out.println("name= " +fname);
}
public void getLname(String lname)
{
System.out.println(lname);
}
public void getAddress(String address)
{
System.out.println(address);
}
public void getContact(int n)
{
System.out.println(n);
}
}
class ex7_6
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int clgfee=in.nextInt();
String fname=in.next();
String lname=in.next();
String address=in.next();
int contact=in.nextInt();
studfee h1=new hosteler();
h1.getAmount(clgfee);
h1.getFname(fname);
h1.getLname(lname);
h1.getAddress(address);
h1.getContact(contact);
int clgfee1=in.nextInt();
String fname1=in.next();
String lname1=in.next();
String address1=in.next();
int contact1=in.nextInt();
studfee h2=new nonhostel();
h2.getAmount(clgfee1);
h2.getFname(fname1);
h2.getLname(lname1);
h2.getAddress(address1);
h2.getContact(contact1);
}
}

