import java.util.*;
class duplicates
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int a[]=new int[3];
for(int i=0;i<3;i++)
{
System.out.println("enter ele ");
int e=in.nextInt();
int c=0;
for(int j=0;j<3;j++)
{
if(e==a[j])
{
System.out.println("already there ");
c=1;
i=i-1;
break;
}
else if(e<10||e>100)
{
System.out.println("not in range ");
c=1;
i=i-1;break;
}
}
if(c==0)
{
a[i]=e;
for(int k=0;k<=i;k++)
{
System.out.println(a[k]);
}
}
}
}
}
