import java.util.*;
class a
{
void display()
{
Scanner in =new Scanner(System.in);
System.out.println("enter the numners ");
int a=in.nextInt();
int b=in.nextInt();
try{

int c=a/b;
System.out.println(c);
}
catch(ArithmeticException e)
{
System.out.println(e);//
System.out.println(e.getMessage());
}
}
}
class arith_exception
{
public static void main(String args[])
{
a a1=new a();
a1.display();
}
}

