package shape;
public class circ
{
public void area(double r)
{
System.out.println(3.14*r*r);
}
public void perimeter(double d)
{
System.out.println(2*3.14*d);
}
}
