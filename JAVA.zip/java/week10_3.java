class week10_3
{
public static void main(String args[])
{
try
{
one();
}
catch(Exception e)
{
System.out.println("Exception caught in main");
}
}
}
public void one() throws Exception
{
try
{
two();
}
catch(Exception e)
{
System.out.println("Exception caught by one ");
throw e;
}
}
static void two() throws Exception
{
throw new Exception("exception thrown in two ");
}

