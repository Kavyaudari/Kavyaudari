#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next,*prev;
}*new,*ptr,*ptr1,*ptr2,*head;
struct node *create()
{
int n;
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&n);
if(n==-1)
return 0;
else
{
new->data=n;
}
}
void insbeg()
{
ptr=head;
new=create();
if(ptr==0)
{
new->next=0;
new->prev=0;
head=new;
}
else
{
new->next=ptr;
new->prev=0;
ptr->prev=new;
head=new;
}
}
void insend()
{
ptr=head;
new=create();
if(ptr==0)
{
new->next=0;
new->prev=0;
head=new;
}
else
{
while(ptr->next!=0)
{
ptr=ptr->next;
}
ptr->next=new;
new->prev=ptr;
new->next=0;
}
}
void inspos()
{
ptr=head;
new=create();
int p,i;
printf("enter the pos ");
scanf("%d",&p);
if(ptr==0)
{
new->next==0;
new->prev==0;
head=new;
}
else
{
for(i=0;i<p-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
new->next=ptr1;
ptr1->prev=new;
new->prev=ptr;
ptr->next=new;
}
}
void traverse()
{
ptr=head;
if(ptr==0)
printf("null");
else
{
while(ptr!=0)
{
printf("%d",ptr->data);
ptr=ptr->next;
}
}
}
void delbeg()
{
ptr=head;
if(ptr==0)
printf("null");
else
{
ptr1=ptr->next;
ptr1->prev=0;
head=ptr1;
free(ptr);
}
}
void delend()
{
ptr=head;
if(ptr==0)
{
printf("null");
}
else
{
while(ptr->next!=0)
{
ptr1=ptr;
ptr=ptr->next;
}
ptr1->next=0;
ptr->prev=0;
free(ptr);
}
}
void delpos()
{
ptr=head;
int p,i;
printf("enter the pos");
scanf("%d",&p);
if(ptr==0)
{
printf("null");
}
else
{
for(i=0;i<p-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
ptr2=ptr1->next;
ptr->next=ptr2;
ptr2->prev=ptr;
free(ptr1);
}
}


void main()
{
int ch;
printf("\n1=beg\n2=end\n3=pos\n4=tra\n5=beg\n6=end\n7=pos");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:insbeg();
break;
case 2:insend();
break;
case 3:inspos();
break;
case 4:traverse();
break;
case 5:delbeg();
break;
case 6:delend();
break;
case 7:delpos();
break;
default:printf("wrong");
break;
}
}
}
