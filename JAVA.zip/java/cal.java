//polymorphism
import java.util.*;
//static=having same function name performing multiple actions (method overloading)
class cal
{
int add(int a,int b)
{
return(a+b);
}
float add(int a,float b)
{
return(a+b);
}
int add(int a, int b,int c)
{
return(a+b+c);
}
double add(double a,int b)
{
return(a+b);
}
class test
{
public static void main(String args[])
{
int a,b,c;
cal c1=new cal();
system.out.println("enter the values");
Scanner in=new Scanner(System.in);
a=in.nextInt();
b=in.nextInt();
c=in.nextInt();
system.out.println(a,b,c);
system.out.println(3.2,8);
system.out.println(3,8,7);
}
}
//dynamic=method overriding ->child always over riding the parent class
