//sum of a no
#include<stdio.h>
int main()
{
int n,s=0,r;
printf("n value");
scanf("%d",&n);
while(n>0)
{
r=n%10;
s=s+r;
n=n/10;
}
printf("%d",s);
}
