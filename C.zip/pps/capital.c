//converting capital to small and vice versa
#include<stdio.h>
int main()
{
char c;
printf("enter the value of c:");
scanf("%c",&c);
if(c>='A'&& c<='Z'){
c=c+32;
printf("after convert %c",c);
}
else if(c>='a'&&c<='z'){
c=c-32;
printf("after convert %c",c);
}
return 0;
}
