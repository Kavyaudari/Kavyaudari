//secondlargest
#include<stdio.h>
int main()
{
int a[50],n,i=0,l1,l2,t;
printf("enter the size");
scanf("%d",&n);
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
printf("%d",a[i]);
printf("\n");
l1=a[0];
l2=a[1];
if(l1<l2)
{
t=l1;
l1=l2;
l2=t;
}
}
for(i=0;i<n;i++)
{
if(a[i]>l1)
{
l2=l1;
l1=a[i];
}
else if(a[i]>l2&&a[i]!=l1)
{
l2=a[i];
}
}
printf("the second largest=%d",l2);
}
