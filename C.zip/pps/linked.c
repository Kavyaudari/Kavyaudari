#include<stdio.h>
#include<stdlib.h>
//#include<conio.h>
#include<malloc.h>
struct node
{
int data;
struct node*next;
};
struct node*strat=NULL;
struct node*create(struct node*);
struct node*display(struct node*);
int main(int argc,char *argv[])
{
int option;
do
{
printf("\n\n********MAIN MENU**********");
printf("\n 1:create a list");
printf("\n 2:Display the list");
printf("\n 3: EXIT");
printf("enter the option");
scanf("%d",&option);
switch(option)
{
case1:start=create(start);
printf("created");
break;
case2:start=display(start);
break;
}
}
while(option!=13);
getch();
return 0;
}
struct node *create(struct node *start)
{
struct node *new_node, *ptr;
int num;
printf("enter -1 to end");
printf("\n enter the data:");
scanf("%d",&num);
while(num!=-1)
{
new_node=(struct node*)malloc(sizeof(struct node));
new_node->data=num;
if(start==NULL)
{
new_node->next =NULL;
start=new_node;
}
else 
{
ptr=start;
while(ptr->next!=NULL)
ptr=ptr->next;
ptr->next=new_node;
new_node->next=NULL;
}
printf("enter the data");
scanf("%d",&num);
}
return start;
}
struct node *display(struct node *start)
{
struct node *ptr;
ptr =start;
while(ptr!=NULL)
{
printf("\t %d ",ptr->data);
ptr=ptr->next;
}
return start;
}

