import calculator.add;
import calculator.sub;
import calculator.mult;
import calculator.div;
import java.util.*;
public class week8_4
{
public static void main(String args[])
{
System.out.println("enter the values");
Scanner in=new Scanner(System.in);
add a1=new add();
sub s=new sub();
mult m=new mult();
div d=new div();
int a=in.nextInt();
int b=in.nextInt();
a1.set(a1.a,a1.b);
a1.display();
s.set(s.a,s.b);
s.display();
m.set(m.a,m.b);
m.display();
d.set(d.a,d.b);
d.display();
}
}

