import java.util.*;
class AREA
{
void area(double r)
{
System.out.println("area= " +(3.14*r*r));
}
void area(float x,float y)
{
System.out.println("area= " +(0.5*x*y));
}
void area(int l,int b)
{
System.out.println("area= " +(l*b));
}
}
class ex6_1
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
double r=in.nextDouble();
float x=in.nextFloat();
float y=in.nextFloat();
int l=in.nextInt();
int b=in.nextInt();
AREA a=new AREA();
a.area(r);
a.area(x,y);
a.area(l,b);
}
}


