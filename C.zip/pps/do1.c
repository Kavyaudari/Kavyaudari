//do while
//tables20
#include<stdio.h>
int main()
{
int n,i;
n=1;
do
{
i=1;
do
{
printf("%d*%d=%d\n",n,i,n*i);
i++;
}
while(i<=10);
n++;
}
while(n<=20);
}
