//perfect number
#include<stdio.h>
int main()
{
int n,i,j,sum;
printf("enter a number");
scanf("%d",&n);
printf("all perfect numbers between 1 to %d:\n",n);
for(i=1;i<=n;i++)
{
sum=0;
for(j=1;j<i;j++)
{
if(i%j==0)
{
sum=sum+j;
}
}
if(sum==i)
{
printf("%d\n",i);
}
}
}
