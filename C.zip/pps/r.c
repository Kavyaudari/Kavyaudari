//sp and cp
#include<stdio.h>
#include<math.h>
int main()
{
int p,t,r;
float sp,cp;
printf("values");
scanf("%d%d%d",&p,&t,&r);
sp=(p*t*r)/100;
cp=p*(pow(1+r/100,t));
printf("%f %f ",sp,cp);
}
