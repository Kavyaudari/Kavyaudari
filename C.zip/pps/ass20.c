/*electricity unit charges
for first 50units Rs.0.50/unit
for next 100units Rs.0.75/unit
for next 100units Rs 1.20/unit
for unit above  250units Rs 1.50/unit
additional surcharge of 20% is added to the bill
*/
#include<stdio.h>
int main()
{
int units;
float amount,total amount,surcharge;
printf("total units");
scanf("%d",&units);
if(unit<=50)
{
amount=unit*0.50;
}
else if(unit<=100)
{
amount=25

