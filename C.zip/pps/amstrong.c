//amstrong
#include<stdio.h>
#include<math.h>
int main()
{
int n,s=0,r,i;
printf("enter the value of n,i");
scanf("%d%d",&n,&i);
int t=n;
do
{
r=n%10;
s=s+pow(r,i);
n=n/10;
}
while(n>0);
printf("%d\t",s);
if(t==s)
{
printf("amstrong");
}
else{
printf("not amstrong");
}
return 0;
}
