/*Create an Interface StudentFee with method getAmount() ,getFirstName()
,getLastName(), getAddress(), getContact(). Calculate the amount paid by the
Hostler and NonHostler student b*/
import java.util.*;
interface sfee
{
void getAmount(int clgfee);
void getFirstname(String fname);
void getLastname(String lname);
void getAddress(String address);
void getContact(int contact);
}
class hostel implements sfee
{
public void getAmount(int clgfee)
{
System.out.println("enter the hostel fee ");
int hfee=in.nextInt();
System.out.println("the total fee payed by hosteler = " +(hfee+clgfee));
}
public void getFirstname(String fname)
{
System.out.println("the name = " +fname);
}
public void getLastname(String lname)
{
System.out.println("the lname = "+lname);
}
public void getAddress(String address)
{
System.out.println("the addess= " +address);
}
public void getContact(int contact)
{
System.out.println("the contact = "+contact);
}
}
class w7
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the details ");
int clgfee=in.nextInt();
String fname=in.next();
String lname=in.next();
String address=in.next();
int contact=in.nextInt();
sfee s1=new hostel();
s1.getAmount(clgfee);
s1.getFirstname(fname);
s1.getLastname(lname);
s1.getAddress(address);
s1.getContact(contact);
}
}


