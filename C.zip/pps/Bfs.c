#include<stdio.h>
# define max 5
int front=-1,rear=-1,queue[5];
void bfs(int[][max],int[]);
void enqueue(int);
int dequeue();
int main()
{
int graph[max][max],i,j;
int visited[max]={0};
printf("enter the  adjacent matrix");
for(i=0;i<max;i++)
{
for(j=0;j<max;j++)
{
scanf("%d",&graph[i][j]);
}
}
for(i=0;i<max;i++)
{
for(j=0;j<max;j++)
{
printf("%d ",graph[i][j]);
}
printf("\n");
}
bfs(graph,visited);

}
void bfs(int graph[][max],int visited[])
{
front=rear=0;
enqueue(0);
visited[0]=1;
while(front!=rear)
{
int current=queue[front];
printf("%d",queue[front]);
dequeue();
for(int i=0;i<max;i++)
{
if(graph[current][i]==1&& visited[i]==0)
{
enqueue(i);
visited[i]=1;
}
}
}
}
void enqueue(int ele)
{
queue[rear]=ele;
rear++;
}
int dequeue()
{
int ele;
ele=queue[front];
front++;
return(ele);
}

