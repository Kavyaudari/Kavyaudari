//sprintf
#include<stdio.h>
int main()
{
int a=10,b=20;
char ch[50];
sprintf(ch,"%d%d",&a,&b);
printf("%s",ch);
return 0;
}
