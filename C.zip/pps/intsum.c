//sum of first n natural numbers
#include<stdio.h>
int main()
{
int n,sum;
printf("enter value");
scanf("%d",&n);
sum=(n*(n+1))/2;
printf("sum =%d",sum);
}
