import java.util.*;
class Binarysearch
{
public static void main(String arg[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the array size");
int n=in.nextInt();
int[] array=new int[n];
for(int i=0;i<n;i++)
{
array[i]=in.nextInt();
}
test obj=new test();
obj.sort(array,n);
obj.search(array,n);
}
}
class test
{
void sort(int array[],int n)
{
int temp;
for(int i=0;i<n;i++)
{
for(int j=0;j<n;j++)
{
if(array[i]<array[j])
{
temp=array[i];
array[i]=array[j];
array[j]=temp;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(array[i]+"\t");
}
}
void search(int array[],int n)
{
System.out.println("enter the num");
Scanner in=new Scanner(System.in);
int x=in.nextInt();
int f=0;//first
int l=n-1;//last
int m=(f+l)/2;//middle
while(f<=l)
{
if(array[m]<x)
f=m+1;
else if(array[m]==x){
System.out.println("found"+x);
break;
}
else
l=m-1;
m=(f+l)/2;

}
if(f>l)
{
System.out.println("not found");
}
}
}
