//ascending order
#include<stdio.h>
int main()
{
int a,b,c,f,d;
printf("enter the value of a,b,c);
scanf("%d%d%d",&a,&b,&c);
if(a
