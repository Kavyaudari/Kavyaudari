//fabinaci series
#include<stdio.h>
int main()
{
int a,b,c,n,i;
printf("enter the a,b values");
scanf("%d%d",&a,&b);
printf("enter the n value");
scanf("%d",&n);
for(i=0;i<n;i++)
{
if(i<=1)
{
c=i;
}
else
{
c=a+b;
a=b;
b=c;
}
printf("%d\t",c);
}
}
