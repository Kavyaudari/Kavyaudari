#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*tail,*new,*temp,*prev;
struct node *create()
{
int n;
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&n);
if(n==-1)
{
return 0;
}
else
{
new->data=n;
new->next=0;
}
}
void inbeg()
{
new=create();
if(tail==0)
{
tail=new;
tail->next=new;
}
else
{
new->next=tail->next;
tail->next=new;
}
}
void inend()
{
temp=tail->next;
new=create();
if(tail==0)
{
tail=new;
tail->next=new;
}
else
{
new->next=tail->next;
tail->next=new;

tail=new;}
}
void inp()
{
int p,i;
temp=tail->next;
new=create();
printf("enter the pos");
scanf("%d",&p);
if(tail==0)
{
tail=new;
tail->next=new;
}
else
{
for(i=1;i<p-1;i++)
{
temp=temp->next;
}
new->next=temp->next;
temp->next=new;
}
}
void tra()
{
temp=tail->next;
do
{
printf("%d",temp->data);
temp=temp->next;
}while(temp!=tail->next);
}
void dbeg()
{
temp=tail->next;
if(tail==0)
printf("null");
else if(temp->next==temp)
{
free(temp);
}
else
{
tail->next=temp->next;
free(temp);
}
}
void dend()
{
temp=tail->next;
if(tail==0)
printf("null");
else if(temp->next==temp)
{
free(temp);
}
else
{
while(temp->next!=tail->next)
{
prev=temp;
temp=temp->next;
}
prev->next=tail->next;
tail=prev;
free(temp);
}
}
void dpos()
{
temp=tail->next;
int p,i;
printf("enter po");
scanf("%d",&p);
if(tail==0)
printf("null");
else if(temp->next==temp)
{
free(temp);
}
else
{
for(i=1;i<p-1;i++)
{
temp=temp->next;
}
prev=temp->next;
temp->next=prev->next;
}
}
void main()
{
int ch;
printf("\n1=b\n2=e\n3=p\n4t\n5=b\n6=e\n7=p");
while(ch!=-1)
{
printf("enter ch");
scanf("%d",&ch);
switch(ch)
{
case 1:inbeg();
break;
case 2:inend();
break;
case 3:inp();
break;
case 4:tra();
break;
case 5:dbeg();
break;
case 6:dend();
break;
case 7:dpos();break;
default:printf("wrong");
break;
}
}
}
