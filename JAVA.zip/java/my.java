package cse;
public class my
{
public void display()
{
System.out.println("my class ");
}
}

