//pointer arithematic
#include<stdio.h>
int main()
{
int a;
printf("enter the elements of a ");
scanf("%d",&a);
int * p=&a;
p=p+1;
printf("%d",*p);
}
