import java.util.*;
class ex4_6
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter str");
String s=in.next();
int a=s.length();
System.out.println(a);
}
}
