//square and cube
#include<stdio.h>
int main()
{
int n,sq,c;
printf("enter the value of n");
scanf("%d",&n);
sq=n*n;
c=n*n*n;
printf("square of the n=%d\n",sq);
printf("cube of the n=%d\n",c);
return 0;
}
