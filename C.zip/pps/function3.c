//with arguments without returntype
#include<stdio.h>
#include<math.h>
void p(int,int);
void main()
{
int x,y,z;
printf("enter x,y values");
scanf("%d%d",&x,&y);
z= p(x,y);
}
void p(int a,int b)
{ 
int c;
c=pow(a,b);
printf("%d",c);
}
