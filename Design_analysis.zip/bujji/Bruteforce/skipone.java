class test{
    public static void main(String args[])
    {
        String str1;
        String str2;
        Scanner in=new Scanner(System.in);
        
        System.out.println(" enter str1");
        str1=in.nextLine();
        System.out.println("str2");
        str2=in.nextLine();
        int c=0;
        int m=str1.length();
        int n=str2.length();
        for(int i=0;i<=m-n;i++)
        {
            if(str1.charAt(i)==str2.charAt(0))
            {
                int flag=0;
                for(int j=0;j<n;j++)
                {
                    if(str2.charAt(j)!=str1.charAt(i+(j*2)))
                    {
                        flag=1;
                        break;
                    }
                }
                if(flag==0)
                {
                    c++;
                }
            }
        }
        System.out.println(c);

        
    }
};

