//positon of num
#include<stdio.h>
int main()
{
int a[50],n,num,i,j,flag=0,index;
printf("enter size");
scanf("%d",&n);
printf("enter the elments");
for(i=0;i<n;i++)
{
scanf("%d",&n);
}
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}printf("\n");
printf("enter num");
scanf("%d",&num);
for(i=0;i!=num;i++)
{
if(a[i]==num)
{
index=i;
flag=1;
break;
}
}
if(flag==1)
{
printf("%d",index);
}
else
printf("not present");
}

