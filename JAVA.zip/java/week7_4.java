import java.util.*;
interface vehicle
{
void getColor(String c);
void getNumber(int n);
void getConsumption(int l,int fuelcost);
}
class two implements vehicle
{
public void getColor(String c)
{
System.out.println("thoe color of two wheeler = " +c);
}
public void getNumber(int n)
{
System.out.println("the no of two wheeler = "+n);
}
public void getConsumption(int l,int fuelcost)
{
System.out.println("the consumption = " +(l*fuelcost));
}
}
class four implements vehicle
{
public void getColor(String c)
{
System.out.println("thoe color of two wheeler = " +c);
}
public void getNumber(int n)
{
System.out.println("the no of two wheeler = "+n);
}
public void getConsumption(int l,int fuelcost)
{
System.out.println("the consumption = " +(l*fuelcost));
}
}
class week7_4
{
public static void main(String args[])
{
vehicle v1=new two();
Scanner in=new Scanner(System.in);
System.out.println("enter he details of two ");
String c1=in.next();
int n1=in.nextInt();
int l1=in.nextInt();
int fuelcost1=in.nextInt();
v1.getColor(c1);
v1.getNumber(n1);
v1.getConsumption(l1,fuelcost1);
vehicle v2=new four();
System.out.println("enter he details of four ");
String c2=in.next();
int n2=in.nextInt();
int l2=in.nextInt();
int fuelcost2=in.nextInt();
v2.getColor(c2);
v2.getNumber(n2);
v2.getConsumption(l2,fuelcost2);
}
}

