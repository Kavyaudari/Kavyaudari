//constructor
import java.util.*;
/*default constructor
class student
{
student()
{
System.out.println("kavya");
}
public static void main(String args[])
{
student s=new student();
}
}*/
/*parameterised =giving parameters
class student
{
int id ,marks;
String name;
student(int i,int m,String n)
{
id=i;
marks=m;
name=n;
}
void display()
{
System.out.println(id+" "+marks+" "+name);
}
public static void main(String args[])
{
student s1=new student(1044,98,"kavya");
s1.display();
int a,b;
String c;
System.out.println("enter data from user");
Scanner in=new Scanner(System.in);
a=in.nextInt();
b=in.nextInt();
c=in.next();
student s2=new student(a,b,c);
s2.display();
}
}*/
//constructor overloading=same con with diff no of aggruments can be createdin same class
class student
{
int id;
int marks;
String name;
student()
{
id=1044;
marks=98;
name="kavya";
}
student(int x)
{
id=x;
}
student(int x,int y,String z)
{
id=x;
marks=y;
name=z;
}
void display()
{
System.out.println(id+" "+marks+" "+name);
}
public static void main(String args[])
{
student s1=new student();
student s2=new student(456);
student s3=new student(56,87,"happy");
s1.display();
s2.display();
s3.display();
}
}
