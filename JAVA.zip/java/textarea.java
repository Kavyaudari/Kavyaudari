/*import java.awt.*;
class MyFrame extends Frame
{
TextArea ta;
TextField tf;
Label l;
Button b;
MyFrame()
{
super("text area Demo ");
l=new Label("			");
ta=new TextArea(10,30);
tf=new TextField(10);
b=new Button("click ");
add(ta);
//add(tf);
//add(l);
//add(b);
}
}
public class textarea
{
public static void main(String args[])
{
MyFrame f=new MyFrame();
f.setSize(500,500);
f.setVisible(true);
}
}
import java.awt.*;
class MyFrame extends Frame
{
TextArea ta;
TextField tf;
Label l;
Button b;
MyFrame()
{
super("text area Demo ");
l=new Label("			");
ta=new TextArea(10,30);
tf=new TextField(10);
b=new Button("click ");
setLayout(new FlowLayout());
add(ta);
add(tf);
add(l);
add(b);
}
}
public class textarea
{
public static void main(String args[])
{
MyFrame f=new MyFrame();
f.setSize(500,500);
f.setVisible(true);
}
}
*/
import java.awt.*;
class MyFrame extends Frame
{
TextArea ta;
TextField tf;
Label l;
Button b;
MyFrame()
{
super("text area Demo ");
l=new Label("			");
ta=new TextArea(10,30);
tf=new TextField(10);
b=new Button("click ");
setLayout(new FlowLayout());
add(ta);
add(tf);
add(l);
add(b);
b.addActionListener(this);
}
public void actionPerformed(ActionEvent ae)
{
l.setText(ta.getSelectedText());
}
}
public class textarea
{
public static void main(String args[])
{
MyFrame f=new MyFrame();
f.setSize(500,500);
f.setVisible(true);
}
}
