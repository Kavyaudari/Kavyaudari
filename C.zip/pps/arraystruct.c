//structures
#include<stdio.h>
struct std
{
int id;
int marks;
int name;
};
int main()
{
int i;
struct std s[5];
for(i=0;i<5;i++)
{
printf("enter the details\n");
scanf("%d %d %s\n",&s[i].id,&s[i].marks,s[i].name);
}
for(i=0;i<5;i++)
{
printf("details of std=%d\n",i+1);
}
}
