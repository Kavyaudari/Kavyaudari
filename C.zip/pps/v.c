#include<stdio.h>
int binary(int[],int,int);
int main()
{
int k,t,i,j,n;
printf("enter array size:\n");
scanf("%d",&n);
int ar[n];
printf("enter array elements");
for(i=0;i<n;i++)
{
scanf("%d",&ar[i]);
}
for(i=0;i<n;i++)
{
for(j=i+1;j<n;j++)
{
if(ar[i]>ar[j])
{
t=ar[i];
ar[i]=ar[j];
ar[j]=t;
}
}
}
printf("after sorting");
for(i=0;i<n;i++)
{
printf("%d\n",ar[i]);
}
printf("enter searching element");
scanf("%d",&k);
int b=binary(ar,n,k);
if(b==-1)
{
printf("element not found");
}
else
{
printf("element found at %d",b);
}
return 0;
}
int binary(int ar[],int n,int k)
{
int low=0,high=n-1,mid;
while(low<=high)
{
mid=low+high/2;
if(ar[mid]==k)
{
return mid;
}
else if(k>ar[mid])
{
low=mid+1;
}
else
{
high=mid-1;
return -1;
/*printf("element not found");*/
}
}
}

