import bunny.A1;
public class nithya
{
public static void main(String args[])
{
A1 a1=new A1();
a1.display();
}
}

