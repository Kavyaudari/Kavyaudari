//binary tree program
#include<stdio.h>
#define MAX 100
int bt[max],i=0;
insert node(int n)
{
if(i>MAX-1)
{
printf("memroy is full");
}
bt[i]=n;
i++;
}
void main()
{
 insert node(1);
 insert node(2);
 insert node(3);
  insert node(4);
  insert node(5);
  insert node(6);
  inorder(0);
  }
  getleftchild index(int i)
  {
  return(2*i+1);
  }
  getrightchild index(int i)
  {
  return(2*i+2)
  }
  inorder(int index)
  {
  if(index<i)
  {
  inorder(getleftchild index(index));
  printf("%d",bt(index));
  inorder(getrightchild index(index));
  }
  }
  
