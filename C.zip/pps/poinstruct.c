//pointer structers
#include<stdio.h>
struct book
{
char name[20];
char author[20];
int pages;
};
int main()
{
struct book b1={"u","kavya",8777};
struct book *p;
p=&b1;
printf("%s %s %d",p->name,p->author,p->pages);
}
