#include<stdio.h>
#include<stdlib.h>
#define max 20
int q[max];
int front=-1,rear=-1;
void enqueue(int);
int dequeue();
void display();
void enqueue(int ele)
{
if(front==-1&&rear==-1)
{
front=rear=0;
q[rear]=ele;
}
else if(rear>max-1)
{
printf("overflow");
}
else
{
rear++;
q[rear]=ele;
}
}
int dequeue()
{
if(front==-1&&rear==-1)
printf("underflow");
else
{
printf("%d deleted",q[front]);
front++;
}
}
void display()
{
if(front==-1&&rear==-1)
printf("underflow");
else
{
while(front!=rear)
{
printf("%d",q[front]);
front++;
}
printf("%d",q[rear]);
}
}
int main()
{
int ch,ele;
printf("\n1=en\n2=de\n3=dis\n");
while(ch!=-1)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the ele");
scanf("%d",&ele);
enqueue(ele);
break;
case 2:dequeue();
break;
case 3:display();
break;
default:printf("wrong");
break;
}
}
}
