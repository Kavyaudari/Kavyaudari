//binary tree implementation and traversal
#include<stdio.h>
#include<stdlib.h>
#define MAX 100
struct node
{
int data;
struct node *left ,*right;
};
struct node *create()
{
int x;
struct node *newnode;
newnode=(struct node *)malloc(sizeof(struct node));
printf("enter the DATA");
scanf("%d" ,&x);
if(x==-1)
{
return NULL;
}
newnode->data=x;
printf("enter the left child of %d ",x);
newnode->left=create();
printf("enter the right child of %d ",x);
newnode->right=create();
return newnode;
} 
//preorder 
void preorder(struct node *root)
{
if(root==0)
return ;
else
{
printf("%d",root->data);
preorder(root->left);//subtrees
preorder(root->right);
}
}
void inorder(struct node *root)
{
if(root==0)
return;
else
{
inorder(root->left);
printf("%d",root->data);
inorder(root->right);
}
}
void postorder(struct node *root)
{
if(root==0)
return;
postorder(root->left);
postorder(root->right);
printf("%d",root->data);
}
void main()
{
struct node *root;
root=0;
root=create();
printf("preorder is  \n");
preorder(root);
printf("inorder is  \n");
inorder(root);
printf("postorder is  \n");
postorder(root);
}

