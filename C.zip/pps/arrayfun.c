//passing arrays in functions
#include<stdio.h>
int large(int[],int);
int main()
{
int n,l,i;
printf("enter the size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
l=large(a,n);
printf("%d",l);
}
int large(int b[],int x)
{
int max=b[0],i;
for(i=0;i<x;i++)
{
if(max<b[i])
{
max=b[i];
}
}
return(max);
}
