package calci;
public class cal3
{
public void add(int a,int b)
{
System.out.println(a+b);
}
public void sub(int a,int b)
{
System.out.println(a-b);
}
public void mult(int a,int b)
{
System.out.println(a*b);
}
public void div(int a,int b)
{
System.out.println(a/b);
}
public void mod(int a,int b)
{
System.out.println(a%b);
}
}

