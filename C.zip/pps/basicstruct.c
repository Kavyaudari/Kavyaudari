//basic progrms
#include<stdio.h>
struct book
{
char name[20];
char author[20];
int page;
};
int main()
{
struct book b1={"u","kavya",98};
printf("%s %s %d ",b1.name,b1.author,b1.page);
}

