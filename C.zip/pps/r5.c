//vowel or not
#include<stdio.h>
int main()
{
char a;
printf("enter ");
scanf("%c",&a);
if(a=='a'||a=='i'||a=='o'||a=='u')
{
printf("vowel");
}
else printf("not a vowel");
}
