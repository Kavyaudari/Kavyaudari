import java.util.*;
class value
{
int a;int b;
void add1(int a,int b)
{
System.out.println("value");
System.out.println(a+b);
}
}
class object{
void add2(value v)
{
System.out.println("object");
System.out.println(v.a+v.b);
}
}
class week5_value
{
public static void main(String args[])
{
System.out.println("enter");
Scanner in=new Scanner(System.in);
value v=new value();
object o=new object();
v.a=in.nextInt();
v.b=in.nextInt();
v.add1(v.a,v.b);
o.add2(v);
}
}

