package org.shapes;
import java.util.*;
public class rectangle
{
public int l,b;
public void set(int l,int b)
{
this.l=l;
this.b=b;
}
public void kavya()
{
System.out.println("area"+l*b);
}
}

