//functions
//with arguments and with return type
#include<stdio.h>
int fact(int,int );
int main()
{
int a,b,c;
printf("enter values");
scanf("%d%d",&a,&b);
c=fact(a,b);
printf("%d",c);
}
int fact(int x,int y)
{
int z;
z=x*y;
return z;
}
