//profit or loss
#include<stdio.h>
int main()
{
int cp,sp,gain,loss;
printf("enter the values");
scanf("%d%d",&cp,&sp);
if(cp<sp)
{
gain=sp-cp;
printf("%d is your gain",gain);
}
else if(cp>sp)
{
loss=cp-sp;
printf("%d is your loss",loss);
}
else
{
printf("no gain or no loss");
}
return 0;
}
