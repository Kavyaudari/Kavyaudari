import java.util.*;
class Roots
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the value of a");
double a=in.nextDouble();
System.out.println("enter the value of b");
double b=in.nextDouble();
System.out.println("enter the value of c");
double c=in.nextDouble();
double d;
d=b*b-4.0*a*c;
if(d>0.0)
{
double r1=(-b+Math.pow(d,0.5))/2.0*a;
double r2=(-b-Math.pow(d,0.5))/2.0*a;
System.out.println("roots are");
System.out.println(r1);
System.out.println(r2);
}
else if(d==0.0)
{
double r1=(-b/(2.0*a));
System.out.println(r1);
}
else
{
System.out.println("roots are not real");
}
}
}
