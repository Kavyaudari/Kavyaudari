import java.util.*;
class kavya
{
int n;
float wt[];
float  w;
float val[];
float ratio[];
Scanner in=new Scanner(System.in);
public kavya(int n,float w)
{
this.n=n;
this.w=w;
wt=new float[n];
val=new float[n];
ratio=new float[n];
   System.out.println("Enter the weights:");
        for (int i = 0; i < n; i++) { 
            wt[i] = in.nextFloat();
        }
        
        System.out.println("Enter the values:");
        for (int j = 0; j < n; j++) { 
            val[j] = in.nextFloat();
        }
        ascend(n,wt,val);
        }
void ascend(int n,float wt[],float val[] )
{
for(int i=0;i<n;i++)
{
ratio[i]=(val[i]/wt[i]);
}
//swapp
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(ratio[i]<ratio[j])
{
float temp=ratio[i];
ratio[i]=ratio[j];
ratio[j]=temp;


 temp=val[i];
val[i]=val[j];
val[j]=temp;



 temp=wt[i];
wt[i]=wt[j];
wt[j]=temp;

}
}
}
System.out.println(ks(n,wt,w,val));
}
int ks(int n,float wt[],float w,float val[])
{
int v=0;
for(int i=0;i<n;i++)
{
if(w>=wt[i])
{
v+=val[i];
w-=wt[i];
}
else
{
v+=(w/wt[i])*val[i];
break;
}
}
return v;
}
}
 class test{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of items:");
        int n = sc.nextInt();
        System.out.println("Enter capacity of knapsack:");
        float w = sc.nextFloat();
        kavya k = new kavya(n, w);
    }
}

     
