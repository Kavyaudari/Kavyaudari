//passing functions as arguments
#include<stdio.h>
int square(int);
int cube(int);
int main()
{
int x=2,y;
y=cube(square(int(x));
printf("%d",y);
}
int square(int a)
{
int b;
b=a*a;
return(b); 
}
int cube(int c)
{
int d;
d=c*c*c;
return(d);
}
