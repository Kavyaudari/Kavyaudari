//rec fun
#include<stdio.h>
int fact(int);
int main()
{
int f=1,n;
printf("enter n value");
scanf("%d",&n);
f=fact(n);
printf("%d",f);
}
int fact(int x)
{
if(x==0||x==1)
{
return(x);
}
else
return(x*fact(x-1));
}
