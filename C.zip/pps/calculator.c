//design a caluculator(+ - * / %)
#include<stdio.h>
int main()
{
int a,b,c;
printf("enter two operands");
scanf("%d%d",&a,&b);
printf("enter any operator");
scanf("%c",&operator);
switch(op)
{
case1:c=a+b;
printf("%d",c);
break;
case2:c=a-b;
printf("%d",c);
break;
case3:c=a*b;
printf("%d",c);
break;
case4:c=a/b;
printf("%d",c);
break;
case5:c=a%b;
printf("%d",c);
break;
default:
printf(" u entered wrong ");
}
