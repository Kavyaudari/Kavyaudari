#include<stdio.h>
#include<stdlib.h>
#define  n 5
int q[n];
int fo=-1;
int re=-1;

void bfs(int [][n],int []);
void eq(int);
int dq();
int main()
{
int g[n][n];
int v[n]={0};
int i,j;
printf("m");
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
scanf("%d",&g[i][j]);
}
}
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
printf("%d",g[i][j]);
}
printf("\n");
}
bfs(g,v);
}
void bfs(int g[][n],int v[])
{
fo=re=0;
eq(0);
v[0]=1;
while(fo!=re)
{
int c=q[fo];
printf("%d",q[fo]);
dq();
for(int i=0;i<n;i++)
{
if(g[c][i]==1&&v[i]==0)
{
eq(i);
v[i]=1;
}
}
}
}
void eq(int x)
{
q[re]=x;
re++;
}
int dq()
{
int x;
x=q[fo];
fo++;
return x;
}

