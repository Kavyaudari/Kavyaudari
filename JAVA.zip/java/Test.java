import java.util.*;
class A
{
String a="apple";
String b="banana";
void show()
{
System.out.println(a);
System.out.println(b);
}
}
class B extends A
{
String a="mango";
void display()
{
System.out.println(a);
}

}
class Test
{
public static void main(String args[])
{
A m=new A();
m.show();
B n=new B();
n.display();
n.show();
}
}
//assignment 1[vamshi][b200967]
