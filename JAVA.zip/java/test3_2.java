import java.util.*;
class test3_2
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
double p1,p2;
double p3,p4,p5;
int quantity;
double total=0;
System.out.println("enter no of prodcts ");
int n=in.nextInt();
for(int i=0;i<n;i++)
{
System.out.println("enter the number 1:p1\n2:p2\n3:p3\n4:p4\n5:p5 ");
System.out.println("enter the quantity ");
quantity=in.nextInt();
int p=in.nextInt(); 
switch(p)
{
case 1:p1=99.90;
total+=(p1*quantity);
break;
case 2:p2=20.20;
total+=(p2*quantity);
break;
case 3:p3=6.87;
total+=(p3*quantity);
break;
case 4:p4=45.50;
total+=(p4*quantity);
break;
case 5:p5=49.0;
total+=(p5*quantity);
break;
}
}
System.out.println("the total price = "+total);
}
}

