#include<stdio.h>
#include<string.h>
int main()
{
char str[100];
int i,n,p;
 printf("enter the string");
gets(str);
printf("enter the position");
scanf("%d",&p);
printf("enter no. of elements to delete");
scanf("%d",&n);
int l=strlen(str);
for(i=p+n;i<l;i++)
{
 str[i-n]=str[i];
}
 str[i-n]='\0';
printf("%s",str);
}
