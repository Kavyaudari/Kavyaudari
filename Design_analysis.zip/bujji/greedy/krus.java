import java.util.*;
class krus
{
int adj[][];
    int p[];
    int p1, p2;
    int value = 0;


   krus(int n){
        adj = new int[n][n];
        p = new int[n];
        Scanner sc = new Scanner(System.in);
        
       
        for (int i = 0; i < n; i++) {
            p[i] = i;
        }

     
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {
                if (i != j) {
                    System.out.print("Enter the value between " + i + " and " + j+": ");
                    adj[i][j] = adj[j][i] = sc.nextInt();
                } else {
                    adj[i][j] = adj[j][i] = 0;
                }
            }
        }
    }
    void cost(int n)
    {
    edge(n);
    if(p1==-1||p2==-1)
    {
    System.out.print("not possible ");
    }
    int pu=parent(p1);
    int pv=parent(p2);
    if(pu!=pv)
    {
    value+=adj[p1][p2];
    p[pu]=pv;
        adj[p1][p2] = adj[p2][p1] = 0;
        }
        System.out.println("Total value of MST: " + value);
    }
    void edge(int n)
    {
       int min = Integer.MAX_VALUE;
        p1 = -1;
        p2 = -1;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (adj[i][j] != 0 && adj[i][j] < min) {
                    p1 = i;
                    p2 = j;
                    min = adj[i][j];
                }
            }
        }
        System.out.println("Selected edge (" + p1 + ", " + p2 + ") with weight " + min);
        return;
    }
    int parent(int n)
    {
      if (n == p[n]) {
            return n;
        }
        return p[n] = parent(p[n]); 
    }
}



class test
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size");
int n=in.nextInt();
krus k1=new krus(n);
k1.cost(n);
}
}

