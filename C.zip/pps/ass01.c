//divisibility
#include<stdio.h>
int main()
{
int n;
printf("enter the value");
scanf("%d",&n);
if(n%5==0)
{
printf("n is divisible by 5");
}
else if(n%11==0)
{
printf(" n is divisible by 11");
}
else
{
printf(" n is not divisible by 5 and 11");
}
}
