import java.util.*;
class triangle
{
int l,b,h;
triangle(int l,int b,int h)
{
this.l=l;
this.b=b;
this.h=h;
}
void display()
{
System.out.println(l+b+h);
}
}
class t1 extends triangle
{
int area(int l,int b,int h)
{
return(l*b*h);
}
void show()
{
super.display();
System.out.println("from parent");
}
}
class week5
{
public static void main(String args[])
{
System.out.println("enter ");
Scanner in=new Scanner(System.in);
a.l=in.nextInt();
a.b=in.nextInt();
a.h=in.nextInt();
t1 a=new t1(a.l,a.b,a.h);
a.area(a.l,a.b,a.h);
a.show();
}
}

