//simple interest compound interset
#include<stdio.h>
#include<math.h>
int main()
{
int p;
float t,r;
printf("enter the values");
scanf("%d%f%f",&p,&t,&r);
float si,ci;
si=(p*t*r)/100;
printf("%f\n",si);
ci=p*pow(1+r/100,t);
printf("%f",ci);
}
