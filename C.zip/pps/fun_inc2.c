//inc and dec operators along with global variables
#include<stdio.h>
void a();
void b();
int main()
{
int x=5,y=8;
x++;
y--;
void a();
printf("x=%d\ny=%d\n",x,y);
}
void a()
{
int x=3,y=4;
x++;
y--;
printf("x=%d\ny=%d\n",x,y);
}
/*void b()
{ 
int x,y;
x++;
y--;
printf("x=%d\ny=%d\n",x,y);
}*/

