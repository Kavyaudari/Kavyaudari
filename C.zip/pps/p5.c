//passing arrays to functions
#include<stdio.h>
int large(int[],int);
int main()
{
int n,i,l;
printf("enter the size of array\n");
scanf("%d",&n);
int a[n];
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
l=large(a,n);
printf("%d",l);
}
int large(int b[],int x)
{
int i;
int max=b[0];
for(i=0;i<x;i++)
{
if(max<b[i])
{
max=b[i];
}
}
return max;
}
