#include<stdio.h>
void swap(int *a,int*b)
{
int temp;
temp=*a;
*a=*b;
*b=temp;
}
void heapify(int a[],int n,int i)
{
int max=i,lc,rc;
lc=2*i+1;
rc=2*i+2;
if(a[lc]>a[max]&&lc<n)
max=lc;
if(a[rc]>a[max]&&rc<n)
max=rc;
if(max!=i)
{
swap(&a[i],&a[max]);
heapify(a,n,max);
}
}
void buildheap(int a[],int n)
{
int b=(n/2)-1;
for(int i=b;i>=0;i--)
{
heapify(a,n,i);
}
}
void printheap(int a[],int n)
{
int i;
printf("array representaion of heap");
for(i=0;i<n;i++)
{
printf("%d ",a[i]);
}
printf("\n");
}
int main()
{
int i, n;
printf("enter the size");
scanf("%d",&n);
int a[n];
printf("enter the binary tree");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
buildheap(a,n);
printheap(a,n);
return 0;
}

