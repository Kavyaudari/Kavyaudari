//empolyement of inheritance
import java.util.*;
class emp1
{
float salary=50000;
void show()
{
System.out.println("salary is"+salary);
}
}
class emp2 extends emp
{
float bonus=1000;
float total;
total=salary+bonus;
void display()
{
System.out.println("total amount :"+total);
}
}
class emp
{
public static void main(String args[])
{
emp1 e1=new emp1();
e1.show();
emp2 e2=new emp2();
e2.display();
}
}

