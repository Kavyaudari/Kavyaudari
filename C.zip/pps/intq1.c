#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*front=0,*rear=0,*temp;
void enq()
{
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
if(front==0&&rear==0)
{
rear=front=new;
}
else
{
rear->next=new;
rear=new;
}
}
int deq()
{
if(rear==0&&front==0)
printf("underflow");
else if(front==rear)
front=rear=0;
else
{
temp=front;
printf("%d",front->data);
front=front->next;
free(temp);
}
}
void dis()
{
temp=front;
while(temp->next!=0)
{
printf("%d",temp->data);
temp=temp->next;
}
printf("%d",rear->data);
}
void main()
{
int ch;
printf("\n1=enq\n2=deq\n3=dis\n");
while(ch!=4)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1:enq();
break;
case 2:deq();
break;
case 3:dis();
break;
default:printf("wrong input");
break;
}
}
}
