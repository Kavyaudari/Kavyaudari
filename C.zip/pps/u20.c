//perfect no
#include<stdio.h>
int main()
{
int n,i,j;
int sum;
printf("enter n value");
scanf("%d",&n);
printf("all perfect no");
for(i=0;i<=n;i++)
{
sum=0;
for(j=1;j<i;j++)
{
if(i%j==0)
sum=sum+j;
}
{
if(sum==i)
printf("%d\n",i);
}
}
}
