#include<stdio.h>
int main()
{
float a,b,c,f;
int x;
printf("press 1 for convert f to c\n");
printf("press 2 for convert c to f\n");
printf("\nenter your choice");
scanf("%d",&a);
switch(x)
{
case 1:
printf("\nenter the value of temoerature in f:");
scanf("%f",&a);
c=5*(a-32)/9;
printf("\nc temperatureis:%f",c);
break;
case 2:
printf("\nenter the value of temoerature in c:");
scanf("%f",&b);
f=((9*b)/5)+32;
printf("\nf temperatureis:%f",f);
break;
default:
printf("\nwrong");
}
return 0;
}
