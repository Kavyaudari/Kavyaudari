import java.util.*;
/*class sorting 
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size of array");
int n=in.nextInt();
int a[]=new int[n];
System.out.println("enter the elements");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(a[i]>a[j])
{
int t;
t=a[i];
a[i]=a[j];
a[j]=t;
}
}
}
System.out.println("after sorting completed ");
for(int i=0;i<n;i++)
{
System.out.println(a[i]+"  ");
}
}
}*/
class sorting
{
public static void main(String args[])
{
System.out.println("enter the size of array");
Scanner in=new Scanner(System.in);
int n=in.nextInt();
int a[]=new int[n];
System.out.println("enter the elements ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(a[i]>a[j])
{
int t;
t=a[i];
a[i]=a[j];
a[j]=t;
}
}
}
System.out.println("sorting = ");
for(int i=0;i<n;i++)
{
System.out.println(a[i]+"	");
}
}
}


