package kav;
public class mango
{
public void display2()
{
System.out.println("iam mango");
}
}

