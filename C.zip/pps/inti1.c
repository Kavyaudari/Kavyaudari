#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#define n 20
char  s[n];
char pop();
int top=-1;
int pri(char);
void push(char );
void push(char x)
{
top++;
s[top]=x;
}
char pop()
{
char x;
x=s[top];
top--;
return x;
}
int pri(char sy)
{
if(sy=='^')
return(3);
else if(sy=='*'||sy=='/')
return(2);
else if(sy=='+'||sy=='-')
return(1);
else if(sy=='(')
return 0;
}
void main()
{
char in[30],*ch,ele;
printf("enter");
gets(in);
ch=in;
while(*ch!='\0')
{
if(*ch=='(')
push(*ch);
else if(isalnum(*ch))
printf("%c",*ch);
else if(*ch==')')
{
while((ele=pop())!='(')
{
printf("%c",ele);
}
}else
{
while(pri(*ch)<=pri(s[top]))
printf("%c",pop());
push(*ch);
}
ch++;
}
while(top!=-1)
{
printf("%c",pop());
}
}
