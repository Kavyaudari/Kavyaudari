//vowel or constant
#include<stdio.h>
int main()
{
char a;
printf("enter a character");
scanf("%c",&a);
if(a=='a'||a=='e'||a=='i'||a=='o'||a=='u'||a=='A'||a=='E'||a=='I'||a=='O'||a=='U')
{
printf("vowel");
}
else 
printf("constant");
}
