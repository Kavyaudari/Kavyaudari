//stack using linked list
#include<stdio.h>
#include<stdlib.h>
int read();
void create();
void push();
void pop();
void display();
struct node
{
int data;
struct node *next;
}*head,*temp,*new,*ptr,*top=NULL;
int read()
{
int a;
printf("enter the data");
scanf("%d",&a);
return a;
}
int main()
{
int ch;
while(ch!=6)
{
printf("enter the choice\n1=read\n2=create\n3=push\n4=pop\n5=display");
scanf("%d",&ch);
switch(ch)
{
case 1:read();
break;
case 2:create();
break;
case 3:push();
break;
case 4:pop();
break;
case 5:display();
break;
default:printf("Wrong");
break;
}
}
}
void create()
{
new=malloc(sizeof(struct node));
int a=read();
new->data=a;
ptr=head;
if(ptr==NULL)
{
new->next=NULL;
head=new;
top=new;
}
else
{
new->next=head;
head=new;
top=new;
}
return;
}
void push()
{
if(top==NULL)
{
printf("underflow");
}
else
{
new=malloc(sizeof(struct node));
int a=read();
new->data=a;
new->next=top;
top=new;
}
}
void pop()
{
temp=top;
if(top==NULL)
{
printf("underflow");
}
else
{
top=top->next;
free(temp);
}
}
void display()
{
temp=top;
if(top==NULL)
{
printf("underflow");
}
else
{
while(temp!=NULL)
{
printf("%d",temp->data);
temp=temp->next;
}
}
}
