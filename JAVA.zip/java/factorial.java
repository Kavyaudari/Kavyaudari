//factorial
import java.util.*;
class factorial
{
public static void main(String args[])
{
int n,i;
int f=1;
System.out.println("enter the num");
Scanner in=new Scanner(System.in);
n=in.nextInt();
for(i=1;i<=n;i++)
{
f=f*i;
}
System.out.println(f);
}
}
