//gcd
#include<stdio.h>
int gcd(int,int);
int main()
{
int a,b,c;
printf("enter any number");
scanf("%d%d",&a,&b);
c=gcd(a,b);
printf("%d",c);
}
int gcd(int x,int y)
{
int z,i;
for(i=1;i<=x&&i<=y;i++)
{
if((x%i==0)&&(y%i==0))
{
z=i;
}
}
//else 
//printf("no");
return(z);
}
