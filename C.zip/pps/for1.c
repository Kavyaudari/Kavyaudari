//10 natural numbers
#include<stdio.h>
int main()
{
int n,sum=0,i;
for(n=1;n<=10;n++)
{
for(i=1;i<=10;i++)
{
printf("%d",n);
}
sum=sum+i;
printf("%d",sum);
}
}

