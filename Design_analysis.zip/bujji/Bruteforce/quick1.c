#include<stdio.h>
void quick(int a[],int,int);
int main()
{
int n;
printf("enter the array size\n");
scanf("%d",&n);
int a[n];
printf("enter the elements of array\n");
for(int i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("the initial array is :\n");
for(int i=0;i<n;i++)
{
printf("%d",a[i]);
}
quick(a,0,n-1);
printf("the sorted array is\n");
for(int i=0;i<n;i++)
{
printf("%d",a[i]);
}
}
void quick(int a[],int start, int end)
{
int i,j,pivot,temp;
if(start<end)
{
i=start;
j=end;
pivot=start;
while(i<j)
{
while(a[i]<=a[pivot])
i++;
while(a[j]>a[pivot])
j--;
if(i<j)
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
}
temp=a[pivot];
a[pivot]=a[j];
a[j]=temp;

quick(a,start+1,j);//a,start,j-1
quick(a,i,end);//a,j+1,end
}
}





