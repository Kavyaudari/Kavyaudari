import java.util.*;
class ex5_1
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the valuse :");
int a=in.nextInt();
Integer c=new Integer(a);
int b=in.nextInt();
Integer d=new Integer(b);
System.out.println("add= " +(c+d));
System.out.println("sub = " +(c-d));
System.out.println("mult = " +(c*d));
System.out.println("div= " +(a/b));
}
}

