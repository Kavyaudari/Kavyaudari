import java.util.*;
class fibanocii
 {
    int a[];
    int n;
     public fibanocii(int n)
     {
        this.n=n;
        a[]=new int[n];
        for(int i=0;i<=n;i++)
        {
            a[i]=-1;
        }

     } 
     int fib(n)
     {
        if(a[n]!=-1)
        {
            return a[n];
        }
        if(n==0;n==1)
        {
            return a[n]=1;
        }
        else 
        {
            return a[n]=fib(n-1)+fib(n-2);
        }
     }

 }
 class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter the value of n");
        int n=in.nextInt();
        fibanocii f=new fibanocii(n);
        System.out.println(f.fib(n));
    }
 } 