
import java.util.*;


class binary{
    int a[];
    int b[];
    int n;
    public binary(int n)
    {
        this.n=n;
        a=new int[n];
        b=new int[n];
        Scanner in=new Scanner(System.in);
        
    }
    void fill(int n,int k)

    {
        if(k==n){
            for(int i=0;i<n;i++)
            {
                System.out.print(b[i]);
            }
            System.out.println();
            return;

        }
        for(int i=0;i<=1;i++)
        {
            b[k]=i;
            fill(n,k+1);

        }
    }
}
class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        int n;
        System.out.println("enter size");
        n=in.nextInt();
        binary b=new binary(n);
        b.fill(n,0);

    }
}
