import cse.my;
public class k
{
public static void main(String args[])
{
my m=new my();
m.display();
}
}

