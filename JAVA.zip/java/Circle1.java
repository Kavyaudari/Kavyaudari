import java.util.*;
class Circle1
{
int radius;
void Area(int r)
{
radius=r;
double area=(3.14)*r*r;
}
void Perimeter(int r)
{
radius=r;
double perimeter=2*(3.14)*r;
}
public static void main(String args[])
{
Circle c1=new Circle();
System.out.println("ENTER r");
Scanner in=new Scanner(System.in);
int m=in.nextInt();
int a=c1.Area(m);
int p=c1.Perimeter(m);
System.out.println("area and perimeter are ");
System.out.println(a);
System.out.println(p);
}
}
