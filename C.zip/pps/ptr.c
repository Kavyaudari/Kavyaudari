//ptr
#include<stdio.h>
int main()
{
int p,t,r,d;
printf("enter p,t,r value");
scanf("%d%d%d",&p,&t,&r);
d=(p*t*r)/100;
printf("%d",d);
return 0;
}
