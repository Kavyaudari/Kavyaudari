//natural numbers
#include<stdio.h>
int main()
{
int n,sum;
printf("enter the value of n");
scanf("%d",&n);
sum=n*(n+1)/2;
printf("sum of first n natural numbers=%d",sum);
return 0;
}
