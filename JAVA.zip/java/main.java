import p1.x;
public class main
{
public static void main(String args[])
{
x x1=new x();
x1.m1();
}
}

