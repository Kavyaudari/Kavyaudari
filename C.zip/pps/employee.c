//employee
#include<stdio.h>
struct em
{
int id;
char name[20];
char dep[20];
char des[20];
float sal;
}e1;
int main()
{
printf("enter Id,name,designation,depertment,salary");
scanf("%d%s%s%s%f",&e1.id,e1.name,e1.dep,e1.des,&e1.sal);
printf("id:%d\nname:%s\ndes:%s\ndep:%s\nsalary:%f\n",e1.id,e1.name,e1.dep,e1.des,e1.sal);
}
