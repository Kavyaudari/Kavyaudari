import java.util.*;
interface vehicle
{
void getColor(String c);
void getNumber(int n);
void getCons(int l,int fuel);
}
class two implements vehicle
{
public void getColor(String c)
{
System.out.println("color= " +c);
}
public void getNumber(int n)
{
System.out.println("number = "+n);
}
public void getCons(int l,int fuel)
{
System.out.println("consumption = " +(l*fuel));
}
}
class four implements vehicle
{
public void getColor(String c)
{
System.out.println("color= " +c);
}
public void getNumber(int n)
{
System.out.println("number = "+n);
}
public void getCons(int l,int fuel)
{
System.out.println("consumption = " +(l*fuel));
}
}
class ex7_4
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
String color=in.next();
int n=in.nextInt();
int l=in.nextInt();
int fuel=in.nextInt();
vehicle v1=new two();
v1.getColor(color);
v1.getNumber(n);
v1.getCons(l,fuel);
String color1=in.next();
int n1=in.nextInt();
int l1=in.nextInt();
int fuel1=in.nextInt();
vehicle v2=new four();
v2.getColor(color1);
v2.getNumber(n1);
v2.getCons(l1,fuel1);
}
}


