//towers of hanni
#include<stdio.h>
void toh(int n,char a,char b,char c)
{
if(n==1)
{
printf("%c->%c\n",a,b);
return ;
}
else
{
toh(n-1;a;b;c);
printf("%c->%c\n",a,b);
toh(n-1,a,b,c);
}
}
int main()
{
int m;
printf("enter no any disks");
scanf("%d",&m);
toh(m,'x','y','z');
}
