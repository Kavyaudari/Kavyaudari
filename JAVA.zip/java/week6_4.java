import java.util.*;
class contractemp
{
String design;
double salary;
public void getDesignation(String design)
{
this.design=design;
}
public String designation()
{
return design;
}
}
class houremp extends contractemp
{
int hours,wagesph;
houremp(String design,int hours,int wagesph)
{
super.getDesignation(design);
this.hours=hours;
this.wagesph=wagesph;
}
int calwages()
{
return hours*wagesph*30;
}
public String designation()
{
return super.design;
}
}
class weekemp extends contractemp
{
int weeks,wagespwk;
weekemp(String design,int weeks,int wagespwk)
{
super.getDesignation(design);
this.weeks=weeks;
this.wagespwk=wagespwk;
}
int calwages()
{
return weeks*wagespwk*30;
}
public String designation()
{
return super.design;
}
}
class week6_4
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the details of weekly employeed workers ");
String design=in.next();
int hours=in.nextInt();
int wages=in.nextInt();
houremp h=new houremp(design,hours,wages);
System.out.println("the total wages per a hourly worked customer = "+h.calwages());
}
}

