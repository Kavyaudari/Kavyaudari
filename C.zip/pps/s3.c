//lines words 
#include<stdio.h>
#include<string.h>
int main()
{
//int n;
//printf("enter the size of array\n");
//scanf("%d",&n);
char s[100],p;
p='\0';
int words=1,lines=1,ch=0,i;
printf("enter string\n");
scanf("%[^~]",s);
for(i=0;s[i]!=0;i++)
{
if(s[i]==' '||s[i]=='\n'||s[i]=='\t')
{
if(p!=' '&&p!='\n'&&p!='\t'&&p!='\0')
{
words++;
}
}
p=s[i];
if(s[i]=='\n')
{
lines++;
}
else if(s[i]>='a'&&s[i]<='z'||s[i]>='A'&&s[i]<='Z')
{
ch++;
}
}
printf("total word=%d\ntotal lines=%d\ntotal char=%d",words,lines,ch);
return 0;
}
