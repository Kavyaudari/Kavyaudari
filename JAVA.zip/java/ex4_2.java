import java.util.*;
class ex4_2
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the names ");
String s1=in.next();
String s2=in.next();
if(s1.equals(s2))
{
System.out.println("equal ");
}
else if(s1.equalsIgnoreCase(s2))
{
System.out.println("equal");
}
else
{
System.out.println("not equal");
}
}
}
