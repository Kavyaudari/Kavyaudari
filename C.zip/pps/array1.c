//arrays
#include<stdio.h>
int main()
{
int a[10],sum=0,i;
float avg;
printf("enter 10 integers");
for(i=0;i<11;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<=10;i++)
{
sum=sum+a[i];
}
printf("the numbers given by user");
for(i=0;i<=10;i++)
{
printf("%d",a[i]);
}
printf("sum=%d",sum);
avg=sum/10;
printf("%f",avg);
return 0;
}
