//units place
#include<stdio.h>
int main()
{
int n,t,u,p;
printf("enter the value of n");
scanf("%d",&n);
t=n%10;
u=n%100;
p=u-t;
printf("units place=%d\n",t);
printf("tens place=%d",p);
return 0;
}
