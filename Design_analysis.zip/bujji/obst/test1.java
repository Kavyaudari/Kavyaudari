/*import java.util.*;
import java.math.*;

class obs{
    int a[];
    int freq[];
    int dp[][];
    int n;
    Scanner in=new Scanner(System.in);
    public obs(int n)
    {
        this.n=n;
        a=new int[n+1];
        freq=new int[n+1];
        dp=new int[n+2][n+2];
        System.out.println("enter " );
        for(int i=0;i<n;i++)
        {
            a[i]=in.nextInt();
        }
        System.out.println("enter keys " );
        for(int i=0;i<n;i++)
        {
            ferq[i]=in.nextInt();
        }
        for(int i=0;i<=n+1;i++)
        {
            for(int j=0;j<=n+1;j++)
            {
                dp[i][j]=-1;
            }

        }
    

    }
    int obst( int i,int j)
    {
        if(i==j)
        return dp[i][j]=freq[i];
        if(i>j)
        return dp[i][j]=0;
        int min=Integer.MAX_VALUE;
        for(int k=i;k<=j;k++)
        {
            int val=obst(i,k-1)+obst(k+1,j+sum(i,j));
            if(val<min)
            min=val;
        }
        return dp[i][j]=min;
    }
    int sum(int i,int j)
    {
        int s=0;
        for(int k=i;k<=j;k++)
        {
            s=s+freq[k];
        }
        return s;

    }


}
class test{
    public static void main(String args[]){
      
        Scanner sc=new Scanner(System.in);
        int n;
        System.out.println("enter array size:");
        n=sc.nextInt();
        obs b=new obs(n);
        System.out.println(b.obst(1,n));
    }
}  

import java.util.*;
import java.math.*;

class obs{
    int a[];
    int freq[];
    int dp[][];
    int n;
    Scanner in=new Scanner(System.in);
    public obs(int n)
    {
        this.n=n;
        a=new int[n+1];
        freq=new int[n+1];
        dp=new int[n+2][n+2];
        System.out.println("enter " );
        for(int i=1;i<=n;i++)
        {
            a[i]=in.nextInt();
        }
        System.out.println("enter keys " );
        for(int i=1;i<=n;i++)
        {
            freq[i]=in.nextInt();
        }
        for(int i=0;i<=n+1;i++)
        {
            for(int j=0;j<=n+1;j++)
            {
                dp[i][j]=-1;
            }

        }
    

    }
    int obst( int i,int j)
    {
    if(dp[i][j]!=-1)
    return dp[i][j];
        if(i==j)
        return dp[i][j]=freq[i];
        if(i>j)
        return dp[i][j]=0;
        int min=Integer.MAX_VALUE;
        for(int k=i;k<=j;k++)
        {
            int val=obst(i,k-1)+obst(k+1,j)+sum(i,j);
            if(val<min)
            min=val;
        }
        return dp[i][j]=min;
    }
    int sum(int i,int j)
    {
        int s=0;
        for(int k=i;k<=j;k++)
        {
            s=s+freq[k];
        }
        return s;

    }


}
class test{
    public static void main(String args[]){
      
        Scanner sc=new Scanner(System.in);
        int n;
        System.out.println("enter array size:");
        n=sc.nextInt();
        obs b=new obs(n);
        System.out.println(b.obst(1,n));
    }
}     */ 


import java.util.*;
class hamil{
    int adj[][];
    int a[];
    int n;
    Scanner in=new Scanner(System.in);
    public hamil(int n)
    {
        this.n=n;
        a=new int[n];
        adj=new int[n][n];
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
{
    adj[i][j]=in.nextInt();
}
        }
        System.out.println();
    }

void fill(int k,int n)
{
    if(n==k)
    {
        for(int i=0;i<n;i++)
        {
            System.out.print(a[i]);
        }
        System.out.println();
        return;
    }
    for( int i=1;i<n;i++)
    {
         if(isSafe(k,i))
        {
            a[k]=i;
            fill(k+1,n);
        }
    }
    a[0]=0;

    
}


boolean isSafe(int k,int i)
{
    for(int j=0;j<k;j++)
    {
        if(a[j]==i)
        return false;
        
        if(adj[k-1][i]!=1)
        return false;
        if(k==n-1 && adj[i][a[0]]!=1)
        {
        return false;
        }

    }
    return true;

}
}

class hamiltonion
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
hamil h=new hamil(n);
h.fill(1,n);
}
}
