//size of all functions
#include<stdio.h>
int main()
{
printf("%d\n",sizeof(int));
printf("%d\n",sizeof(char));
printf("%d\n",sizeof(float));
printf("%ld\n",sizeof(double));
return 0;
}
