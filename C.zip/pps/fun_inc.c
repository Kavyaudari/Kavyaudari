//inc and dec using funtions
#include<stdio.h>
void a(void);
void b(void);
int main()
{
int x=5,y=6;
//printf("enter the values");
a();
scanf("%d%d",&x,&y);
}
void a()
{
int x,y;
printf("enter the values");
scanf("%d%d",&x,&y);
x++;
y--;
printf("x=%d\ny=%d\n",x,y);
b();
}
void b()
{
printf("kavya");
}
