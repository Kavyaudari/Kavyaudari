//vector functions
import java.util.*;
class vector
{
public static void main(String args[])
{
Vector<String>vec=new Vector<String>(4);
//creating vector capacity=4
//adding elements
vec.add("tiger");
vec.add("lion");
vec.add("cat");
vec.add("dog");
//to check size
System.out.println("size"+vec.size());
//System.out.println("capactiy"+vec.capactiy());
System.out.println("elements are:"+vec);
vec.add("rat");
vec.add("fish");
vec.add("fox");
System.out.println("size"+vec.size());
//System.out.println("capactiy"+vec.capactiy());
System.out.println("elements are:"+vec);
if(vec.contains("lion"))
{
System.out.println("lion is present in :"+vec.indexOf("lion"));
}
System.out.println("first element is :"+vec.firstElement());
System.out.println("last element is :"+vec.lastElement());
System.out.println("removable element:"+vec.indexOf(3));
vec.remove(3);
System.out.println(" element at 0 index:"+vec.get(0));

}
}

