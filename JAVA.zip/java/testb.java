//constructor in inheritance
import java.util.*;
class p
{
p()
{
System.out.println("this parent constructor");
}
}
class c extends p
{
c()
{
System.out.println("this is child constructor");
}
}
class testb
{
public static void main(String args[])
{
p p1=new p();//output is 2times parent 1 child constructor
c c1=new c();
}
}
