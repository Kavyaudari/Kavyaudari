package p1;
public class x
{
public void m1()
{
System.out.println("kavya rangaiah ");
}
}

