public class multiple_catch
{
public static void main(String args[])
{
try
{
int a[]=new int[5];
a[5]=30/0;
}
catch(ArithmeticException e)
{
System.out.println("arithmetic Exception");
}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("array exception ");
}
catch(Exception e)
{
System.out.println("parent exception ");
}
System.out.println("rest of code ");
}
}

