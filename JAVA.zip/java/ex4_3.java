import java.util.*;
class ex4_3
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter str");
String s1=in.next();
System.out.println("enter char");
char ch=in.next().charAt(0);
int c=0;
for(int i=0;i<s1.length();i++)
{
if(s1.charAt(s1.indexOf(ch))==s1.charAt(i))
{
c++;
}
}
System.out.println(c);
}
}

