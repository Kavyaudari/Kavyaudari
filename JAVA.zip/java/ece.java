package branch;
public class ece
{
public void display()
{
System.out.println("sub: et,networks,signals,probability");
}
}
