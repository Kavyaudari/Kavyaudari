//finding out curved surface area,total&volume of sphere and cone
#include<stdio.h>
#define pi 3.14
int main()
{
int r,csa1,tsa1,volume1,l,csa2,tsa2,volume2,height;
printf("enter the radius");
scanf("%d",&r);
csa1=4*pi*r*r;
printf("csa of sphere=%d\n",csa1);
tsa1=4*pi*r*r;
printf("tsa of sphere=%d\n",tsa1);
volume1=4/3*pi*r*r*r;
printf("volume of sphere=%d\n",volume1);
//cone
printf("enter the length of cone");
scanf("%d",&l);
printf("enter the height of cone");
scanf("%d",&height);
csa2=pi*r*l;
printf("csa of cone=%d\n",csa2);
tsa2=pi*r*(r+l);
printf("tsa of cone=%d\n",tsa2);
volume2=pi*r*r*(height/3);
printf("volume of cone=%d\n",volume2);
}
