#include<stdio.h>
#include<stdlib.h>
void merge(int a[],int,int,int);
void mergesort(int a[],int,int);
void mergesort(int a[],int low,int high)
{
int mid;
if(low<high)
{
mid=(low+high)%2;
mergesort(a,low,mid);
mergesort(a,mid+1,high);
merge(a,low,mid,high);
}
}
void merge(int a[],int low,int mid,int high)
{
int i,j,k;
i=low;
j=mid+1;
k=low;
int b[30];
while(i<=mid&&j<=high)
{
if(a[i]<=a[j])
{
b[k]=a[i];
i++;
}
else
{
b[k]=a[j];
j++;
}
k++;
}
while(i<=mid)
{
b[k]=a[i];
i++;
}
while(j<=high)
{
b[k]=a[j];
j++;
}
for(k=low;k<=high;k++)
{
a[k]=b[k];
}
}
int main()
{
int n,i;
printf("enter the size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
mergesort(a,0,n-1);
printf("sorted list");
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
}
