//abstraction
import java.util.*;
abstract class bank
{
abstract int interst();
}
class sbi extends bank
{
int interst()
{
return(7);
}
}
class hdfc extends bank
{
int interst()
{
return(17);
}
}
class abgvb extends bank
{
int interst()
{
return(10);
}
}
class testl
{
public static void main(String args[])
{
bank b;
Scanner in=new Scanner(System.in);
System.out.println("enter the value");
int x=in.nextInt();
if(x==1)
{
b=new sbi();
System.out.println("SBI="+b.interst()+"%");
}
else if(x==2)
{
b=new hdfc();
System.out.println("HDFC="+b.interst()+"%");
}
else if(x==3)
{
b=new abgvb();
System.out.println("ABGVB="+b.interst()+"%");
}
else
{
System.out.println("w");
}
}
}
