//mean
#include<stdio.h>
#include<math.h>
int main()
{
int n,i,j,sum=0,s1=0;
float avg=0,variance,standard_deviation;
printf("enter the size of array");
scanf("%d",&n);
int a[n];
printf("enter the elements in array");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
sum=sum+a[i];
avg=sum/n;
}
{
s1=sum+pow((a[i]-avg),2);
}
{
variance=s1/n;
}
standard_deviation=sqrt(variance);
printf("avg=%f\n",avg);
printf("variance=%f\n",variance);
printf("std=%f\n",standard_deviation);
return 0;
}
