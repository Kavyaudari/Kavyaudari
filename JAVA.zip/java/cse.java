package branch;
public class cse
{
public void display()
{
System.out.println("sub: oops,dbms,dec,coa");
}
}

