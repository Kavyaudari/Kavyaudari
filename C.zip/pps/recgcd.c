#include<stdio.h>
int gcd(int,int);
int main()
{
int a,b,c;
printf("enter a,b value");
scanf("%d%d",&a,&b);
c=gcd(a,b);
printf("%d",c);
}
int gcd(int a,int b)
{
int i,r;
//for(i=0;i<=a;i++)
if(a==0)
{
return(b);
}
else
{
r=b%a;
b=a;
a=r;
return(gcd(a,b));
}
}
