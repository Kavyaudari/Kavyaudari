//gcd
#include<stdio.h>
int gcd(int,int);
int main()
{
int a,b,c;
printf("enter a,b values");
scanf("%d%d",&a,&b);
c=gcd(a,b);
printf("%d",c);
}
int gcd(int x,int y)
{
int z,i;
for(i=1;i<=x&&y;i++)
{
if(x%i==0&&y%i==0)
{
z=i;
}
}
return(z);
}
