//logical operators
#include<stdio.h>
int main()
{
int a=4;
int b=7;
if
(a>2 && b>95);
{
printf("yes");
}
else
{
printf("no");
}
return 0;
}
