package p2;
import java.util.*;
public class square1
{
public void display(int a)
{
System.out.println("area= " +(a*a));
}
}


