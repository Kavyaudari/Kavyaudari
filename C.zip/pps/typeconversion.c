//type conversion
#include<stdio.h>
int x=5;
float t;
t=x+1.0;
printf("%f",t);
return 0;
}

