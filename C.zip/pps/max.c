//maxium and minimum
#include<stdio.h>
int main()
{
int a,b;
printf("enter a,b values");
scanf("%d%d",&a,&b);
if(a>b)
{
printf("a is maximum=%d",a);
}
else
{
printf("b is maximum%d",b);
return 0;
}
}
