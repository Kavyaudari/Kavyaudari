//sum of array
#include<stdio.h>
int main()
{
int n,i;
int s=0;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
s=s+a[i];
}
printf("sum=%d",s);
}

