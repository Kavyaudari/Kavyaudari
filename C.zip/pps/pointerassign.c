//pointer assignment
#include<stdio.h>
int main()
{
int a=34,b=89;
int * p, * q;
p=&a;
q=p;
printf("%d %d %d",a,*p,* q);
}
