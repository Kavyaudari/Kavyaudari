//swap
#include<stdio.h>
int main()
{
int a,b;
printf("enter ");
scanf("%d%d",&a,&b);
a=a*b;
b=a/b;
a=a/b;
printf("%d%d",a,b);
}
