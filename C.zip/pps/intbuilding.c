//building
//s=10*3=30m
//a=9.8m/s
//u=0
#include<stdio.h>
#include<math.h>
int main()
{
int s=30;
int a=9.8;
float t;
t=sqrt(2*s/a);
printf("time=%f",t);
}

