//standard variance
#include<stdio.h>
#include<math.h>
int main()
{
int n,i,s=0,s1=0;
float avg=0,v,std;
printf("enter the no");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
s=s+a[i];
}
avg=s/n;
s1=s+pow((a[i]-avg),2);
v=s1/n;
std=sqrt(v);
printf("%f  %f  %f ",avg,std,v);
}
