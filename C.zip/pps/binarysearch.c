//binary search
#include<stdio.h>
int main()
{
int n,a[10],num,first,last,middle,i;
printf("enter no of elements\n");
scanf("%d",&n);
printf("enter the elments\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("enter the element you want search");
scanf("%d",&num);
first=0;
last=n-1;
middle=(first+last)/2;
while(first<=last)
{
if(a[middle]<num)
{
first=middle+1;
}
else if(a[middle]==num)
{
printf("%d num is present in %d index",num,middle);
break;
}
else
last=middle-1;
middle=(first+last)/2;
}
if(first>last)
{
printf("element is not found");
}
}
