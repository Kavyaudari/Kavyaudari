//break statement
#include<stdio.h>
int main()
{
int n;
printf("enter the value of n");
scanf("%d",&n);
if(n%2==0)
{
goto even;
}
else
{
goto odd;
}
even:
printf("even number");
odd:
printf("odd number");
return 0;
}
