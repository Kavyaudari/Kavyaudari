#include<stdio.h>
#include<stdlib.h>
#define max 20
int s[max];
int top=-1;
void push(int);
void pop();
void display();
void push(int ele)
{
if(top==max-1)
{
printf(" overflow");
}
else if(top==-1)
{
top=0;
s[top]=ele;
}
else
{
top++;
s[top]=ele;
}
}
void pop()
{
if(top==-1)
{
printf("underflow");
}
else
{
printf("popped element %d",s[top]);
top--;
}
}
void display()
{
if(top==-1)
{
printf("underflow");
}
else
{
while(top!=-1)
{
printf("%d",s[top]);
top--;
}
}
}
void main()
{
int ch,ele;
printf("\n1=push\n2=pop\n3=display\n");
while(ch!=-1)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the data");
scanf("%d",&ele);
push(ele);
break;
case 2:pop();
break;
case 3:display();
break;
default:printf("wrong");
break;
}
}
}
