#include<stdio.h>
#include<stdlib.h>
int choice,place;
void insert();
void delete();
void traverse();
void search();
struct node
{
int data;
struct node *next;
struct node *prev;
}
*head,*ptr,*ptr1,*ptr2,*new;
int main()
{
printf("\n1.insert\n2.delete\n3.traverse\n4.search\n");
while(1)
{
printf("enter the choice");
scanf("%d",&choice);
switch(choice)
{
case 1:insert();
break;
case 2: delete();
break;
case 3: traverse();
break;
case 4:search();
break;
default:printf("exit");
break;
}
}
}
void insert()
{
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
if(head==NULL)
{
new->next=NULL;
new->prev=NULL;
head=new;
}
else
{
printf("\n1.insert at beg\n2.insert at end\n3.insert at position\n");
printf("enter the place");
scanf("%d",&place);
int pos,i;
if(place==1)
{
ptr=head;
new->next=ptr;
ptr->prev=new;
new->prev=NULL;
head=new;
}
if(place==2)
{
ptr=head;
while(ptr->next!=NULL)
{
ptr=ptr->next;
}
new->next=NULL;
new->prev=ptr;
ptr->next=new;
}
if(place==3)
{
ptr=head;
printf("enter the position");
scanf("%d",&pos);
for(i=1;i<pos-1;i++)
{
ptr=ptr->next;
}
if(ptr->next==NULL)
{
ptr=head;
new->next=ptr;
ptr->prev=new;
new->prev=NULL;
head=new;
}
else
{
ptr1=ptr->next;
new->next=ptr1;
ptr1->prev=new;
new->prev=ptr;
ptr->next=new;
}
}
}
}
void delete()
{
int pos,i;
ptr=head;
if(ptr==NULL)
{
printf("empty list");
}
else
{
printf("\n1.delete at beg\n2.delete at end\n3.delete at position\n");
printf("enter the place");
scanf("%d",&place);
if(place==1)
{
head=ptr->next;
head->prev=NULL;
free(ptr);
}if(place==2)
{
ptr=head;
if(head==NULL)
{
printf("empty list");
}
else
{
while(ptr->next!=NULL)
{
ptr=ptr->next;
}
ptr1=ptr->prev;
ptr1->next=NULL;
free(ptr);
}
}
if(place==3)
{
ptr=head;
printf("enter the position");
scanf("%d",&pos);
for(i=1;i<pos-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
ptr2=ptr1->next;
ptr->next=ptr2;
ptr2->prev=ptr;
free(ptr1);
}
}
}
void traverse()
{
if(head==NULL)
{
printf("empty list");
}
else
{
printf("elements in the list are");
for(ptr=head;ptr!=NULL;ptr=ptr->next)
{
printf("%d",ptr->data);
}
}
}void search()
{
int i=0;
int flag=0;
int value;
printf("enter the value\n");
scanf("%d",&value);
ptr=head;
if(head==NULL)
{
printf("list is empty\n");
return;
}
while(ptr!=NULL)
{
if(ptr->data==value)
{
flag=1;
break;
}
ptr=ptr->next;
i++;
}
if(flag)
printf("node is present in the list at the position :%d\n",i);
else
printf("node is not present\n");
}

