#include<stdio.h>
int main()
{
int a[50],i,j,n,c=0;
printf("enter the array size");
scanf("%d",&n);
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
for(i=0;i<n;i++)
{
for(j=i+1;j<n;j++)
{
if(a[i]==a[j])
{
c=c+1;break;
}
}
}
printf("the number of duplicate elements=%d",c);
}
