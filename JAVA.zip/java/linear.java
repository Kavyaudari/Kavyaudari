import java.util.*;
class linear
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the array size ");
int n=in.nextInt();
int a[]=new int[n];
System.out.println("enter the elements");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
System.out.println("enter the element to be searched ");
int s=in.nextInt();
int c=0;
for(int i=0;i<n;i++)
{
if(a[i]==s)
{
c=1;
System.out.println("found "+s);
break;
}
}
if(c==0)
{
System.out.println("not found");
}
}
}



