//pointers
#include<stdio.h>
int main()
{
int a;
printf("enter the a value");
scanf("%d",&a);
int *p;
p=&a;
printf("%u",* p);
}
