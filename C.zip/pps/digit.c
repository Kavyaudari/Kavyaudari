//no of digits
#include<stdio.h>
int main()
{
int count=0;
int n,r;
printf("enter the value of n");
scanf("%d",&n);
if(n>0)
{
while(n!=0)
{
r=n%10;
count=count+1;
n=n/10;
}
printf("count=%d",count);
}
else
{
printf("you entered neg integer",n);
}
return 0;
}
