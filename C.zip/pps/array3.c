//read 10 integers and add1 for each elament
#include<stdio.h>
int main()
{
int a[10],i;
printf("enter 10 integers\n");
for(i=0;i<=10;i++)
{
scanf("%d",&a[10]);
a[i]++;
printf("%d",a[i]);
}
return 0;
}
