import java.util.*;
/*class test3_3
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the array size ");
int n=in.nextInt();
int a[]=new int[n];
for(int i=0;i<n;i++)
{
int c=0;
System.out.println("enter the elements ");
int e=in.nextInt();
for(int j=0;j<a.length;j++)
{
if(e==a[j])
{
c=1;
System.out.println("it is repeated ");
i=i-1;
break;
}
else if(e<10||e>100)
{
c=1;
System.out.println("not in range ");
i=i-1;
break;
}
}
if(c!=1)
{
a[i]=e;
for(int k=0;k<i;k++)
{
System.out.println(a[k]);
}
}
}
}
}*/
class test3_3
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the array size ");
int n=in.nextInt();
int a[]=new int[n];
for(int i=0;i<n;i++)
{
int c=0;
System.out.println("enter the element ");
int e=in.nextInt();
for(int j=0;j<a.length;j++)
{
if(e==a[j])
{
c=1;
System.out.println("repeated ");
i=i-1;
break;
}
else if(e<10||e>100)
{
c=1;
System.out.println("not in range ");
i=i-1;
break;
}
}
if(c!=1)
{
a[i]=e;
for(int k=0;k<i;k++)
{
System.out.println(a[k]);
}
}
}
}
}




