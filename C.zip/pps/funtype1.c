//with arguments and with return type
#include<stdio.h>
int fun(int,int);
int main()
{
int x=3,y=2,z;
z=fun(x,y);
printf("%d\n",z);
}
int fun(int a,int b)
{
int c;
c=a*b;
return(c);
}
