//power
#include<stdio.h>
#include<math.h>
int main()
{
int n,p,t;
printf("enter the value of n,p");
scanf("%d%d",&n,&p);
t=pow(n,p);
printf("power =%d",t);
return 0;
}
