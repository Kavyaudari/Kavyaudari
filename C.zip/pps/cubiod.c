//cubiod
#include<stdio.h>
int main()
{
int l,b,h,t,lt,v;
printf("enter the values of l,b,h");
scanf("%d%d%d",&l,&b,&h);
lt=2*(l+b)*h;\\2(l+b)h
t=2*l*b+2*b*h+2*l*h;
v=l*b*h;
printf("lateral surface area=%d\n",lt);
printf("total surface area=%d\n",t);
printf("volume=%d\n",v);
return 0;
}
