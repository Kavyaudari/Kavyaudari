//arrays- sum of 10 numbers and avg
#include<stdio.h>
int main()
{
int x[10];
int i,sum=0;
float avg;
printf("enter the values");
for(i=0;i<10;i++)
{
scanf("%d",&x[i]);
}
for(i=0;i<10;i++)
{
sum=sum+x[i];
}
printf("sum=%d",sum);
avg=sum/10;
printf("avg=%f",avg);
}
