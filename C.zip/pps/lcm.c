#include<stdio.h>
int main()
{
int n1,n2,max,i,min,hcf=1;
printf("enter two integers");
scanf("%d%d",&n1,&n2);
max=(n1>n2)?n1:n2;
while(1)
{
if((max%n1==0)&&(max%n2==0))
{
printf("the lcm of %d and %d is %d\n",n1,n2,max);
	break;
}
++max;
}
//hcf
min=(n1<n2)?n1:n2;
for(i=1;i<=min;i++)
{
if(n1%i==0&&n2%i==0)
{
hcf=i;
}
}
printf("hcf of %d and %d is %d\n",n1,n2,hcf);
}
