swap without 3 rd variable
#include<stdio.h>
int main()
{
int a,b;
printf("enter values");
scanf("%d%d",&a,&b);
a=a*b;
b=a/b;
a=a/b;
printf("a,b=%d,%d",a,b);
}
