class vehicle
{
int maxSpeed=120;
}
class car extends vehicle
{
int maxSpeed=180;
void display()
{
System.out.println("Maximum Speed="+super.maxSpeed);
}
}
class week5_super
{
public static void main(String args[])
{
car e=new car();
e.display();
}
}

