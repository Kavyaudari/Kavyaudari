//addition
#include<stdio.h>
int main()
{
int a,b,sum,sub,mult,div,modulus;
printf("enter a,b values");
scanf("%d%d",&a,&b);
sum=a+b;
printf("sum of the values=%d\n",sum);
sub=a-b;
printf("sub of the values%d\n",sub);
mult=a*b;
printf("mult of the values%d\n",mult);
div=a/b;
printf("div of the values%d\n",div);
modulus=a%b;
printf("modulus of the values%d\n",modulus);
return 0;
}
