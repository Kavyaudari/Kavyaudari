//increment and decrement
#include<stdio.h>
int main()
{
int x;
printf("enter the value of n");
scanf("%d",&x);
printf("%d\n%d\n%d\n%d\n%d\n",++x,x--,x,x++,++x);
return 0;
}
