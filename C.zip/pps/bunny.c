#include<stdio.h>
int minfun();
int maxfun();
int sum();
float average();
int main()
{
int n, i,check=-1;
int sum=0;
printf("enter array size");
scanf("%d",&n);
int a[n];
printf("enter array elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
while(check!=0)
{
printf("\nenter the choices\n1for minimumnumber\n2 for maximumnumber\n3 for average\n");
scanf("%d",&check);
switch(check)
{
case 1:printf("\n minimum=%d\n",minfun(a,n));
break;
case 2:printf("\n maximum=%d\n",maxfun(a,n));
break;
case 3:printf("\n avg=%f\n",avgfun(a,&sum,n));
break;
case 0:printf("\n program sucessfully exited");
break;
default:printf("invalid:\n");
{
printf(".......");
}
return 0;
int minfun(int a[],int n)
{
int i,min=a[0];
for(i=0;i<n;i++)
{
if(a[i]<min)
{
min=a[i];
}
}
return min;
}
int maxfun(int a[],int n);
int i,max=a[0];
for(i=1;i<n;i++)
{
if (a[i]>max)
{
max=a[i];
}
}
return max;
float avgfun(int a[],int sum, int n)
{
int i;
sum=0;
for(i=0;i<n;i++)
{
sum =sum+a[i];
}
printf("%d=sum",sum);
return(sum/n);
}
}
}
