class BTClass{
    int keys[];
    int freq[];
    int n;
    BTClass(int n, int keys[], int freq[]){
        this.n = n;
        this.keys = keys;
        this.freq = freq;
        System.out.println(obst(1, n));
    }
    int obst(int i, int j){
        if(i>j){
            return 0;
        }
        if(i == j){
            return freq[i];
        }
        int min = Integer.MAX_VALUE;
        for(int k=i; k<=j; k++){
            int val = obst(i, k-1) + obst(k+1, j) + sum(i, j);
            if(val < min){
                min = val;
            }
        }
        return min;
    }
    int sum(int m, int n){
        int sum = 0;
        for(int i=m; i<=n; i++){
            sum += freq[i];
        }      
          return sum;
    }
}
public class OBST {
    public static void main(String[] args) {
        int n = 3;
        int keys[] = {0, 10, 20, 30};
        int freq[] = {0, 5, 2, 12};
        new BTClass(n, keys, freq);
    }
}
