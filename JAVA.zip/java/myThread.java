class myThread implements Runnable
{
public void run()
{
int i=1;
while(i<5)
{
System.out.println(i+"kavya");
i++;
}
}
public static void main(String args[])
{
myThread m=new myThread();
Thread t1=new Thread(m);
t1.start();
int i=1;
while(i<7)
{
System.out.println(i+"udari ");
i++;
}
}
}

