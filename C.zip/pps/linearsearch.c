//linear search
#include<stdio.h>
#include<stdlib.h>
int main()
{
int a[100],n,i,num;
printf("enter how many elements do you want\n");
scanf("%d",&n);
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("enter a num do you want to search");
scanf("%d",&num);
for(i=0;i<n;i++)
{
if(a[i]==num)
{
printf("num is present in %d index",i);
exit(0);
}
}
printf("element is not found");
}

