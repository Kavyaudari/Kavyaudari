#include<stdio.h>
#include<stdlib.h>
void q(int a[],int low,int high)
{
int i,j,pivot,temp;
if(low<high)
{
i=low;
j=high;
pivot=low;
while(i<j)
{
while(a[i]<=a[pivot])
{
i++;
}
while(a[j]>a[pivot])
{
j--;
}
if(i<j)
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
}
temp=a[j];
a[j]=a[pivot];
a[pivot]=temp;
q(a,low,j-1);
q(a,j+1,high);
}
}
void main()
{
int n,i;
printf("enter the size");
scanf("%d",&n);
int a[n];
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
q(a,0,n-1);
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
printf("\n");
}
