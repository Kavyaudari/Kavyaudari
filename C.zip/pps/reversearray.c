//reverse of an array
#include<stdio.h>
int main()
{
int n,i;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=n-1;i>=0;i--)
{
printf("%d %d",i,a[i]);
}
}
