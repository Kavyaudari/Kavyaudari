input("enter the name")
name=input("enter the name")
print(name)
print("hello  " +name)

