import java.util.*;
class mine
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the ele ");
int n=in.nextInt();
int c=0;
if(n>=2&&n%2==0)
{
System.out.println("2");
for(int i=1;i<=n;i++)
{
if(n%i==0)
{
for(int j=2;j<i;j++){
if(i%j==0)
{
c=0;
break;
}
else
{
c=1;
}
}
if(c==1)
{
System.out.println(i);
}
}
}
}
}
}
