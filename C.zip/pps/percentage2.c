//percentage
#include<stdio.h>
int main()
{
int perc;
printf("enter your percentage");
scanf("%d",&perc);
if(perc>=70)
{
printf("distinction");
}
else if(perc<70&&perc>60)
{
printf("first class");
}
else if(perc<60&&perc<40)
{
printf("second class");
}
else
{
printf("failed");
}
}

