#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
struct node *prev;
}*header,*tail,*ptr,*new,*ptr1,*ptr2;

void insert__beg()
{
new =malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
if(header==NULL)
{
new->next=NULL;
new->prev=NULL;
header=new;
}
else
{
ptr=header;
new->next=ptr;
ptr->prev=new;
new->prev=NULL;
header=new;
}
}

void insert__end()
{
new=malloc(sizeof(struct node));
printf("enter the data:");
scanf("%d",&new->data);
ptr=header;
while(ptr->next!=NULL)
{
ptr=ptr->next;
}
new->next=NULL;
new->prev=ptr;
ptr->next=new;
}
void insert__pos()
{
int pos,i;
ptr=header;
printf("enter the position ");
scanf("%d",&pos);
for(i=1;i<pos-1;i++)
{
ptr=ptr->next;
}
if(ptr->next==NULL)
{
ptr=header;
new->next=ptr;
ptr->prev=new;
new->prev=NULL;
header=new;
}
else
{
ptr1=ptr->next;
new->next=ptr1;
ptr1->prev=new;
new->prev=ptr;
ptr->next=new;
}
}
void delete__beg()
{
ptr=header;
if(ptr==NULL)
{
printf("the list is empty");
}
else
{
header=ptr->next;
header->prev=NULL;
free(ptr);
}
}
void delete__end()

{
ptr=header;
if(header==NULL)
{
printf("empty list");
}
else
{
while(ptr->next!=NULL)
{
ptr=ptr->next;
}
ptr1=ptr->prev;
ptr1->next=NULL;
free(ptr);
}
}
void delete__pos()
{
int i,pos;
ptr=header;
printf("enter the pos");
scanf("%d",&pos);
for(i=1;i<pos-1;i++)
{
ptr=ptr->next;
}
ptr1=ptr->next;
ptr2=ptr1->next;
ptr->next=ptr2;
ptr2->prev=ptr;
free(ptr1);
}
void traverse()
{
if(header==NULL)
{
printf("list is empty");
}
else
{
printf("elements in the list");
for(ptr=header;ptr!=NULL;ptr=ptr->next)
{
printf("%d",ptr->data);
}
}
}
void search()
{
int i=0;
int flag=0;
int value;
printf("enter the value\n");
scanf("%d",&value);
ptr=header;
if(header==NULL)
{
printf("list is empty\n");
return;
}
while(ptr!=NULL)
{
if(ptr->data==value)
{
flag=1;
break;
}
ptr=ptr->next;
i++;
}
if(flag)
printf("node is present in the list at the position :%d\n",i);
else
printf("node is not present\n");
}
int main()
{
int choice;
printf("\n1=insertatbeg\n2=insertatend\n3=insertatpostion\n4=delete at beg\n5=delete at end\n6=delete at position\n7=traverse\n8=search\n");
while(choice!=10)
{
printf("enter the choice");
scanf("%d",&choice);
switch(choice)
{
case 1: insert__beg();
break;
case 2: insert__end();
break;
case 3: insert__pos();
break;
case 4: delete__beg();
break;
case 5: delete__end();
break;
case 6: delete__pos();
break;
case 7: traverse();
break;
case 8: search();
break;
 case 9:exit(0);
break;
default:printf("wrong");
}
}
}
