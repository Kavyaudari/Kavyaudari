import java.util.*;
class large
{
public static void main(String args[])
{
System.out.println("enter the values a,b,c,d,e ");
Scanner in=new Scanner(System.in);
int a,b,c;
int d,e;
a=in.nextInt();
b=in.nextInt();
c=in.nextInt();
d=in.nextInt();
e=in.nextInt();
System.out.println("largest number ");
if(a>b && a>c && a>b && a>d && a>e)
{
System.out.println(a);
System.out.println(" :is the largest number ");
}
else if(b>c && b>d && b>e)
{
System.out.println(b);
System.out.println(" :is the largest number ");
}
else if(c>d && c>e) 
{
System.out.println(c);
System.out.println(" :is the largest number ");
}
else if( d>e)
{
System.out.println(d);
System.out.println(" :is the largest number ");
}
else
{
System.out.println(e);
System.out.println(" :is the largest number ");
}
System.out.println("smallest number ");
if(a<b && a<c && a<d && a<e)
{
System.out.println(a);
System.out.println(" : is the smallest number");
}
else if(b<c && b<d && b<e)
{
System.out.println(b);
System.out.println(" : is the smallest number");
}
else if( c<d && c<e)
{
System.out.println(c);
System.out.println(" : is the smallest number");
}
else if( d<e)
{
System.out.println(d);
System.out.println(" : is the smallest number");
}
else
{
System.out.println(e);
System.out.println(" : is the smallest number");
}
}
}
