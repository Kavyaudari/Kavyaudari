//pattern
#include<stdio.h>
int main()
{
printf("*\n**\n***\n****\n*****");
return 0;
}
