import java.util.*;
class back{
    int n;
    int a[];
    int b[];
    Scanner in=new Scanner(System.in);
    public back(int n)
    {
        this.n=n;
        a=new int[n];
        System.out.println("enter elements");

        for(int i=0;i<n;i++)
        {
        a[i]=in.nextInt();
        }
         b=new int[n];

    }
     void  fill(int n,int k)
     {
        if(k==n)
        {
            for(int i=0;i<n;i++)
        {
            System.out.print(b[i]);
    
        }
         System.out.println();
        return;
        }
        
        for(int i=0;i<n;i++)
        {
            if(isSafe(k,a[i]))
            {
                b[k]=a[i];
                 fill(n,k+1);
            }
            
        }
}

     
      
     boolean isSafe(int k,int i)
     {
        for(int j=0;j<k;j++)
        {
            if(b[j]==i)
            return false;
        }
        return true;
     }

}
class test {
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter the n");
        int n=in.nextInt();
        
        back b=new back(n);
    
        b.fill(n,0);
    }
}
