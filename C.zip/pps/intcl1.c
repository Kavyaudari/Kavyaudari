#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*head,*ptr,*ptr1;
struct node *create()
{
int n;
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&n);
if(n==-1)
{
return 0;
}
else
{
new->data=n;
}
}
void insbeg()
{
ptr=head;
new=create();
if(ptr==0)
{
new->next=0;
head=new;
head->next=new;
}
else
{
new->next=head->next;
head->next=new;
}
}
void insend()
{
ptr=head;
new=create();
if(ptr==0)
{
new->next=0;
head=new;
head->next=new;
}
else
{
new->next=head->next;
head->next=new;
}
}
void inspos()
{
ptr=head;
new=create();
int p,i;
printf("enter the pos");
scanf("%d",&p);
if(ptr==0)
{
new->next=0;
head=new;
head->next=new;
}
else
{
for(i=0;i<p-1;i++)
{
ptr=ptr->next;
}
new->next=ptr->next;
ptr->next=new;
}
}
void traverse()
{
ptr=head;
if(ptr==0)
printf("null");
else
{
while(ptr!=

