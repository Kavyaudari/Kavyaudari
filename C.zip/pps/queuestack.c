//implement queue using stack
#include<stdio.h>
# define N 5
int s1[5],s2[5];
int top1=-1;
int top2=-1;
int c=0;
void push1(int data)
{
if(top1==N-1)
printf("overflow");
else
{
top1++;
s1[top1]=data;
}
}
int pop1()
{
if(top1==-1)
printf("underflow");
else
{
int a=s1[top1];
top--;
return a;
}
}
void push2(int x)
{
if(top2==N-1)
printf("overflow");
else
{
top2++;
s2[top2]=x;
}
void pop2()
{
int element=s2[top2];
top2--;
return element;
}
void enqueue(int x)
{
push1(x);
c++;
}
void dequeue()
{
if(top1==-1&&top2==-1)
printf("empty");
else
{
for(int i=0;i<c;i++)
{
int element=pop1();
push2(element);
}
int b=pop2();
printf("dequeued element is %d ",b);
printf("\n");
c--;
for(int i=0;i<c;i++)
{
int a=pop2();
push1(a);
}
}
}
void display()
{
if(top1==-1&&top2==-1)
printf("emty");
for(int i=0;i<=top1;i++)
{
printf("%d",s1[i]);
}
}
void main()
{
enqueue(

