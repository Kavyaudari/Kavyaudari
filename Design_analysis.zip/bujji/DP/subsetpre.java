import java.util.*;
class subset{
    int arr[];
    int n;
    int sum;
    Scanner in=new Scanner(System.in);
    subset(int n,int sum)
    {
        this.n=n;
        this.sum=sum;
        arr=new int[n];
    
    System.out.println("enter the values of arrays");

    for(int i=0;i<n;i++)
    {
        arr[i]=in.nextInt();

    }
}
    boolean  ss( int n, int sum)
    {
        if(sum==0)
        { 
            return  true;
        }
        if(n==0)
        {
            return false;
        }
        if(arr[n-1]<=sum)
        {
            return ss(n-1,sum-arr[n-1])||ss(n-1,sum);
        }
        else
        return ss(n-1,sum);

    }
}
class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of items");
        int n=in.nextInt();
        System.out.println("enter the sum  value of the subset");
        int sum=in.nextInt();
        subset s=new subset(n,sum);
        System.out.println("the  preseence  sum of subset is:"+s.ss(n,sum));

        
    
    }
}
