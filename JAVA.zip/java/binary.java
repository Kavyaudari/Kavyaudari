import java.util.*;
class binary
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n=in.nextInt();
int a[]=new int[n];
System.out.println("enter the elements ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
System.out.println("enter the searching element ");
int s=in.nextInt();
int first=0;
int last=n-1;
int middle=(first+last)/2;
while(first<=last)
{
if(a[middle]==s)
{
System.out.println("found "+a[middle]);
break;
}
else if(a[middle]<s)
{
first=middle+1;
}
else
{
last=middle-1;
}
if(first>last)
{
System.out.println("not found ");
}
}
}
}

