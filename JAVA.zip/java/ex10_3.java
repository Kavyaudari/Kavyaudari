class ex10_3 extends Thread
{
void wait(int x)
{
try
{
Thread.sleep(x);
}
catch(Exception e)
{
System.out.println(e);
}
}
public void run()
{
while(true){
System.out.println("red light on");
wait(1000);
System.out.println("red off");
System.out.println("orange light on");
wait(1000);
System.out.println("orange off");
System.out.println("green light on");
wait(10000);
System.out.println("green light off ");
wait(1000);
}
}
public static void main(String args[])
{
ex10_3 e1=new ex10_3();
e1.start();
}
}


