//up to lp
#include<stdio.h>
int main()
{
char l;
printf("enter");
scanf("%c",&l);
if(l>='A'&&l<='Z')
{
l=l+32;
printf("%c",l);
}
else if(l>='a'&&l<='z')
{
l=l-32;
printf("%c",l);
}
}
