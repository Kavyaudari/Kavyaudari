//while loop
#include<stdio.h>
int main()
{
int i=1;
while(i<20)
{
printf("%d",i);
i++;
}
return 0;
}
