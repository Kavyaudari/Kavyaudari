import java.awt.*;
import java.awt.event.*;
class Myframe extends Frame
{
List l;
Choice c;
TextArea ta;
Myframe()
{
super("list box demo ");
l=new List(5,true);
c=new Choice();
ta=new TextArea(20,30);
l.add("monday");
l.add("tuesday");
l.add("wednesday");
l.add("thursday");
l.add("friday");
l.add("saturday");
l.add("sunday");
c.add("january");
c.add("feb");
c.add("march");
c.add("april");
c.add("may");
c.add("june");
c.add("july");
c.add("aug");
c.add("sept");
c.add("oct");
c.add("nov");
c.add("dec");
}
}
public class listbox
{
public static void main(String args[])
{
Myframe f=new Myframe();
f.setSize(500,500);
f.setVisible(true);
}
}

