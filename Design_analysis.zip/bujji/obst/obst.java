import java.util.*;
import java.math.*;
class binary
{
int a[],freq[];

int sum(int i,int j){
    int s=0;
    for (int k=i;k<=j;k++)
    {
         s+=freq[k];
     }
 return s;
 }
int obst(int i,int j)
{
     if(i==j)
       return freq[i];
    if(i>j)
        return 0;
    int min=Integer.MAX_VALUE;
    for(int k=i;k<=j;k++)
    {
        int val=obst(i,k-1)+obst(k+1,j)+sum(i,j);
        if(val<min)
            min=val;
     }
    return min;
}
}
class obst{
    public static void main(String args[]){
        binary b=new binary();
        Scanner sc=new Scanner(System.in);
        int n;
        System.out.println("enter array size:");
        n=sc.nextInt();
        b.a=new int[n+1];
        b.freq=new int[n+1];
        System.out.println("enter key values:");
        for(int i=1;i<=n;i++)
        {
           b.a[i]=sc.nextInt();
         }
         System.out.println("enter freq for corresponding key values:");
         for(int i=1;i<=n;i++)
        {
           b.freq[i]=sc.nextInt();
         }
       System.out.println( b.obst(1,n));
      }
}
    
