import java.util.*;
class equal{
  
    int n;
    int s[][];
    
    int a[];
    Scanner in=new Scanner(System.in);
    public equal(int n)
    
        {
        this.n=n;
        a=new int[n];      
        }
   void set(int n,int x)
    {
        this.n=n;
        s=new int[n+1][x+1];
         for(int i=0;i<=n;i++)
        {
            for(int j=0;j<=x;j++)
            {
               s[i][j]=-1;
            }
        }
  
    }
    int  es(int n,int sum )
    {
        if(s[n][sum]!=-1)     
        return s[n][sum];
        if(n==0&sum!=0)
        return s[n][sum]=0;
        if(sum==0)
        return s[n][sum]=1;
        if(a[n-1]<=sum)
        {
            if(es(n-1,sum-a[n-1])!=0||es(n-1,sum)!=0)
            {
            return s[n][sum]=1;
            }
            else
            {
            return s[n][sum]=0;
            }
        }
        else
        return  s[n][sum]=es(n-1,sum);
    }
}

class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of items");
        int n=in.nextInt();
        equal s=new equal(n);
        System.out.println("enter the array");
        for(int i=0;i<n;i++)
        {
          s.a[i]=in.nextInt();
        }

    
    int x;
    int sum=0;
    for(int i=0;i<n;i++)
    {
        sum=sum+s.a[i];
    }
    
    x=sum/2;
    s.set(n,x);
   /* int[][] s=new int[n+1][x+1];
  
        for(int i=0;i<=n;i++)
        {
            for(int j=0;j<=x;j++)
            {
               s.s[i][j]=-1;
            }
        }*/
    if(sum%2!=0)
    {
    System.out.println("the  preseence   equal partition of subset is:false");
    
    }
    else
    {
    String w;
    if(s.es(n,x)==0)
    {
        w="false";
        }
        else
        {
        w="true";
    
        System.out.println("the  preseence   equal partition of subset is:"+w);    
    }}
}}
