class mine1
{
public static void main(String args[])
{
try
{
System.out.println("try block ");
throw new Exception("String argument ");
}
catch(Exception e)
{
System.out.println("catch block ");
System.out.println(e.getMessage());
}
finally
{
System.out.println("final block ");
}
}
}
