//recurrsion factorial
#include<stdio.h>
int factorial(int);
int main()
{
int n,fact;
printf("enter any number");
scanf("%d",&n);
fact=factorial(n);
printf("%d",fact);
}
int factorial(int x)
{
if(x==1||x==0)
return(x);
else
return(x*factorial(x-1));
}
