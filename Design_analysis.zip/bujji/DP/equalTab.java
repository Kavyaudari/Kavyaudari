import java.util.*;
class equal{
    int a[];
    int s[][];
    int n;
    public equal(int n)
    {
        this.n=n;
        a=new int[n];
    }
    void set(int n,int x )
    {
        s=new int[n+1][x+1];
    }
    int es(int n,int x )
    {
        for(int i=0;i<=n;i++)
        {
            for(int j=0;j<=x;j++)
            {
                if(j==0)
                {
                    return s[i][j]=1;
                }
                if(i==0)
                {
                    return s[i][j]=0;
                }
                if(a[i-1]<=j)
                {
                    if(s[i-1][j-a[i-1]]!=0||s[i-1][j]!=0)
                    {
                         s[i][j]=1;
                    }
                    else
                    {
                        s[i][j]=0;
                    }
                    
                }
                else
                {
                    s[i][j]=s[i-1][j];
                }
            }
        }
        return s[n][x];
    }
    
}
class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of items");
        int n=in.nextInt();
        equal s=new equal(n);
        System.out.println("enter the array");
        for(int i=0;i<n;i++)
        {
            s.a[i]=in.nextInt();
        }

        int sum=0;
        
        for(int i=0;i<n;i++)
        {
            sum=sum+s.a[i];
        }
        int x=sum/2;
        s.set(n,x);
        if(sum%2!=0)
        {
            System.out.println("the  preseence   equal partition of subset is:false");
        }
        else
        {
        String w;
        if(s.es(n,x)==0)
        {
            w="false";
        }
        else
         {
            w="true";
            }
        
            System.out.println("the  preseence   equal partition of subset is:"+w);
        }
    }
}
