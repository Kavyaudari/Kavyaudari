import calci.cal3;
public class ex8_3
{
public static void main(String args[])
{
cal3 c1=new cal3();
c1.add(5,80);
c1.sub(67,8);
c1.mult(6,7);
c1.div(7,8);
c1.mod(5,7);
}
}
