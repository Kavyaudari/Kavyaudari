import java.util.*;
class compare
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the two Strings ");
String s1=in.nextLine();
String s2=in.nextLine();
if(s1.compareTo(s2)>0)
{
System.out.println(s1 +"is greater than " +s2);
}
else if(s1.compareTo(s2)<0)
{
System.out.println(s1 +"is smaller than " +s2);
}
else
{
System.out.println("both are equal ");
}
}
}

