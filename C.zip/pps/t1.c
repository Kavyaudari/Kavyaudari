//linear search
#include<stdio.h>
#include<stdlib.h>
int main()
{
int a[100],n,i,num;
printf("enter the size of arrays\n");
scanf("%d",&n);
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("enter the element\n");
scanf("%d",&num);
for(i=0;i<n;i++)
{
if(a[i]==num)
{
printf("%d is found in index %d",num,i);
exit(0);
}
}
printf("element is not found");
}
