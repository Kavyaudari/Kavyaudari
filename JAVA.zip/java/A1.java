package bunny;
public class A1
{
public void display()
{
System.out.println("hii bunny ");
}
}


