#include<stdio.h>
#include<math.h>
int main()
{
int i;
float n;
printf("enter the value of i");
scanf("%d",&i);
n=sqrt(i);
printf("sqrt of n=%f",n);
return 0;
}
