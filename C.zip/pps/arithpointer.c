//arithematic pointer 
#include<stdio.h>
int main()
{
int a;
printf("enter the a value");
scanf("%d",&a);
int *p;
p=&a;
printf("addrss of a =%u",p);
p=p+2;
printf("address of a=%u",p);
}
