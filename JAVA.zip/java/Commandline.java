import java.util.*;
class Commandline
{
public static void main(String a[])
{
int i;
for(i=0;i<a.length;i++)
{
System.out.println(a[i]);
}
}
}
