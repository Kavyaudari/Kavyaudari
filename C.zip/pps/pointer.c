//pointers 
#include<stdio.h>
int main()
{
int a=10,b=90;
int * p, * q;
p=&a;
q=&b;
printf("%d %d %d %d",* p,a,*q,b);
}
