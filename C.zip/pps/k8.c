//qudratic roots
#include<stdio.h>
#include<math.h>
int main()
{
int a,b,c;
float r1,r2,det;
printf("enter values");
scanf("%d%d%d",&a,&b,&c);
det=b*b-4*a*c;
printf("%f",det);
if(det<0)
printf("roots are imaginary");
else if(det==0)
{
r1=-b/2*a;
r2=-b/2*a;
printf("roots are equal %f %f",r1,r2);
}
else
{
r1=(-b+sqrt(det))/2*a;
r2=(-b-sqrt(det))/2*a;
printf("%f %f are real and distinct",r1,r2);
}
}
