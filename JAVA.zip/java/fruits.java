import kav.apple;
import kav.mango;
public class fruits 
{
public static void main(String args[])
{
apple a=new apple();
mango m =new mango();
a.display1();
m.display2();
}
}

