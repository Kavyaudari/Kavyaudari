#include<stdio.h>
int main()
{
int n,s=0,avg,max,min,i;
printf("enter the size of a matrix");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
s=s+a[i];
}
min=a[0];
max=a[0];
for(i=0;i<n;i++)
{
if(min>a[i])
{
min=a[i];
}
if(max<a[i])
{
max=a[i];
}
}
avg=(float)s/n;
printf("max=%d\n",max);
printf("min=%d\n",min);
printf("avg=%d\n",avg);
}
