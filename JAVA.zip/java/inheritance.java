import java.util.*;
class fruit
{
String name;
String colour;
String taste;
void print()
{
System.out.println(name+colour+taste);
}
}
class mango extends fruit
{
int price;
void print()
{
System.out.println(name+colour+taste+price);
}
}
class lemon extends fruit
{
int price ;
void print()
{
System.out.println(name+colour+taste+price);
}
}
class inheritance
{
public static void main(String args[])
{
System.out.println("enter the details");
Scanner in=new  Scanner(System.in);
mango m=new mango();
lemon l=new lemon();
System.out.println("name+colour+taste+price");
m.colour=in.next();
m.taste="sweet";
m.print();
}
}
