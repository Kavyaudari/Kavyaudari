package kavya;
public class a
{
public void display()
{
System.out.println("kavya rangaiah ");
}
}
