//array basics
#include<stdio.h>
int main()
{
int x[5]={1,2,3,4,5};
int y[2]={5};
int z[]={1,8,9};
int k[]={0};
printf("%d",x[5]);
printf("%d",y[2]);
return 0;
}
