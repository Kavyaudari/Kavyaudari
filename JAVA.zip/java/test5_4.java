import java.util.*;
class account
{
String name;
int a_no;
double amount,withdraw,deposit;
account(String n,int i,double a,double w,double d)
{
name=n;
a_no=i;
amount=a;
withdraw=w;
deposit=d;
}
void debit(double w)
{
if(amount>w)
{
amount=(amount-w);
System.out.println("after withdrawed = "+amount);
double m=(amount-withdraw)+deposit;
System.out.println("current amount =" +m);
}
else
{
System.out.println("not possible ");
}

}
void credit(double d)
{
amount=amount+d;
System.out.println("deposited amount = "+amount);
}
}
class test5_4
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the name ");
String n=in.nextLine();
System.out.println("enter the number ");
int i=in.nextInt();
System.out.println("enter amount ");
double a=in.nextDouble();
System.out.println("withdraw amount ");
double w=in.nextDouble();
System.out.println("deposit amount ");
double d=in.nextDouble();
account ac=new account(n,i,a,w,d);
ac.credit(d);
ac.debit(w);
}
}
