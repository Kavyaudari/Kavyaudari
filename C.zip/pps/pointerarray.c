//pointer array
#include<stdio.h>
int main()
{
int a[5]={0,9,7,5,3};
/*printf("enter the array size");
scanf("%d",&a);
int k[a],i;
printf("enter the elements of k");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
int * p=&a[i];
//printf("%d",* p)*/
int * p=&a[0];
printf("%d",* p);
p=p+2;
printf("%d",* p);
}
