//fabanocciseries
#include<stdio.h>
int main()
{
int t1=0,t2=1,t3,i,n;
printf("enter the value ofn");
scanf("%d",&n);
i=0;
while(i<=n){
printf("%d",t1);
t3=t1+t2;
t1=t2;
t2=t3;
i++;
}
}
