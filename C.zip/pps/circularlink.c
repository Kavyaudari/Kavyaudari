#include<stdio.h>
#include<stdlib.h>
void insertbeg();
void insertend();
void insertpos();
void deletebeg();
void deleteend();
void deletepos();
void traverse();
//void search();
int i,pos,choice,place;
struct node
{
int data;
struct node *next;
}*tail,*new,*temp,*prev;
int main()
{
printf("\n1=insert\n2=end\n3=pos\n4=delete\n5=end\n6=pos\n7=traverse\n8=search\n9=exit");
while(1)
{
printf("enter the choice");
scanf("%d",&choice);
switch(choice)
{
case 1:insertbeg();
break;
case 2:insertend();
break;
case 3:insertpos();
break;
case 4:deletebeg();
break;
case 5:deleteend();
break;
case 6:deletepos();
break;
case 7:traverse();
break;
//case 8:search();
//break;
case 9:exit(0);
default:printf("\nwrong ");
}
}
}
void insertbeg()
{
new=malloc(sizeof(struct node));
new->next=NULL;
printf("enter the data");
scanf("%d",&new->data);
if(tail==NULL)
{
tail=new;
tail->next=new;
}
else
{
new->next=tail->next;
tail->next=new;
}}
void insertend()
{
new=malloc(sizeof(struct node));
new->next=NULL;
printf("enter the data");
scanf("%d",&new->data);
if(tail==NULL)
{
tail=new;
tail->next=new;
}
else
{
new->next=tail->next;
tail->next=new;
}
}
void insertpos()
{
new=malloc(sizeof(struct node));
new->next=NULL;
printf("enter the data");
scanf("%d",&new->data);
if(tail==NULL)
{
tail=new;
tail->next=new;
}
else
{
printf("enter the pos");
scanf("%d",&pos);
temp=tail->next;
for(i=1;i<pos-1;i++)
{
temp=temp->next;
}
new->next=temp->next;
temp->next=new;
}
}
void deletebeg()
{
temp=tail->next;
if(tail==NULL)
{
printf("list is empty");
}
else if(temp->next=temp)
{
tail=NULL;
free(temp);
}
else
{
tail->next=temp->next;
free(temp);
}
}
void deleteend()
{
temp=tail->next;
if(tail==NULL)
{
printf("list is empty");
}
else if(temp->next==temp)
{
tail=NULL;
free(temp);
}
else
{
while(temp->next!=tail->next)
{
prev=temp;
temp=temp->next;
}
prev->next=tail->next;
tail=prev;
free(temp);
}
}void deletepos()
{
temp=tail->next;
if(tail==NULL)
{
printf("list is empty");
}
else if(temp->next==temp)
{
tail=NULL;
free(temp);
}
else
{
printf("enter the pos");
scanf("%d",&pos);
for(i=1;i<pos-1;i++)
{
temp=temp->next;
}
prev=temp->next;
temp->next=prev->next;
}
}
void traverse()
{
temp=tail->next;
do{
printf("%d",temp->data);
temp=temp->next;
}
while(temp!=tail->next);
}/*
void search()
{
int i=0;
int flag=0;
int value;
printf("enter the vaue");
scanf("%d ",&value);
temp=tail->next;
if(tail==NULL)
{
printf("empty\n");
return;
}
while(tail!=NULL)
{
if(temp->data==value)
{
flag=1;
break;
}
temp=temp->next;
i++;
}
if(flag)
printf("node is present in %d position\n",i);
else
printf("node is not present");
}*/

