#include<stdio.h>
#include<math.h>
int main()
{
int p;
float  t,r,si,cp;
printf("enter the p t r values");
scanf("%d%f%f",&p,&t,&r);
si=(p*t*r)/100;
printf("si=%f",si);
cp=p*pow(1+r/100,t);
printf("cp=%f",cp);
}
