#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
char s[100];
int top=-1;
void push(char x)
{
top++;
s[top]=x;
}
char pop()
{
char x;
x=s[top];
top--;
return x;
}
void main()
{
char infix[50],postfix[50],vh,ele;
int i=0,k=0;
printf("enter the infix expression");
scanf("%s",infix);
push('#');
while((ch=infix[i]!='\0')
{
if(ch=='(')
{
push(ch);
}
else if(Isalnum(ch))
postfix[k++]=ch;
else if(ch==')')
{
while(s[top]!='(')
postfix[k++]=pop();
ele=pop();
}
else
{
while(pri(ch)<=prs[s[top]))
{
postfix[k++]=pop();
push(ch);
}
i++;
}
}
while(s[top!=0)
{
postfix[k++]=pop();
postfix[k]='\0';
printf("%s",postfix);
}
}
int pri(char sym)
{
if(sym=='^')
{
return 5;
}
else if(sym=='*'||sym=='/')
{
return 3;
}
else if(sym=='+'||sym=='-')
{
return 1;
}
else
{
return 0;
}
}
int prs(char sym)
{
if(sym=='^')
{
return 6;
}
else if(sym=='*'||sym=='/')
{
return 4;
}
else if(sym=='+'||sym=='-')
{
return 2;
}
else
{
return 0;
}
}
