//prime
#include<stdio.h>
int main()
{
int n,i=1,c=0;
printf("enter n value");
scanf("%d",&n);
while(i<=n)
{
if(n%i==0)
c=c+1;
i++;
}
if(c==2)
{
printf("prime");
}
else
printf("not prime");
}
