class BTClassdp{
    int keys[];
    int freq[];
    int n;
    int dp[][];
    BTClassdp(int n, int keys[], int freq[]){
        this.n = n;
        this.keys = keys;
        this.freq = freq;
        dp = new int [n+2][n+2];  //as we are getting i>j case so at last when k = n(here 3) k+1 = 4(n+1)
        for(int i=0; i<=n+1; i++){
            for(int j=0; j<=n+1; j++){
                dp[i][j] = -1;
            }
        }
        System.out.println(obst(1, n));
    }
    int obst(int i, int j){
        if(dp[i][j] != -1){
            return dp[i][j];
        }
        if(i>j){
            return dp[i][j] = 0;
        }
        if(i == j){
            return dp[i][j] = freq[i];
        }
        int min = Integer.MAX_VALUE;
        for(int k=i; k<=j; k++){
            int val = obst(i, k-1) + obst(k+1, j) + sum(i, j);
            if(val < min){
                min = val;
            }
        }
        return dp[i][j] = min;
    }
    int sum(int m, int n){
        int sum = 0;
        for(int i=m; i<=n; i++){
            sum += freq[i];
        }
        return sum;
    }
}
public class OBSTdp {
    public static void main(String[] args) {
        int n = 3;
        int keys[] = {0, 10, 20, 30};
        int freq[] = {0, 5, 8, 12};
        new BTClassdp(n, keys, freq);
    }
}

