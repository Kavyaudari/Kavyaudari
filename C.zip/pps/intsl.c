#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*top=0,*ptr;
void push()
{
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
if(top==0)
{
top=new;
}
else
{
new->next=top;
top=new;
}
}
void pop()
{
ptr=top;
if(top==0)
printf("underflow");
else
{
printf("%d",top->data);
top=top->next;
free(ptr);
}
}
void display()
{
ptr=top;
if(ptr==0)
printf("null");
else
{
while(ptr!=0)
{
printf("%d",ptr->data);
ptr=ptr->next;
}
}
}
void main()
{
int ch;
printf("\n1=push\n2=pop\n3=display");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:push();
break;
case 2:pop();
break;
case 3:display();
break;
default:printf("wrong");
break;
}
}
}
