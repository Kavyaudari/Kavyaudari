import java.util.*;
class emp
{
String firstname;
String lastname;
void getFirstname(String fname){
firstname=fname;
System.out.println("the fname="+fname);
}
void getLastname(String lname)
{
lastname=lname;
System.out.println("the last name="+lname);
}
}
class contract extends emp
{
String dept;
String desc;
String fullname;
void getFullname(String n)
{
fullname=n;
System.out.println("the fullname= "+n);
}
void getDept(String d)
{
dept=d;
System.out.println("department ="+d);
}
void getDesc(String D)
{
desc=D;
System.out.println("designation= "+D);
}
}
class regular extends emp
{
String dept;
String desc;
String fullname;
void getFullname(String a)
{
fullname=a;
System.out.println("the fullname= "+a);
}
void getDept(String b)
{
dept=b;
System.out.println("department ="+b);
}
void getDesc(String c)
{
desc=c;
System.out.println("designation= "+c);
}
}
class week6_3
{
public static void main(String args[])
{
contract c1=new contract();
Scanner in=new Scanner(System.in);
emp e1=new emp();
System.out.println("enter the first name and last name ");
String fname=in.next();
String lname=in.next();
e1.getFirstname(fname);
e1.getLastname(lname);
System.out.println("enter the details of contract employee ");
String name1=in.next();
String department1=in.next();
String designation1=in.next();
c1.getFullname(name1);
c1.getDept(department1);
c1.getDesc(designation1);
regular r1=new regular();
System.out.println("enter the details of regular employee ");
String name2=in.next();
String department2=in.next();
String designation2=in.next();
r1.getFullname(name2);
r1.getDept(department2);
r1.getDesc(designation2);
}
}

