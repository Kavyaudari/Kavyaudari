package rudra;
public interface inter4
{
void display();
}

