import java.util.*;
/*class rudra
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter ");
int a=in.nextInt();
int c=0;
if(a>=2&&a%2==0)
{
System.out.println("2");
}
for(int i=1;i<=a;i++)
{
if(a%i==0)
{
for(int j=2;j<i;j++)
{
if(i%j==0)
{
c=0;
break;
}
else
{
c=1;
}
}
if(c==1)
{
System.out.println(i);
}
}
}
}
}
class rudra
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter ");
int a=in.nextInt();
int t=a;
int s=0;
while(a>0)
{
s=s*10;
int r=a%10;
s=s+r;
a=a/10;
}
if(s==t)
{
System.out.println("same ");
}
}
}
class rudra
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter size");
int n=in.nextInt();
int a[]=new int[n];
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
check c1=new check();
int x=in.nextInt();
c1.search(a,n,x);
}
}
class check
{
void search(int a[],int n,int x)
{
int f=0;
int l=n-1;
int m=(f+l)/2;
for(int i=0;i<n;i++)
{
if(a[m]<x)
{
f=m+1;
}
else if(a[m]==x)
{
System.out.println("found ");
break;
}
else
{
l=m-1;
m=(f+l)/2;
}
}
}
}

class rudra
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter ");
int m=in.nextInt();
int n=in.nextInt();
int p=in.nextInt();
int q=in.nextInt();
int a[][]=new int[m][n];
int b[][]=new int[p][q];
int c[][]=new int[m][q];
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
a[i][j]=in.nextInt();
}
}
for(int i=0;i<p;i++)
{
for(int j=0;j<q;j++)
{
b[i][j]=in.nextInt();
}
}
check c1=new check();
c1.mult(a,b,c,m,n,p,q);
}
}
class check
{
int s=0;
void mult(int a[][],int b[][],int c[][],int m,int n,int p,int q)
{
if(n!=p)
{
System.out.println("no");
}
else
{
for(int i=0;i<m;i++)
{
for(int j=0;j<q;j++)
{
for(int k=0;k<p;k++)
{
s=s+a[i][k]*b[k][j];
}
c[i][j]=s;
s=0;
}
}
}
for(int i=0;i<m;i++)
{
for(int j=0;j<q;j++)
{
System.out.print(c[i][j] +"\t");
}
System.out.print("\n");
}
}
}

class rudra
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter size");
int n=in.nextInt();
String s[]=new String[n];
for(int i=0;i<n;i++)
{
s[i]=in.next();
}
check c1=new check();
c1.sort(s,n);
}
}
class check
{
void sort(String s[],int n)
{
String x;
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(s[i].compareTo(s[j])>0)
{
x=s[i];
s[i]=s[j];
s[j]=x;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(s[i]);
}
}
}
class emp
{
int id;
String name;
String address;
double sal;
void display()
{
System.out.println(id+name+address+sal);
}
}
class rudra
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
emp e[]=new emp[3];
e[0]=new emp();
e[1]=new emp();
e[2]=new emp();
for(int i=0;i<3;i++)
{
e[i].id=in.nextInt();
e[i].name=in.next();
e[i].address=in.next();
e[i].sal=in.nextDouble();
}
System.out.println("enter id ");
int x=in.nextInt();
for(int i=0;i<3;i++)
{
if(e[i].id==x)
{
e[i].display();
}
}
}
}

class rudra
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int a[]=new int[5];
for(int i=0;i<5;i++)
{
System.out.println("enter ");
int e=in.nextInt();
int c=0;
for(int j=0;j<=i;j++)
{
if(a[j]==e)
{
System.out.println("rep");
c=1;
i=i-1;
break;
}
else if(e<=10||e>=100)
{
System.out.println("range");
c=1;
i=i-1;
break;
}
}
if(c!=1)
{
a[i]=e;
for(int k=0;k<=i;k++)
{
System.out.println(a[k]);
}
}
}
}
}

import java.util.Random;
class rudra
{
public static void main(String args[])
{
int i,dice1,dice2;
int m=0;
int n=0;
Random r=new Random();
dice1 =r.nextInt(6);
dice2=r.nextInt(6);
for(i=0;i<3;i++)
{
Scanner in=new Scanner(System.in);
dice1=in.nextInt();
dice2=in.nextInt();
if((dice1>=1&&dice1<=6)&&(dice2>=1&&dice2<=6))
{
if(dice1==dice2)
{
n++;
}
else
{
m++;
}
}
else
{
System.out.println("invalid ");
}
}
System.out.println(n);
System.out.println(m);
}
}

class book
{
int id;
String name;
String author ;
int c;
book(int id,String name,String author,int c)
{
this.id=id;
this.name=name;
this.author=author;
this.c=c;
}
void sell(int n)
{
if(c>=n)
{
c=c-n;
System.out.println(c);
}
else
{
System.out.println("no");
}
}
}
class customer
{
String cname;
int cid;
customer(String cname,int cid)
{
this.cname=cname;
this.cid=cid;
}
void buy(book b,int n)
{
System.out.println("books ");
b.sell(n);
}
}
class rudra
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int id=in.nextInt();
String name=in.next();
String address=in.next();
int c=in.nextInt();
book b1=new book(id,name,address,c);
int cid=in.nextInt();
String cname=in.next();
customer c1=new customer(cname,cid);
c1.buy(b1,5);
}
}
*/
