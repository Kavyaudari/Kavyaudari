//constructor with paramters
import java.util.*;
class p
{
p()
{
System.out.println("without parameters");
}
p(int x)
{
System.out.println("with parameters");
}
}
class c extends p
{
c()
{
System.out.println(" child without parameters");
}
c(int z)
{
super(z);//used to calling parameterised consructor 
System.out.println(" child with parameters");
}
}
class testc
{
public static void main(String ars[])
{
c c1=new c();
c c2=new c(67);
}
}

