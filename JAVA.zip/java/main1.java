import package.p2;
import java.util.*;
public class main1
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the a ");
int a=in.nextInt();
square1 s1=new square1();
s1.display(a);
}
}

