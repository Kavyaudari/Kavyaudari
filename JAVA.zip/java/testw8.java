import org.shapes.square;
import org.shapes.circle;
import org.shapes.rectangle;
import java.util.*;
public class testw8
{
public static void main(String args[])
{
System.out.println("enter the value for square");
Scanner in=new Scanner(System.in);
square s1=new square();
s1.s=in.nextInt();
s1.set(s1.s);
s1.display();
System.out.println("enter the value for circle");
circle k1=new circle();
k1.r=in.nextInt();
k1.set2(k1.r);
k1.print();
System.out.println("enter the value for rectangle");
rectangle r1=new rectangle();
r1.l=in.nextInt();
r1.b=in.nextInt();
r1.set(r1.l,r1.b);
r1.kavya();
}
}
