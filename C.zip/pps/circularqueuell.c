#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*front=0,*rear=0,*temp,*new;
void enqueue(int x)
{
new=malloc(sizeof(struct node));
new->data=x;
new->next=NULL;
if(rear==0){
front =rear=new;
rear->next=front;/*circular q address storing itself*/
}
else
{
rear->next=new;
rear=new;
rear->next=front;
}
}
void dequeue()
{
temp=front;
if(front==0&&rear==0)
printf("q is empty");
else if(front==rear)
free(temp);
else
{
front=front->next;
rear->next=front;
free(temp);
}
}
void peek()
{
if(front==0&&rear==0)
printf("q is empty");
else
{
printf("%d",front->data);
}
}
void display()
{
temp=front;
if(front==0&&rear==0)
printf("q is empty");
else
{
while(temp->next!=front)
{
printf("%d",temp->data);
temp=temp->next;
}
printf("%d",temp->data);
}
}
int main()
{
int ch,ele;
printf("\n1=enqueue\n2=dequeue\n3=peek\n4=display");
while(ch!=5)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the element");
scanf("%d",&ele);
enqueue(ele);
break;
case 2:dequeue();
break;
case 3:peek();
break;
case 4:display();
break;
default:printf("wrong");
break;
}
}
}
