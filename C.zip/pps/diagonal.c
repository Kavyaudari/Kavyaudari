#include<stdio.h>
int main()
{
int a[10][10],n,m,i,j;
printf("enter");
scanf("%d%d",&m,&n);
printf("enter the elements");
for(i=0;i<m;i++)
{
for(j=0;j<n;j++)
{
scanf("%d",&a[i][j]);
}
}
for(i=0;i<m;i++)
{
for(j=0;j<n;j++)
{
printf("%d",a[i][j]);
}
}
printf("the diagonal elmentts are");
if(m==n)
{
for(i=0;i<m;i++)
{
for(j=0;j<n;j++)
{
if(i==j)
{printf("%d",a[i][j]);
}
}
}
}
else
printf("it is not a square matrix");
}
