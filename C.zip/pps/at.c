//area of triangle
#include<stdio.h>
float main()
{
 float n,l,b,t;
 n=0.5;
 printf("enter l,b value");
 scanf("%f%f",&l,&b);
 t=n*l*b;
 printf("%f",t);
 return 0;
 }
 
 

