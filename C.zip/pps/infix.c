#include<stdio.h>
#include<ctype.h>
#define s 30
char stack[s];
int top=-1;
void push(char x);
char pop();
int pri(char);
void push(char x)
{
top++;
stack[top]=x;
}
char pop()
{
char x;
x=stack[top];
top--;
return x;
}
int pri(char symbol)
{
if(symbol=='^')
return (3);
else if(symbol=='*'||symbol=='/')
return (2);
else if(symbol=='+'||symbol=='-')
return (1);
else if(symbol=='(')
return 0;
}
void main()
{
char infix[30],*ch,ele;
printf("enter the expression");
gets(infix);
ch=infix;
while(*ch!='\0')
{
if(*ch=='(')
push(*ch);
else if(isalnum(*ch))
printf("%c",*ch);
else if(*ch==')')
{
while((ele=pop())!='(')
{
printf("%c",ele);
}
}
else
{
while(pri(*ch)<=pri(stack[top]))
printf("%c",pop());
push(*ch);
}
ch++;
}
while(top!=-1)
{
printf("%c",pop());
}
}
