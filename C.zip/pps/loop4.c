//name using loops
#include<stdio.h>
int main()
{
int i='kavya';
while(i<50)
{
printf("%d\n",i);
i++;
}
return 0;
}
