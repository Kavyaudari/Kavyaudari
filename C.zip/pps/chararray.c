//character array
#include<stdio.h>
int main()
{
char a[5]={'K','a','v','y','a'};
printf("%s",a);
}
