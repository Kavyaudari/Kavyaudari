import java.util.*;
interface payable
{
void getAmount(int m,int n);
}
class call implements payable
{
public void getAmount(int m,int n)
{
System.out.println("the total amount of employee = " +(m*100));
System.out.println("the total amount of employee including invoice "+((m*100)+n));
}
}
class week7_3
{
public static void main(String args[])
{
payable p1=new call();
Scanner in=new Scanner(System.in);
System.out.println("enter the m and n values ");
int m=in.nextInt();
int n=in.nextInt();
p1.getAmount(m,n);
}
}


