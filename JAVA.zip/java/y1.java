import kavya.x1a;
import kavya.x2a;
class y1
{
public static void main(String args[])
{
x1a a1=new x1a();
x2a a2=new x2a();
a1.m1();
a2.m2();
}
}

