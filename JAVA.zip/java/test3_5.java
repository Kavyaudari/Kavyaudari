import java.util.*;
/*class book
{
String name;
String author;
int count;
public book(String name, String author ,int count)
{
this.name=name;
this.author=author;
this.count=count;
}
public void sell(int n)
{
if(count>=n)
{
count=count-n;
System.out.println("solded are ="+n);
System.out.println("remaining are ="+count);
}
else
{
System.out.println("not available ");
}
}
}
class customer
{
String name;
String address;
int cid;
public customer(String name,String address ,int cid)
{
this.name=name;
this.address=address;
this.cid=cid;
}
public void bookbuy(book b,int n)
{
System.out.println(name+"is buyed ");
b.sell(n);
}
}
class test3_5
{
public static void main(String args[])
{
String n,a;
int c;
Scanner in=new Scanner(System.in);
System.out.println("enter the details ");
n=in.next();
a=in.next();
c=in.nextInt();
book b=new book(n,a,c);
String N=in.next();
String address=in.next();
int cid=in.nextInt();
customer c1=new customer(N,address,cid);
c1.bookbuy(b,2);}
}*/
class book
{
String name;
String author;
int count;
public book(String name,String author ,int count)
{
this.name=name;
this.author=author;
this.count=count;
}
public void sell(int n)
{
if(count>=n)
{
count=count-2;
System.out.println("the books are solded are "+n+"remaining books are "+count);
}
else {
System.out.println("no available are there ");
}
}
}
class customer
{
String name;
String address;
int cid;
public customer(String name,String address ,int cid)
{
this.name=name;
this.address=address;
this.cid=cid;
}
public void buy(book b,int n)
{
System.out.println("book is "+name + "is buyed ");
b.sell(n);
}
}
class test3_5
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the details of book ");
String name,author;
int count;
name=in.next();
author=in.next();
count=in.nextInt();
book b1=new book(name,author,count);
System.out.println("enter the details of customer ");
String cname;
String address;
int cid;
cname=in.next();
address=in.next();
cid=in.nextInt();
customer c1=new customer(cname,address,cid);
System.out.println("enter the no of books you want ");
int n=in.nextInt();
c1.book(b1,n);
}
}



