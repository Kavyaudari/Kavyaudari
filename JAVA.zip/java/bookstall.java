import java.util.*;
class book
{
int book_id;
String book_name;
String author;
int count ;
void display()
{
System.out.println(book_id+book_name+author+count);
}
void buy(int x)
{
int y=count-x;
System.out.println(y);
}
}
class customer
{
String cname;
int cid;
String address;
void display()
{
System.out.println(cname+cid+address);
}
}
class bookstall
{
public static void main(String args[])
{
book b[]=new book[3];
customer c[]=new customer[1];
b[0]=new book();
b[1]=new book();
b[2]=new book();
c[0]=new customer();
Scanner in=new Scanner(System.in);
for(int i=0;i<2;i++)
{
System.out.println("enter the details");
b[i].book_id=in.nextInt();
b[i].book_name=in.next();
b[i].author=in.next();
b[i].count=in.nextInt();
}
for(int i=0;i<1;i++)
{
c[i].cname=in.next();
c[i].cid=in.nextInt();
c[i].address=in.next();
}
System.out.println("enter the book name you want");
int id=in.nextInt();
System.out.println("enter the number of books");
int x=in.nextInt();
for(int i=0;i<2;i++)
{
if(b[i].book_id==id)
{
b[i].display();
c[i].display();
b[i].buy(x);
}
}
}
}
