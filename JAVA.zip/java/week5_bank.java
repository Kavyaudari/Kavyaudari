import java.util.*;
class account
{
int a_no;
String a_name;
int a_balance;
String a_address;
int x;
void credit(int a_balance,int x)
{
a_balance=a_balance+x;
System.out.println(a_balance);
}
void debit(int a_balance,int x)
{
if(a_balance<x)
{
System.out.println("no");
}
else 
{
a_balance=a_balance-x;
System.out.println(a_balance);
}
}
void getbalance()
{
System.out.println(a_balance);
}
}
class week5_bank
{
public static void main(String args[])
{
System.out.println("enter");
Scanner in=new Scanner(System.in);
account a=new account();
a.a_no=in.nextInt();
a.a_name=in.next();
a.a_balance=in.nextInt();
a.a_address=in.next();
a.x=in.nextInt();
a.credit(a.a_balance,a.x);
a.debit(a.a_balance,a.x);
a.getbalance();
}
}

