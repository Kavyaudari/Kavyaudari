package kavya;
public class x2a
{
public void m2()
{
System.out.println("2nd program ");
}
}

