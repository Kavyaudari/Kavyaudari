#include<stdio.h>
#define MAX 30
char s[MAX];
int top=-1;
void push(char ele)
{
if(top==MAX-1)
{
printf("stack overflow\n");
}
char pop()
{
if(top<0)
{
printf("stack underflow\n");
return ;
}
int getpriority(char x)
{
if(x=='+'||x=='-')
return 1;
if(x=='*'||x=='/')
return 2;
return 0;
}
void infixpos(char inexp[])
{
char c;
int i;
for(i=0;inexp[i]!='\0';i++)
{
if(isalnum(inexp[i])
printf("%c",inexp[i]);
else if(inexp[i]=='(')
push(inexp[i]);
else if(inexp[i]==')')
{
while((c=pop())
