class myThread extends Thread
{
public void run()
{
int i=1;

while(i<5)
{
System.out.println(i+"kavya ");
i++;
}
}
}
class thread1
{
public static void main(String args[])
{
myThread t1=new myThread();
t1.start();
int i=1;
while(i<9)
{
System.out.println(i+"udari");
i++;
}
}
}

