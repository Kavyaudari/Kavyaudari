import java.util.*;
class vehicle
{
int v_no;
String model;
String color;
String fuel_type;
int milage;
Scanner in=new Scanner(System.in);
void getdetails()
{
System.out.println("enter the no");
v_no=in.nextInt();
System.out.println("enter the model");
model=in.next();
System.out.println("enter the color");
color=in.next();
System.out.println("enter the fueltype");
fuel_type=in.next();
System.out.println("enter the milage");
milage=in.nextInt();
}
}
class t_wheeler extends vehicle
{
void show()
{
System.out.println(v_no+model+color+fuel_type+milage);
}
}
class f_wheeler extends vehicle
{
void display()
{
System.out.println(v_no+model+color+fuel_type+milage);
}
public static void main(String args[])
{
System.out.println("enter");
f_wheeler f=new f_wheeler();
System.out.println("enter two ");
f.getdetails();
f.show();
System.out.println("enter f");
f.getdetails();
f.display();
}
}
