import branch.cse;
import branch.ece;
import branch.me;
import branch.ce;
public class week8_3
{
public static void main(String args[])
{
cse c1=new cse();
ece e1=new ece();
me m1=new me();
ce r1=new ce();
c1.display();
e1.display();
m1.display();
r1.display();
}
}

