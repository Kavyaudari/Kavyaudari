#include<stdio.h>
int main()
{
char x='A';
printf("%c\n",x);
printf("%d",x);
return 0;
}
