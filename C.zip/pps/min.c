//minimum with three numbers
#include<stdio.h>
int main()
{
int a,b,c;
printf("enter a,b,c values");
scanf("%d%d%d",&a,&b,&c);
if(a<b,a<c)
{
printf("a is minimum");
}
else
{
printf("a is maximum");
}
return 0;
}
