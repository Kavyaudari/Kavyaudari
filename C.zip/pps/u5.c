//power without rec
#include<stdio.h>
int p(int,int);
int main()
{
int a,b,c;
printf("enter values");
scanf("%d%d",&a,&b);
c=p(a,b);
printf("%d",c);
}
int p(int x, int y)
{
int z=1,i;
for(i=1;i<=y;i++)
{
z=z*x;
}
return z;
}
