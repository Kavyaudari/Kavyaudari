//perimeter of cirle
#include<stdio.h>
float main()
{
float a,b,c,d;
a=2;
printf("enter b,c value");
scanf("%f%f",&b,&c);
d=a*b*c;
printf("%f",d);
return 0;
}


 
