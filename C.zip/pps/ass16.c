//week
#include<stdio.h>
int main()
{
int day;
printf("enter your day");
scanf("%d",&day);
switch(day<=7)
{
case '1':printf("monday");
	break;
case '2':printf("tuesday");
	break;
}
}	
