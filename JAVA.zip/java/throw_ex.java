import java.util.*;
public class throw_ex
{
public static  void validate(int age)
{
if(age<18)
{
throw new ArithmeticException("age need to be greater than 18 to cast their vote ");
}
else
{
System.out.println("yes you are eligible to vote ");
}}
public static void main(String args[])
{
System.out.println("enter the age to check ");
Scanner in=new Scanner(System.in);
int a=in.nextInt();
validate(a);
}
}


