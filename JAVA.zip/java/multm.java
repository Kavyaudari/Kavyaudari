import java.util.*;
class multm
{
public static void main(String args[])
{
int m,n,p,q;
Scanner in=new Scanner(System.in);
System.out.println("enter the size");
m=in.nextInt();
n=in.nextInt();
p=in.nextInt();
q=in.nextInt();
int sum=0;
if(n!=p)
{
System.out.println("not possible ");
}
else
{
int a[][]=new int[m][n];
int b[][]=new int[p][q];
int t[][]=new int[m][q];
System.out.println("enter the elements ");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
a[i][j]=in.nextInt();
}
}
System.out.println("enter the elements");
for(int i=0;i<p;i++)
{
for(int j=0;j<q;j++)
{
b[i][j]=in.nextInt();
}
}
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
for(int k=0;k<p;k++)
{
sum=sum+a[i][k]*b[k][j];
}
t[i][j]=sum;
sum=0;
}
}
System.out.println("multply=");
for(int i=0;i<p;i++)
{
for(int j=0;j<q;j++)
{
System.out.print(t[i][j]+"\t");
}
System.out.print("\n");
}
}
}
}
