//with arguments and without return type
#include<stdio.h>
void fun(int,int);
void main()
{
int x=2,y=3,z;
z=fun(x,y);
}
void fun()
{
int a=2,b=3;
int c;
c=a*b;
printf("%d",c);
}
