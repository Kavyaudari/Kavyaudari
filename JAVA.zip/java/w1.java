/*import java.util.*;
class w1
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the elements ");
double a=in.nextDouble();
double b=in.nextDouble();
double c=in.nextDouble();
double d;
d=b*b-4.0*a;
if(d>0.0)
{
double r1=-b+(Math.pow(d,0.5))/2.0*a;
double r2=-b-(Math.pow(d,0.5))/2.0*a;
System.out.println("the roots are ");
System.out.println(r1);
System.out.println(r2);
}
else if(d==0.0)
{
double r=(-b/2*a);
System.out.println("the are equal ");
}
else
{
System.out.println("roots are imaginary ");
}
}
}

import java.util.*;
class w1
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the elements ");
int a=in.nextInt();
int b=in.nextInt();
System.out.println("enter case to perform operations ");
int n=in.nextInt();
switch(n)
{
case 1:System.out.println("the addition ="+(a+b));
break;
case 2:System.out.println("subtraction ="+(a-b));
break;
case 3:System.out.println("multiplication = "+(a*b));
break;
case 4:System.out.println("division ="+(a/b));
break;
case 5:System.out.println("modulo ="+(a%b));
break;
}
}
}

import java.util.*;
class w1
{
public static void main(String args[])
{
System.out.println("enter the number ");
Scanner in=new Scanner(System.in);
int a=in.nextInt();
int c=0;
if(a>=2&&a%2==0)
{
System.out.println("2");
}
for(int i=1;i<=a;i++)
{
if(a%i==0)
{
for(int j=2;j<i;j++)
{
if(i%j==0)
{
c=0;
break;
}
else
{
c=1;
}
}
if(c==1)
{
System.out.println(i);
}
}
}
}
}


import java.util.*;
class w1{
public static void main(String args[])
{
System.out.println("enter the number ");
Scanner in=new Scanner(System.in);
int a=in.nextInt();
int t=a;
int sum=0;
while(a>0)
{
sum=sum*10;
int r=a%10;
sum=sum+r;
a=a/10;
}
if(sum==t)
{
System.out.println("yes it is a palindrome ");
}
else
{
System.out.println("no ");
}
}
}
*/

