
import java.util.*;
import java.math.*;
class subset{
    int arr[];
    int n;
    int sum;
    Scanner in=new Scanner(System.in);
    subset(int n,int sum)
    {
        this.n=n;
         this.sum=sum;
    
        arr=new int[n];
    
    System.out.println("enter the values of arrays");

    for(int i=0;i<n;i++)
    {
        arr[i]=in.nextInt();

    }
}
    int  ss( int n, int sum)
    {
    
        if(sum==0)
        { 
            return  0;
        }
        if(n==0)
        {
            return Integer.MAX_VALUE-1000;
        }
        if(arr[n-1]<=sum)
        {
            return Math.min(1+ss(n,sum-arr[n-1]),ss(n-1,sum));
        }
        else
        return ss(n-1,sum);

    }
}
class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of coins");
        int n=in.nextInt();
        System.out.println("enter the target value");
        int sum=in.nextInt();
        subset s=new subset(n,sum);
        System.out.println("the  min no of coins:"+s.ss(n,sum));
    }
}
