import java.util.*;
class Conversion
{
public static void main(String args[])
{
System.out.println("Automatic conversion");
Scanner in=new Scanner(System.in);
System.out.println("enter a");
int a=in.nextInt();
float b=a;
System.out.println(b);
System.out.println("enter c");
float c=in.nextFloat();
int d=(int)c;
System.out.println(d);
}
}

