//exponential
#include<stdio.h>
int p(int,int);
int main()
{
int a,b,t;
printf("enter a, b value");
scanf("%d%d",&a,&b);
t=p(a,b);
printf("%d",t);
}
int p(int x,int y)
{
int i,z=1;
for(i=1;i<=y;i++)
{
z=z*x;
}
return(z);
}
