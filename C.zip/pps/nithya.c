#include<stdio.h>
int main()
{
int num,i,j,t;
int first,last,middle;
printf("enter the array size");
scanf("%d",&num);
int a[num];
printf("enter th e elements\n");
for(i=0;i<num;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<num;i++)
{
for(j=i+1;j<num;j++)
{
if(a[i]>a[j])
{
t=a[i];
a[i]=a[j];
a[j]=t;
}
}
}
printf("enter the element you want search");
scanf("%d",&num);
first=0;
last=num-1;
middle=(first+last)/2;
while(first<=last)
{
if(a[middle]<num)
{
first=middle+1;
}
else if(a[middle]==num)
{
printf("%d num is present in %d index",num,middle);
break;
}
else
last=middle-1;
middle=(first+last)/2;
}
if(first>last)
{
printf("element is not found");
}
}
