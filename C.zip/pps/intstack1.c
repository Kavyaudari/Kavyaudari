#include<stdio.h>
#include<stdlib.h>
struct node 
{
int data;
struct node *next;
}*new,*top=0,*temp;
void push()
{
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
if(top==0)
{
top=new;
}
else
{
temp=top;
new->next=temp;
top=new;
}
}
void pop()
{
temp=top;
if(top==0)
{
printf("underflow");
}
else
{
printf("popped element is %d",top->data);
top=top->next;
free(temp);
}
}
void display()
{
temp=top;
if(top==0)
{
printf("underflow");
}
else
while(temp!=0)
{
printf("%d",temp->data);
temp=temp->next;
}
}
int main()
{
int ch;
printf("\n1=push\n2=pop\n3=display\n");
while(ch!=-1)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1:push();
break;
case 2:pop();
break;
case 3:display();
break;
default:printf("wrong");
break;
}
}
}

