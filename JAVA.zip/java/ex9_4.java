class ex9_4
{
public static void main(String args[])
{
try{
Class.forName("rhyme");
}
catch(Exception e)
{
System.out.println(e);
}
}
}
