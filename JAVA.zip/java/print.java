import interface1.inter;
public class print implements inter
{
public void display()
{
System.out.println("this is interface");
}
public static void main(String args[])
{
print p=new print();
p.display();
}
}

