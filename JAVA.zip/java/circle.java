package org.shapes;
import java.util.*;
public class circle
{
public int r;
public void set2(int r)
{
this.r=r;
}
public void print()
{
System.out.println("area="+r*r*3.14);
}
}

