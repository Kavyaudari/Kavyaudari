import java.util.*;
class cemp
{
String desig;
double salary;
public void setDesign(String desig)
{
this.desig=desig;
}
public void getDesign()
{
System.out.println(desig);
}
}
class hemp extends cemp
{
int hrs,wageph;
hemp(String design,int hrs,int wageph)
{
super.setDesign(desig);
this.hrs=hrs;
this.wageph=wageph;
}
void calwage()
{
System.out.println(hrs*wageph*30);
}
void getDesignation()
{
System.out.println(super.desig);
}
}
class wemp extends cemp
{
int wks,wagepw;
wemp(String design,int wks,int wagepw)
{
super.setDesign(desig);
this.wks=wks;
this.wagepw=wagepw;
}
void calwage()
{
System.out.println(wks*wagepw*30);
}
void getDesignation()
{
System.out.println(super.desig);
}
}
class ex6_4
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
String desig=in.next();
cemp c1=new cemp();
c1.setDesign(desig);
c1.getDesign();
int hrs=in.nextInt();
int wageph=in.nextInt();
hemp h1=new hemp(desig,hrs,wageph);
h1.calwage();
h1.getDesignation();
int wks=in.nextInt();
int wagepw=in.nextInt();
wemp w1=new wemp(desig,wks,wagepw);
w1.calwage();
w1.getDesignation();
}
}

