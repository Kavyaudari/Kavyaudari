//swapping of two pointers 
#include<stdio.h>
int main()
{
int a,b;
printf("enter a,b values");
scanf("%d%d",&a,&b);
int * p1,* p2;
p1=&a;
p2=&b;
printf("before swapping=%d%d",*p1,*p2);
* p1=* p1+* p2;
* p2=* p1-* p2;
* p1=* p1-* p2;
printf("after swapping=%d %d",*p1,*p2);
}
