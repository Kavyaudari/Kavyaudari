#include<stdio.h>
int binary(int [],int,int);
int main()
{
int n,i,j,k,t;
printf("enter the size");
scanf("%d",&n);
int a[n];
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
for(j=0;j<n-1;j++)
{
if(a[j]>a[j+1])
{
t=a[j];
a[j]=a[j+1];
a[j+1]=t;
}
}
}
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
printf("element");
scanf("%d",&k);
int b=binary(a,n,k);
if(b==-1)
printf("element not found");
else 
printf("%d",b);
}
int binary(int a[],int n,int k)
{
int f=0,l=n-1;
int m;
while(f<=l)
{
m=f+l/2;
if(a[m]<k)
f=m+1;
else if(a[m]==k)
return m;
else
l=m-1;
}
if(f>l)
return -1;
}

