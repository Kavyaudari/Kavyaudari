#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*tail,*newnode,*temp,*head;
int read()
{
int a;
printf("enter the data\n");
scanf("%d",&a);
return a;
}
void insertbeg()
{
newnode=maloc(sizeof(struct node());
newnode->next=head;//
printf("enter the details");
scanf("%d",&new->data);


