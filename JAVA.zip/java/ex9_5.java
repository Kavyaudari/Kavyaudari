class ex9_5
{
public static void main(String args[])
{
try
{
String s="hello";
int i=Integer.parseInt(s);
}
catch(Exception e)
{
System.out.println(e);
}
}
}
