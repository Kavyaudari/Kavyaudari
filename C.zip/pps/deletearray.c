//delete element from specific position
#include<stdio.h>
int main()
{
int n,i,p;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("enter position");
scanf("%d",&p);
for(i=p;i<n;i++)
{
a[i]=a[i+1];
}
printf("after deleting");
for(i=0;i<n-1;i++)
{
printf("%d",a[i]);
}
}
