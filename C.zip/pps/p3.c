//with arguments with return type
#include<stdio.h>
void fact(int,int);
void main()
{
int a,b,c
printf("enter the values");
scanf("%d%d",&a,&b);
c=fact(a,b);
}
void fact(int x,int y)
{
int z;
z=x*y;
printf("%d",z);
}
