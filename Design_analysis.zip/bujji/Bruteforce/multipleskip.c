 #include<stdio.h>
#include<string.h>
void main()
{


int f=0;
int flag=0;
int c=0;
char a[100];
char b[100];
printf("enter the string ");
scanf("%s",a);
printf("enter the substring ");
scanf("%s",b);
int m=strlen(a);
int n=strlen(b);
for(int i=0;i<=m-n;i++)
{
if(a[i]==b[0])
{
 int flag=0;
for(int j=0;j<n;j++)
{
if(b[j]!=a[i+(j*(j+3))/2])
{
flag=1;
break;
}
}
if(flag==0)
{
printf("%d\n",i);
c++;
}
}
}
printf("%d",c);
}





