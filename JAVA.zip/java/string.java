import java.util.*;
class string
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the str1 ");
String str1=in.nextLine();
System.out.println(str1);
System.out.println("enter the str2 ");
String str2=in.nextLine();
System.out.println("comparision"+str1.compareTo(str2));//it compares str2-str1
System.out.println(str1.equals(str2));
System.out.println("case"+str1.equalsIgnoreCase(str2));//it ignores the case
System.out.println("index"+str1.indexOf(str2));
System.out.println("length of str"+str1.length());//length
System.out.println("length of str2"+str2.length());
System.out.println("char="+str1.charAt(0));//gives char at that index
System.out.println(str1.charAt(4));
System.out.println(str1.charAt(3));
System.out.println(str1.charAt(2));
System.out.println(str1.charAt(1));
System.out.println(str1.charAt(0));
int n=str1.length();//length to reverse the string
System.out.println("length of str1:"+n);
System.out.println("reverse of str1:");
for(int i=n-1;i>=0;i--)
{
System.out.println(str1.charAt(i));//reverse of string
}
System.out.println("concate"+str1.concat(" ").concat(str2));//concatination
int vcount=0;//to count no of vowels and consonants
int ccount=0;
String str=str1.toLowerCase();//upper to lower and vice versa
System.out.println("lower :"+str);
String stra=str1.toUpperCase();
System.out.println("upper :"+stra);
for(int i=0;i<str.length();i++)
{
if(str.charAt(i)=='a'||str.charAt(i)=='e'||str.charAt(i)=='i'||str.charAt(i)=='o'||str.charAt(i)=='u')
{
vcount++;
System.out.println(str.charAt(i));
}
else if(str.charAt(i)>='a'&&str.charAt(i)<='z')
{
ccount++;
}
}
System.out.println("vowel count="+vcount);
System.out.println("consonant count="+ccount);
System.out.println("enter the char");//to check wether string ends with that char
String c=in.nextLine();
System.out.println(str1.endsWith(c));
System.out.println(str1.startsWith(c));
}
}



