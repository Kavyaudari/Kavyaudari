//1+x+x^2+x^3
#include<stdio.h>
#include<math.h>
int main()
{
int i;
int x;
int n;
int sum=1;
printf("enter x and n");
scanf("%d%d",&x,&n);
for(i=1;i<=n;i++)
{
sum=sum+pow(x,i);
}
printf("%d\n",sum);
}
