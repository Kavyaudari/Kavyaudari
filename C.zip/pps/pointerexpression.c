//pointer expressions
#include<stdio.h>
int main()
{
int p=5,*q,r;
q=&p;
//r=*q*3+10-20/5;
r=((*q)*3)+10-(20/5);
printf("%d",r);
}
