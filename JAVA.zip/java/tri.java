package shape;
public class tri
{
public void area(double l,double b)
{
System.out.println(0.5*l*b);
}
public void perimeter(double x,double y,double z)
{
System.out.println(x+y+z);
}
}
