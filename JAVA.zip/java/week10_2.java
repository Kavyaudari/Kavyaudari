class Super
{
int a,b;
void set1(int a,int b)
{
this.a=a;
this.b=b;
}
int getvalue1()
{
return(a/b);
}
}
class sub extends Super
{
int a,b,c;
void set2(int a,int b,int c)
{
this.a=a;
this.b=b;
this.c=c;
}
int getvalue2()
{
return((a/b)*c);
}
}
class week10_2
{
public static void main(String args[])
{
try
{
sub s1=new sub();
s1.set2(12,5,0);
System.out.println(s1.getvalue2());
s1.set1(5,0);
System.out.println(s1.getvalue1());
}
/*catch(Exception e)
{
System.out.println(e);
}*/
catch(ArithmeticException e)
{
System.out.println(e);
}
catch(NullPointerException e)
{
System.out.println(e);
}
catch(Exception e)
{
System.out.println(e);
}
}
}
 
