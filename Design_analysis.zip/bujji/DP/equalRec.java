import java.util.*;
class equal{
    int a[];
    int n;
   // Scanner in=new Scanner(System.in);
     equal(int n)
    {
        this.n=n;
        a=new int[n];
        }

    boolean es(int n,int x)
    {
       
        if(x==0)
        {
            return true;
        }
        if(n==0&&x!=0)
        {
        return false;
        }
        
               if(a[n-1]<=x)
        {
            return es(n-1,x-a[n-1])||es(n-1,x);
        }
        else{
            return es(n-1,x);
        }
    }


}
class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of items");
        int n=in.nextInt();
        equal s=new equal(n);
        System.out.println("enter the array");
        for(int i=0;i<n;i++)
        {
          s.a[i]=in.nextInt();
        }

    
    int x;
    int sum=0;
    for(int i=0;i<n;i++)
    {
        sum=sum+s.a[i];
    }
     //System.out.println(sum);
    x=sum/2;
    if(sum%2!=0)
    {
    System.out.println("the  preseence   equal partition of subset is:false");
    
    }
    else
    {
        System.out.println("the  preseence   equal partition of subset is:"+s.es(n,x));    
    }
}}
