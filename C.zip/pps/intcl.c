#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*head,*new,*ptr,*ptr1;
struct node *create()
{
int n;
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&n);
if(n==-1)
{
return 0;
}
else
{
new->data=n;
}
}
void inbeg()
{
ptr=head;
new=create();
if(ptr==0)
{
head=new;
head->next=new;
}
else
{
new->next=ptr->next;
ptr->next=new;
}

}
void inend()
{
ptr=head;
new=create();
if(ptr==0)
{
head=new;
head->next=new;
}
else
{
new->next=ptr->next;
ptr->next=new;
}
}
void inpos()
{
int p,i;
printf("enter thee pos");
scanf("%d",&p);
ptr=head->next;
for(i=1;i<p-1;i++)
{
ptr=ptr->next;
}
new->next=ptr->next;
ptr->next=new;
}
void traverse()
{
ptr=head->next;

void main()
{
int ch;
printf("\n1=beg\n2=end\n3=pos\n4=trav\n5=beg\n6=end\n7=pos");
while(ch!=8)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1:insbeg();
break;
case 2:insend();
break;
case 3:inspos();
break;
case 4:traverse();
break;
/*case 5:delbeg();
break;
case 6:delend();
break;
case 7:delpos();
break;*/
default:printf("enter the correct input");
break;
}
}
}

