//reading array elements
#include<stdio.h>
int main()
{
int n,i;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements\n");
int *p;
p=&a[0];
for(i=0;i<n;i++)
{
scanf("%d",&*(p+i));
}
for(i=0;i<n;i++)
{
printf("%d",*(p+i));
}
printf("\n");
}
