#include<stdio.h>
#include<stdlib.h>
#define n 9
int s[n];
int top=-1;
void push(int);
void pop();
void display();
void push(int ele)
{
if(top>n)
{
printf("stack is overflow");
}
else if(top==-1)
{
top=0;
s[top]=ele;
}
else
{
top++;
s[top]=ele;
}
}
void pop()
{
if(top==-1)
{
printf("stack is underflow");
}
else
{
printf("%d",s[top]);
top--;
}
}
void display()
{
int i;
if(top==-1)
printf("stack is underflow");
else
{
for(i=top;i>=0;i--)//for condition should be in decrementation
{
printf("%d",s[i]);
}
}
}
void main()
{
int ch,ele;
printf("\n1=push\n2=pop\n3=display");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the ele");
scanf("%d",&ele);
push(ele);
break;
case 2:pop();
break;
case 3:display();
break;
default:printf("wrong");
break;
}
}
}
