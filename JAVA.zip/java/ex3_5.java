import java.util.*;
class ex3_5
{
public static void main(String args[])
{
books b1=new books("oops","karthik",50);
customer c1=new customer("kavya","hyd",40);
c1.buy(b1,30);
}
}
class books
{
String n;
String a;
int c;
books(String n,String a,int c)
{
this.n=n;
this.a=a;
this.c=c;
}
public void sell(int n)
{
if(c<n)
{
System.out.println("not there");
}
else
{
c=c-n;
System.out.println("remain= " +c);
}
}
}
class customer
{
String Cn;
String Ca;
int cost;
customer(String Cn,String Ca,int cost)
{
this.Cn=Cn;
this.Ca=Ca;
this.cost=cost;
}
public void buy(books b,int n)
{
System.out.println("book name = " +b);
b.sell(n);
}
}

