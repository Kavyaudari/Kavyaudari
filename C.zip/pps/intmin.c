//avg,max,min
#include<stdio.h>
int main()
{
int n,i,s=0,avg=0,min,max;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}

for(i=0;i<n;i++)
{
s=s+a[i];
avg=s/n;
}
for(i=0;i<n;i++)
{
if(min>a[i])
{
min=a[i];
}
if(max<a[i])
{
max=a[i];
}
}
printf("%d %d %d ",avg,max,min);
}
