#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#define n 30
char s[n];
int top=-1;
void push(char x);
char pop();
int pri(char);
void push(char x)
{
top++;
s[top]=x;
}
char pop()
{
char x;
x=s[top];
top--;
return x;
}
int pri(char sy)
{
if(sy=='^')
return(3);
else if(sy=='*'||sy=='/')
return(2);
else if(sy=='+'||sy=='-')
return(1);
else if(sy=='(')
return 0;
}
void main()
{
char in[30], ele,*ch;
printf("enter the ex");
gets(in);
ch=in;
while(*ch!='\0')
{
if(*ch=='(')
push(*ch);
else if(*ch==')')
{
while(ele=pop()!='(')
{
printf("%c",ele);
}
}
else
{
while(pri(*ch)<=pri(s[top]))
printf("%c",pop());
push(*ch);
}ch++;
}
while(top!=-1)
{
printf("%c",pop());
}
}
