public class ex10_1 extends Thread
{
public void run()
{
int i=0;
while(true)
{
System.out.println("thread " +i++);
}
}
public static void main(String args[])
{
ex10_1 e1=new ex10_1();
e1.start();
int i=0;
while(true)
{
System.out.println("main" +i++);
}
}
}

