#include<stdio.h>
char stack[100],ele;
int stack1[100],ele1;
int top=-1,size=10,max=9,min=-1;
int top1=-1;
//int stack1[100],ele1;
//int a,b,c,d;
//printf("enter the values");
//scanf("%d%d%d%d",&a,&b,&c,&d);
void push(char ele)
{
if(top==max)
printf("stack overflow");
else
 {
	top++;
	stack[top]=ele;
	printf("\n%c inseted successfully\n",ele);
 }
}
int push1(int ele1)
{
	if(top1==max)
	printf("stack is overflow");
	else
	{
	top1++;
	stack1[top1]=ele1;
	printf("\n%d is inserted successfully\n",ele1);
	}
}
char pop()
{
if(top==min)
{
printf("stack underflow");
return (0);
}
else
{
ele=stack[top];
top--;
printf("\n%c is popped\n",ele);
return (ele);
}
}
int pop1()
{
if(top1==min)
{
printf("stack underflow");
return (0);
}
else
{
ele1=stack1[top1];
top1--;
printf("\n%d is popped\n",ele1);
return(ele1);
}
}
void display()
{
int i;
printf("\nstack elements are:\n");
for(i=0;i<=top;i++)
printf("%c\n",stack[i]);
}
void display1()
{
int i;
printf("\nstack elements are:\n");
for(i=0;i<=top1;i++)
printf("%c\n",stack1[i]);
}
int priority(char op)
{
if(op=='+'||op=='-')
return (2);
else 
return (1);
}

void main()
{
char infix[]="a+b*c+d";
int a,b,c,d,val1,val2;
a=2;b=3;c=4;d=5;
int i,pos=0;
char postfix[100],o1,o2;
for(i=0;infix[i]!='\0';i++)
{
if(infix[i]=='+'||infix[i]=='-'||infix[i]=='*'||infix[i]=='/')
{
while((priority(infix[i])>=priority(stack[top]))&&(top>min))
{
ele=pop();
postfix[pos]=ele;
pos++;
}
push(infix[i]);
}
else
{
postfix[pos]=infix[i];
pos++;
}
}
while(top>min)
{
ele=pop();
postfix[pos]=ele;
pos++;
}
printf("\n postfix expression is %s\n",postfix);
for(i=0;postfix[i]!='\0';i++)
{
if((postfix[i]=='+')||(postfix[i]=='-')||(postfix[i]=='*')||(postfix[i]=='/'))
{
val1=pop1();
val2=pop1();
switch(postfix[i])
{
case '+':push1(val1+val2);
break;
case '-':push1(val1-val2);
break;
case '*':push1(val1*val2);
break;
case '/':push1(val1/val2);
break;
}
}
else
{
switch(postfix[i])
{
case 'a':val1=a;
break;
case 'b':val1=b;
break;
case 'c':val1=c;
break;
case 'd':val1=d;
break;
}
push1(val1);
}
}
printf("Ans=%d",pop1());
}



