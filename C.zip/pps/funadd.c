//functions
//addition
#include<stdio.h>
int addition(int,int);
int main()
{
int a,b,c;
printf("enter two numbers");
scanf("%d%d",&a,&b);
c=addition(a,b);
printf("c=%d",c);
}
int addition(int x,int y)
{
int z;
z=x+y;
return(z);
}
