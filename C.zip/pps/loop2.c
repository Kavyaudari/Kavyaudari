//loops
#include<stdio.h>
int main()
{
int i,j;
for(i=1,j=0;i<=5;i++)
{
printf("%d%d",i,j);
}
return 0;
}
