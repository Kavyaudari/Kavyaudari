//avg,min,max of the array
#include<stdio.h>
int main()
{
int n;
printf("enter the size;");
scanf("%d",&n);
int i,sum=0,min,max;
float avg;
int x[n];
printf("enter n integers");
for(i=0;i<5;i++){
scanf("%d",&x[i]);
}
max=x[0];
min=x[0];
for(i=1;i<n;i++)
if(x[i]>max)
{
max=x[i];
}
else
{
(x[i]<min);
{
min=x[i];
}
}
printf("%d",max);
printf("%d",min);
for(i=0;i<5;i++){
sum=sum+x[i];

}
printf("sum=%d\n",sum);
//printf("the no are");
//for(i=0;i<5;i++){
//printf("%d",x[i]);
//}
avg=sum/5.0;
printf("%f",avg); 

return 0;
}
