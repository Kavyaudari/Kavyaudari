//rec
#include<stdio.h>
int fact(int);
int main()
{
int n,f=1;
printf("enter n value");
scanf("%d",&n);
f=fact(n);
printf("%d",f);
}
int fact(int x)
{
if(x==1||x==0)
{
return(x);
}
else
return(x*fact(x-1));
}
