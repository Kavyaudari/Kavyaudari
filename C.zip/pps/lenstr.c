//pointers arithematic
#include<stdio.h>
int main()
{
char str[10];
printf("enterr string");
gets(str);
char *p;
p=str;
int c=0;
while(*p!='\0')
{
c++;
p++;
}
printf("%d",c);
}
