//1-x/2+x^2/4
#include<stdio.h>
#include<math.h>
int main()
{
int n,x,t=-1,i;
float s=1;
printf("enter n x values");
scanf("%d%d",&n,&x);
for(i=1;i<=n;i++)
{
s=s+t*pow(x,i)/(float)(2*i);
t=t*(-1);
}
printf("%f",s);
}
