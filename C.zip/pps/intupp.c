//uppercase
#include<stdio.h>
int main()
{
char l;
printf("enter character");
scanf("%c",&l);
if(l>='A'&&l<='Z')
{
l=l+32;
printf("%c",l);
}
else if(l>='a'&&l<='z')
{
l=l-32;
printf("%c",l);
}
else
printf("wrong");
}
