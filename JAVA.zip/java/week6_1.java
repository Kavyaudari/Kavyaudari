class a
{
void area(float x)
{
System.out.println("the area of square="+x*x);
}
void area(float x ,float y)
{
System.out.println("the area of rectangle="+x*y);
}
void area(double x)
{
double a=(3.14*x*x);
System.out.println("the area of circle="+a);
}
void area(int x,int y)
{
float f=(x*y)/2;
System.out.println("the area of triangle="+f);
}
}
class week6_1
{
public static void main(String args[])
{
a a1=new a();
a1.area(10);
a1.area(10,20);
a1.area(10);
a1.area(10,30);
}
}

