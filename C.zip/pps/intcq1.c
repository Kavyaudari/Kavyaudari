#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*ptr,*front=0;*rear=0;
void enq()
{
new=malloc(sizeof(struct node));
printf("enter the data:");
scanf("%d",&new->data);
if((rear==0)&&(front==0))
{
front=rear=new;
rear->next=front;
}
else
{
rear->next=new;
rear=new;
rear->next=front;
}
}
void deq()
{
if((front==0)&&(rear==0))
{
printf("emty");
}
else if(front==rear)
{
front=0;rear=0;
}
else
{
ptr=front;
printf("%d",front->data);
front=front->next;
rear->next=front;
free(ptr);
}
}
void dis()
{
if((front==0)&&(rear==0))
{
printf("emty");
}
else
{
ptr=front;
while(ptr->next!=front)
{
printf("%d",ptr->data);
ptr=ptr->next;
}
printf("%d",ptr->data);
}
}
void main()
{
int ch;
printf("\n1=enq\n2=deq\n3=dis\n");
while(ch!=4)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1:enq();
break;
case 2:deq();
break;
case 3:dis();
break;
default:printf("wrong");
break;
}
}
}
