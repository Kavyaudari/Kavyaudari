//bitwise operators
#include<stdio.h>
int main()
{
 int a=7,b=9,c,d,e,f,g;
 c=a&b;//bitwise and
 d=a|b;//bitwise or
 e=a^b;//bitwise xor
 f=a>>b;//rightshift
 g=a<<b;//leftshfit
 printf("%d\n%d\n%d\n%d\n%d\n",c,d,e,f,g);
 return 0;
}

