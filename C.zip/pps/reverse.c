//revese of a number
#include<stdio.h>
int main()
{
int num,rev=0,r;
printf("enter the value of num");
scanf("%d",&num);
while(num>0)
{
r=num%10;
rev=(rev*10)+r;
num=num/10;
}
printf("reverse of a num%d",rev);
return 0;
}

