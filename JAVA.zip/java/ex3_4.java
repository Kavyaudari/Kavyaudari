import java.util.*;
class ex3_4
{
public static void main(String args[])
{
int n=0,m=0;
int dice1;int dice2;
Scanner in=new Scanner(System.in);
Random r=new Random();
dice1=r.nextInt(6);
dice2=r.nextInt(6);
for(int i=0;i<3;i++)
{
System.out.println("enter the number ");
dice1=in.nextInt();
dice2=in.nextInt();
if((dice1>=1&&dice1<=6)&&(dice2>=1&&dice2<=6))
{
if(dice1==dice2)
{
n++;
}
else
{
m++;
}
}
}
System.out.println(m);
System.out.println(n);
}
}

