//import java.util.*;
import p1.A;
public class B
{
public static void main(String args[])
{
p1.A a=new p1.A();
a.display();
}
}

