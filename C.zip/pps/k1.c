//eve sum odd sum
#include<stdio.h>
int main()
{
int n,i,e=0,o=0;
printf("enter n value");
scanf("%d",&n);
for(i=0;i<=n;i++)
{
if(i%2==0)
{
e=e+i;
}
else
o=o+i;
}
printf("even=%d",e);
printf("odd=%d",o);
}
