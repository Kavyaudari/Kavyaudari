//fab
#include<stdio.h>
int main()
{
int t1=0,t2=1,t3,i,n;
printf("input n");
scanf("%d",&n);
//printf("the series");
i=0;
while(i<=n)
{
printf("%d",t1);
t3=t1+t2;
t1=t2;
t2=t3;
i++;
}
printf(" is the series");

}
