#include<stdio.h>
#include<math.h>
int main()
{
int n,i,j,sum=0,s=0;
float avg=0,v,sd;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
sum=sum+a[i];
avg=sum/n;
}
{
s=sum+pow((a[i]-avg),2);
}
{
v=s/n;
}
sd=sqrt(v);
printf("%f\n",avg);
printf("%f\n",v);
printf("%f",sd);
}
