#include<stdio.h>
int gcd(int,int);
int main()
{
int a,b,c;
printf("enter the a,b values");
scanf("%d%d",&a,&b);
c=gcd(a,b);
printf("%d",c);
}
int gcd(int x,int y)
{
int z;
if(x==0)
{
return(y);
}
z=y%x;
y=x;
x=z;
return gcd(x,y);
}
