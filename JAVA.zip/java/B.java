//import java.util.*;
import p1.A;
import p1.C1;
public class B
{
public static void main(String args[])
{
//p1.A a=new p1.A();
A a=new A();
C1 c1=new C1();
a.display();
c1.print();
}
}

