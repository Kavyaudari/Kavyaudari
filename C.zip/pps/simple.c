//simple interest
#include<stdio.h>
#include<math.h>
int main()
{
int P;
float T;
float R;
float si;
float ci;
printf("enter P,T,R values");
scanf("%d%f%f",&P,&T,&R);
si=(P*T*R)/100;
printf("simple interest is %f\n",si);
ci=P*pow(1+R/100,T);
printf("compound interest is %f\n",ci);
return 0;
}
