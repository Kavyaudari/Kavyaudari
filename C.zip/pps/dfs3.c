#include<stdio.h>
#include<stdlib.h>
#define n 10
int adj[n][n];
int s[n];
int top=-1;
int vis[n]={0};
void addedge(int s,int d)
{
adj[s][d]=1;
adj[d][s]=1;
}
void dfs(int start)
{
int v;
s[++top]=start;
while(top>=0)
{
v=s[top--];
if(vis[v]==0)
{
printf("%d",v);
vis[v]=1;
for(int i=0;i<n;i++)
{
if(adj[v][i]==1&&!vis[i])
{
s[++top]=i;
}
}
}
}
}
int main()
{
int s,d ,start;
for(int i=0;i<n;i++)
{
for(int j=0;j<n;j++)
{
adj[i][j]=0;
}
}
for(int i=0;i<n;i++)
{
printf("s&d");
scanf("%d%d",&s,&d);
if(s==-1&&d==-1)
break;
else
addedge(s,d);
}
printf("dfs");
dfs(0);
printf("\n");
}
