//array
#include<stdio.h>
int main()
{
int n,s=0,min,max,i;
float avg;
printf("enter the size of array\n");
scanf("%d",&n);
int a[n];
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
s=s+a[i];
}
avg=(s)/n;
min=a[0];
max=a[0];
for(i=0;i<n;i++)
{
if(min>a[i])
{
min=a[i];
}
if(max<a[i]);
{
max=a[i];
}
}
printf("%d  %d  %f ",min,max,avg);
}
