 class myThread extends Thread
{
public myThread(String name)
{
super(name);
}
public void run()
{
int c=1;
while(true)
{
System.out.println(c++);
try
{
Thread.sleep(10000);
}
catch(InterruptedException e)
{
System.out.println(e);
}
}
}
}
public class interrupt_thread
{
public static void main(String args[]) throws Exception 
{
myThread t1=new myThread("my second Thread ");
t1.setDaemon(true);
t1.start();
/*t1.interrupt();
try
{
Thread.sleep(1000);
}
catch(Exception e)
{
}*/
Thread mainThread =Thread.currentThread();
mainThread.join();
}
}

