import java.util.*;
class practice
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n=in.nextInt();
String name[]=new String[n];
int id=new int[n];
String address=new address[n];
double salary=new double[n];
System.out.println("enter the details of employees ");
for(int i=0;i<n;i++)
{
System.out.println("enter the details of "+(i+1));
name[i]=in.next();
id[i]=in.nextInt();
address[i]=in.next();
salary[i]=in.nextDouble();
}
System.out.println("enter the id to search ");
int Id=in.nextInt();
for(int i=0;i<n;i++)
{
if(Id==id[i])
{
System.out.println("name = " +name[i]);
System.out.println("id ="  + id[i]);
System.out.println("address = " +address[i]);
System.out.println("salary = "+salary[i]);
break;
}
}
}
}




