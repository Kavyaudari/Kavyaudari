import java.util.*;
interface fare
{
void getAmount(int k,int c);
}
class bus implements fare
{
public void getAmount(int k,int c)
{
System.out.println(k*c);
}
}
class train implements fare
{
public void getAmount(int k,int c)
{
System.out.println(k*c);
}
}
class ex7_5
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int k=in.nextInt();
int c=in.nextInt();
fare f1=new bus();
f1.getAmount(k,c);
int k1=in.nextInt();
int c1=in.nextInt();
fare f2=new train();
f2.getAmount(k1,c1);
}
}

