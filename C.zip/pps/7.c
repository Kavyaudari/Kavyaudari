//REC POW
#include<stdio.h>
int p(int,int);
int main()
{
int a,b,c;
printf("enter a,b values");
scanf("%d%d",&a,&b);
c=p(a,b);
printf("%d",c);
}
int p(int x,int y)
{
if(y==0||y==1)
{
return(x);
}
else
return(x*p(x,y-1));
}
