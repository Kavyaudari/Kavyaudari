//multiplication number
#include<stdio.h>
int main()
{
int i,num;
printf("enter the value of num");
scanf("%d",&num);
for(i=1;i<=10;i++)
{
printf("%d*%d=%d\n",num,i,num*i);
}
return 0;
}
