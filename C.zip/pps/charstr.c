//to search a char in string
#include<stdio.h>
#include<string.h>
int main()
{
char str[10];
char x;
int i;
printf("enter any char");
scanf("%c",&x);
printf("enter any string");
scanf("%s",str);
//printf("enter any char");
//scanf("%c",&x);
for(i=0;str[i]!='\0';i++)
{
if(x==str[i])
{
printf("%c is present index %d",x,i);
}
}
//if
//printf("it is not present in the string");
}


