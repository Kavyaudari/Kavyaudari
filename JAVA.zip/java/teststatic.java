//static as variable
import java.util.*;
class student
{
String name;
int roll;
static String college="rgukt";
void insert(String name,int roll)
{
this.name=name;
this.roll=roll;
}
void display()
{
System.out.println("name="+name+"roll="+roll+"college="+college);
}
}
class teststatic
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the deatils");
String name=in.nextLine();
int roll=in.nextInt();
int r=in.nextInt();
String n=in.nextLine();

student s=new student();
student s1=new student();
s.insert(name,roll);
s1.insert(n,r);
s.display();
s1.display();
}
}

