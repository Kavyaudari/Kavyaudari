//method overriding
import java.util.*;
class a
{
int r=40;
String n="kavya";
void display()
{
System.out.println("r="+r+"n"+n);
}
}
class b extends a
{
String branch="cse";
void show()
{
System.out.println("r="+r+"n"+n+branch);
}
}
class overriding
{
public static void main(String args[])
{
b r=new b();
r.show();
}
}


