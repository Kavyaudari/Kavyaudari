//queue using array
#include<stdio.h>
int q[5];
int front=-1;
int rear=-1;
int max=4;
int min=-1;
int ele;
void enqueue(int);
int  dequeue();
void display();
void main()
{
int ch,ele;
do{
printf("\n1=enqueue\n2=dequeue\n3=display\n4=exit");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the element to be inserted\n");
scanf("%d",&ele);
enqueue(ele);
break;
case 2:dequeue();
break;
case 3:display();
break;
case 4:printf("enter the valid choice\n");
break;
}
}
while(ch!=4);
}
void enqueue(int ele)
{
if(rear==max)
{
printf("queue overflow\n");
}
else
{
rear++;
q[rear]=ele;
if(front==-1)
{
front++;
printf("element %d is inserted sucessfully",ele);
}
}
}
int dequeue()
{
if((front==-1)||(front>rear))
{
printf("queue underflow");
return 0;
}
else
{
ele=q[front];
front++;
printf("%d deleted sucessfully",ele);
}
return(ele);
}
void display()
{
int i;
if((front==-1)||(front>rear))
{
printf("no elements to display");
}
else
{
for(i=front;i<=rear;i++)
{
printf("%d",q[i]);
}
}
}
