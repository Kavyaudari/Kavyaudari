//polymorphism
import java.util.*;
/*class adder
{
static int sum(int a,int b)
{
return a+b;
}
static int sum(int a,int b,int c)
{
return a+b+c;
}					//1..by changing no of arguments
}
class poly
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int x=in.nextInt();
int y=in.nextInt();
int a=in.nextInt();
int b=in.nextInt();
int c=in.nextInt();
System.out.println(adder.sum(x,y));
System.out.println(adder.sum(a,b,c));
}
}*/
class adder
{
static int sum(int a,int b)
{
return a+b;
}
static float sum(int a,float b,int c)
{
return a+b+c;
}					//1..by changing type of arguments
}
class poly
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int x=in.nextInt();
int y=in.nextInt();
int a=in.nextInt();
float b=in.nextInt();
int c=in.nextInt();
System.out.println(adder.sum(x,y));
System.out.println(adder.sum(a,b,c));
}
}
