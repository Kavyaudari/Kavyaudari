#include<stdio.h>
#include<stdlib.h>
int q[10];
int max=5;
int min=-1;
int front=-1,rear=-1;
int element;
void enque();
void deque();
void display();
int main()
{
int choice;
do
{
printf("\n1,enque\n2.deque\n3.display");
//printf("enter the choice");
scanf("%d",&choice);
switch(choice)
{
case 1:printf("enter the elements ");
scanf("%d",&element);
enque();
break;
case 2:deque();
break;
case 3:display();
break;
default:printf("invalid");
exit(0);
}
}
while(choice!=4);
}

void enque()
{
if(rear==max)
{
printf("over flow");
}
else
{
rear++;
q[rear]=element;
if(front==-1)
{
printf("the element %d is inserted",element);
}
}
}
void deque()
{
if((front==-1)&&(front>rear))
{
printf("over flow");
}
else
{
q[front]=element;
front++;
printf("%d element is deleted ",element);
}
}
void display()
{
int i;
if((front==-1)&&(front>rear))
{
printf("over flow");
}
else
{
for(i=front;i<=rear;i++)
{
printf(" %d",q[i]);
}
}
}

