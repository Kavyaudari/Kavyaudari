class ex10_2 extends Thread
{
public void check()
{
System.out.println("not over ");
}
public void run()
{
int i=0;
while(true)
{
check();
try{
Thread.sleep(100);
}
catch(Exception e)
{
System.out.println(e);
}
}
}
public static void main(String args[])
{
ex10_2 e1=new ex10_2();
e1.start();
}
}

