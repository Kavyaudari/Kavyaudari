//mean,vaiance,std
#include<stdio.h>
#include<math.h>
int main()
{
int n,i;
float avg,v,std,sum=0,s1;
printf("enter n value");
scanf("%d",&n);
int a[n];
printf("enter elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
sum=sum+a[i];
}
avg=sum/n;
s1=sum+pow((a[i]-avg),2);
v=s1/n;
std=sqrt(v);
printf("%f %f %f ",avg,v,std);
}

