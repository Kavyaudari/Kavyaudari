#include<stdio.h>
#include<stdlib.h>
void push();
void pop();
void display();
int stack[100],i,j,top=-1,n,choice=0;
int main()
{
printf("enter the size");
scanf("%d",&n);
printf("\n1=push\n2=pop\n3=display");
while(choice!=4)
{
printf("enter the choice");
scanf("%d",&choice);
switch(choice)
{
case 1:push();
break;
case 2:pop();
break;
case 3:display();
break;
default:printf("invalid");
break;
}
}
}
void push()
{
if(top==n-1)
{
printf("stack is full");
}
else
{
printf("enter the elements\n");
scanf("%d",&i);
top=top+1;
stack[top]=i;
}
}
void pop()
{
if(top==-1)
{
printf("stack is empty");
}
else
{
printf("item deleted from the list %d ",stack[top]);
top--;
}
}
void display()
{
if(top==-1)
{
printf("stack is empty");
}
else
{
for(j=top;j>=0;j--)
{
printf("%d\n",stack[j]);
}
}
}
