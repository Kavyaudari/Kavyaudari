import java.util.*;
class vehicle
{
int vno;
String vmodel;
String vcolor;
Scanner in=new Scanner(System.in);
void get()
{
System.out.println("enter details");
vno=in.nextInt();
vmodel=in.nextLine();
vcolor=in.nextLine();
}
}
class twov extends vehicle
{
void show1()
{
System.out.println("enter details of twov"+vno+vmodel+vcolor);
}
}
class four extends vehicle
{
void show2()
{
System.out.println("enter details of fourv"+vno+vmodel+vcolor);
}
}
class fourv
{
public static void main(String args[])
{
four n=new four();
System.out.println("enter details of twov");
n.get();
n.show1();
System.out.println("enter details of fourv");
n.get();
n.show2();
}
}

