import java.util.*;
class Addmatrix
{
public static void main(String args[])
{
System.out.println("enter the row of 1st matrix");
Scanner in=new Scanner(System.in);
int p=in.nextInt();
System.out.println("enter the col of 1st matrix");
int q=in.nextInt();
System.out.println("enter the row of 2nd matrix");
int r=in.nextInt();
System.out.println("enter the col of 2nd matrix");
int s=in.nextInt();
int[][] a=new int[p][q];
System.out.println("enter the first matrix");
if(p==r&&q==s)
{
for(int i=0;i<p;i++)
{
for(int j=0;j<q;j++)
{
a[i][j]=in.nextInt();
}
}
for(int i=0;i<p;i++)
{
for(int j=0;j<q;j++)
{
System.out.print(a[i][j]+" ");
}
System.out.println("");
}
int[][] b=new int[r][s];
System.out.println("enter the second matrix");
for(int i=0;i<p;i++)
{
for(int j=0;j<q;j++)
{
b[i][j]=in.nextInt();
}
}
for(int i=0;i<p;i++)
{
for(int j=0;j<q;j++)
{
System.out.print(b[i][j]+" ");
}
System.out.println("");
}
test obj=new test();
int[][] c=new int[p][s];
obj.sum(a,p,s,q,b,r,c);
//int[][] c=new int[p][s];
obj.display(c,p,s);
}
else
System.out.println("not possible");
}
}
class test
{
void sum(int a[][],int p,int s,int q,int b[][],int r,int c[][])
{
for(int i=0;i<p;i++)
{
for(int j=0;j<s;j++)
{
c[i][j]=a[i][j]+b[i][j];
}
}
}
void display(int c[][],int p,int s)
{
for(int i=0;i<p;i++)
{
for(int j=0;j<s;j++)
{
System.out.print(c[i][j]+" ");
}
System.out.println("");
}
}
}
