import java.util.*;
class Sorting
{
public static void main(String args[])
{	
Scanner in=new Scanner(System.in);
System.out.println("enter the size of array");
check obj=new check();
int n=in.nextInt();
int[] array=new int[n];
System.out.println("enter the elements");
for(int i=0;i<n;i++)
{
array[i]=in.nextInt();
}
obj.sort(array,n);
obj.display(array,n);
}
}
class check
{
void sort(int array[],int n)
{
int temp;
for(int i=0;i<n;i++)
{
for(int j=0;j<n;j++)
{
if(array[i]<array[j])
{
temp=array[i];
array[i]=array[j];
array[j]=temp;
}
}
}
}
void display(int array[],int n)
{
System.out.println("after sorting");
for(int i=0;i<n;i++)
{
System.out.println(array[i]+"\t");
}
}
}



