//factorial
#include<stdio.h>
int main()
{
int f,n,i;
printf("enter the value of f,n);
scanf("%d%d",&f,&n);
for(i=0;i<=n;i++)
{
f=f*i;
}
printf("%d",f)
return 0;
}
