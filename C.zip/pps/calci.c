//caliculator using switch operator
#include<stdio.h>
int main()
{
int a,b;
char c;
printf("enter the operator");
scanf("%c",&c);
printf("enter a, b values");
scanf("%d%d",&a,&b);
switch(c)
{
case '+':printf("addition=%d",a+b);
	break;
case '-':printf("sub=%d",a-b);
	break;
case '*':printf("mult=%d",a*b);
	break;
case '/':printf("divi=%d",a/b);
	break;
case '%':printf("mod=%d",a%b);
	break;
default:printf("invalid");
}
return 0;
}
