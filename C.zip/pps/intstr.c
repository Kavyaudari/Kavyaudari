//character
#include<stdio.h>
#include<stdlib.h>
int main()
{
char str[10];
char ch;
int i;
printf("enter any character");
scanf("%c",&ch);
printf("enter any string");
scanf("%s",str);
for(i=0;str[i]!='\0';i++)
{
if(ch==str[i])
{
printf("%c is present in index %d",ch,i);
//exit(0);
break;
}
} 
  //(ch!=str[i])
if(ch!=str[i])
printf("not present");
}



