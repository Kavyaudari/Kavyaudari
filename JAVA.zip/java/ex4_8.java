import java.util.*;
class ex4_8
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter str");
String s=in.next();
System.out.println("enter substring starting point ");

int n=in.nextInt();
String s1=s.substring(n);
System.out.println(s1);
System.out.println("enter start and end point ");
int a=in.nextInt();
int b=in.nextInt();
String s2=s.substring(a,b);
System.out.println(s2);
}
}

