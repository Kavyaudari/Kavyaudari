//sum of a number
#include<stdio.h>
int main()
{
int s=0,r,n;
printf("enter the value");
scanf("%d",&n);
do
{
r=n%10;
s=s+r;
n=n/10;
}
while(n>0);
printf("%d",s);
}
