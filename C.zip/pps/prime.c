//prime
#include<stdio.h>
int main()
{
 int a,b,c=0;
 printf("enter a value");
 scanf("%d",&a);
 for(b=1;b<=a;b++)
 { 
     if(a%b==0)
      {
        c++;
      }
 }
 if(c==2)
 {
 printf("given number is prime=%d",a);
 }
 else
 {
 printf("given number is not prime=%d",a);
 }
 return 0;
}

 
 
 
 
 
