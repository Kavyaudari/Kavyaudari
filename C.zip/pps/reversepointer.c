//pointer
#include<stdio.h>
int main()
{
int n;
int i;
int *p;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",p+i);
}
for(i=n-1;i>=0;i--)
{
printf("%d",*(p+i));
}
}
