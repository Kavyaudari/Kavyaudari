//swapping two numbers
#include<stdio.h>
void main()
{
int a,b,temp;
printf("enter the value of a\n,b\n");
scanf("%d%d",&a,&b);
temp=a;
a=b;
b=temp;
printf("after swapping the two numbers a=%d%,b=%d",a,b);
}
