import java.util.*;
abstract class employee
{
abstract void getAmount(int m,int w);
}
class he extends employee
{
public void getAmount(int m,int w)
{
System.out.println("the total wages for hourly employeed = " +(m*w));
}
}
class we extends employee
{
public void getAmount(int m,int w)
{
System.out.println("the total wages for hourly employeed = " +(m*w));
}
}
class week7_2
{
public static void main(String args[])
{
employee e1=new he();
employee e2=new we();
Scanner in=new Scanner(System.in);
System.out.println("enter the hours and wages of hourly employed ");
int m1=in.nextInt();
int n1=in.nextInt();
e1.getAmount(m1,n1);
System.out.println("enter the hours and wages of weekly employed ");
int m2=in.nextInt();
int n2=in.nextInt();
e2.getAmount(m2,n2);
}
}

