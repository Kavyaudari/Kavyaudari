import interface.inter
public class print implements inter
{
public void display()
{
System.out.println("this is interface");
}
}public class week8_5
{
public ststic void main(String args[])
{
print p=new print();
p.display();
}
}

