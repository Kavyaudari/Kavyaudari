import java.util.*;
/*class circle
{
double r;
double area()
{
return (22/7)*r*r;
}
double perimeter()
{
return 2*(22/7)*r;
}
}
class test5_2
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the radius ");
double R=in.nextDouble();
circle c1=new circle();
c1.r=R;
System.out.println("area : ");
System.out.println(c1.area());
System.out.println("perimeter ");
System.out.println(c1.perimeter());
}
}*/

class rectangle
{
int l,b;
int area()
{
return l*b;
}
int perimeter ()
{
return 2*(l+b);
}
}
class test5_2
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the l and b ");
int L=in.nextInt();
int B=in.nextInt();
rectangle r=new rectangle();
r.l=L;
r.b=B;
System.out.println("area and perimeter = ");
System.out.println(r.area());
System.out.println(r.perimeter());
}
}

