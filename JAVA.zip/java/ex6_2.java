class a
{
void display()
{
System.out.println("parent ");
}
}
class b extends a
{
void display()
{
super.display();
System.out.println("child");
}
}
class ex6_2
{
public static void main(String args[])
{
b b1=new b();
b1.display();
}
}

