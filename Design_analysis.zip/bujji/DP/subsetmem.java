import java.util.*;
class subset{
    int s[][];
    int n;
    int sum;
    int a[];
    Scanner in=new Scanner(System.in);
    subset(int n,int sum)
    {
        this.n=n;
        this.sum=sum;
        a=new int[n];
        s=new int[n+1][sum+1];
        System.out.println("enter the values of arrays");
        for(int i=0;i<n;i++)
        {
            a[i]=in.nextInt();

        }
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<sum;j++)
            {
                s[i][j]=-1;
            }
        }
    }
    int  ss(int n,int sum)
    {
        if(s[n][sum]!=-1)
        
        
        return s[n][sum];
        if(n==0)
        return s[n][sum]=0;
        if(sum==0)
        return s[n][sum]=1;
        if(a[n-1]<=sum)
        {
            if((ss(n-1,sum-a[n-1]))!=0||(ss(n-1,sum))!=0)
            {
            return s[n][sum]=1;
            }
            else
            {
            return s[n][sum]=0;
            }
        }
        else
        return  s[n][sum]=ss(n-1,sum);
    }
}
class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of items");
        int n=in.nextInt();
        System.out.println("enter the sum  value of the subset");
        int sum=in.nextInt();
        subset s=new subset(n,sum);
       
        if(s.ss(n,sum)==0)
        {
        System.out.println("false");
        }
        else
           System.out.println("true");
        

        
    
    }
}
