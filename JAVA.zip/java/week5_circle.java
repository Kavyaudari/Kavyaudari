import java.util.*;
class circle
{
int r;
double areaCircle(int r)
{
return(3.14*r*r);
}
double perimeterCircle(int r)
{
return(2*3.14*r);
}
}
class week5_circle
{
public static void main(String args[])
{
System.out.println("enter");
Scanner in=new Scanner(System.in);
circle c1=new circle();
c1.r=in.nextInt();
//circle(r);
System.out.println("area"+c1.areaCircle(c1.r));
System.out.println("perimeter"+c1.perimeterCircle(c1.r));
}
}

