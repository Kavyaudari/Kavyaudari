import java.util.*;
import java.math.*;
class matrix{
int a[];
int n;
Scanner in=new Scanner(System.in);
public matrix(int  n)
{
this.n=n;
a=new int[n];
System.out.println("Enter the array");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
}

int mcm(int i,int j)
{
if(i==j)
return 0;
int min=Integer.MAX_VALUE;
for(int k=i;k<j;k++)
{
int val=mcm(i,k)+mcm(k+1,j)+a[i-1]*a[k]*a[j];
if(val<min)
{
min=val;
}
}
return  min;
}
}


class test{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n");
int n;
n=in.nextInt();
matrix m=new matrix(n);
System.out.println(m.mcm(1,n-1));
}
}

