import java.util.*;
import java.math.*;
class knapsack{
    int n;
    int w;
    int a[][];
    int val[];
    int wt[];
    public knapsack(int n,int w)
    {
        this.w=w;
        this.n=n;
        wt=new int[n];
        val=new int[n];
        Scanner in=new Scanner(System.in);
        a=new int[n+1][w+1];
        for(int i=0;i<n;i++)
        {
        System.out.println("enter the weight of "+(i+1)+ "item ");
        wt[i]=in.nextInt();
        }
        for(int i=0;i<n;i++)
        {
        System.out.println("enter the value of "+(i+1)+ "item ");
        val[i]=in.nextInt();
        }
        for(int i=0;i<=n;i++)
        {
            for(int j=0;j<=w;j++)
            a[i][j]=-1;
        }
    }
        int ks(int n,int w)
        {
            if(a[n][w]!=-1)
            {
                return  a[n][w];
            }
            if(n==0||w==0)
            {
                return a[n][w]=0;
            }
            if(wt[n-1]<=w)
            return a[n][w]= Math.max(val[n-1]+ks(n-1,w-wt[n-1]),ks(n-1,w));
            else
            {
                return a[n][w]=ks(n-1,w);
            }
        
        }

        
    }
    class test{
        public static void main(String args[])
        {
            Scanner in=new Scanner(System.in);
            System.out.println("enter no.of items");
            int n=in.nextInt();
            System.out.println("enter the weight of the bag");
            int w=in.nextInt();
            knapsack k=new knapsack(n,w);
            System.out.println("the max value of bag:"+k.ks(n,w));
            
        
        }
    }

