//centigrade into fahreheitc=(f-32)/1.8
#include<stdio.h>
float main()
{
float c,f;
printf("enter c value");
scanf("%f",&c);
f=(c*1.8)+32;
printf("%f=fahreheit\n",f);
c=(32*f-32)*5/9;
printf("%f=celsius\n",c);	
return 0;
}

