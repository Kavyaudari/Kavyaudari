/*import java.util.*;
class w2
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the array size ");
int n=in.nextInt();
int[] a=new int[n];
System.out.println("enter the elements ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
sort s1=new sort();
s1.sorting(a,n);
}
}
class sort
{
void sorting(int a[],int n)
{
int temp;
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(a[i]>a[j])
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(a[i]);
}
}
}
import java.util.*;
class w2
{
public static void main(String args[])
{
System.out.println("enter the array size ");
Scanner in=new Scanner(System.in);
int n=in.nextInt();
int[] a=new int[n];
System.out.println("enter the element ");
int e=in.nextInt();
System.out.println("enter the elements ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
kavya k1=new kavya();
k1.search(a,n,e);
}
}
class kavya
{
void search(int a[],int n,int e)
{
for(int i=0;i<n;i++)
{
if(e==a[i])
{
System.out.println("the element is present " +e);
break;
}
}
}
}
import java.util.*;
class w2{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the array size ");
int n=in.nextInt();
int a[]=new int[n];
System.out.println("enter the elements ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
kavya k1=new kavya();
System.out.println("enter the element ");
int e=in.nextInt();
k1.search(a,n,e);
}
}
class kavya
{
void search(int a[],int n,int e)
{
int f=0;
int l=n-1;
int m=(f+l)/2;
while(f<=l)
{
if(a[m]==e)
{
System.out.println("the number found = " +e);
break;
}
else if(a[m]<e)
{
f=m+1;
}
else 
{
l=m-1;
m=(f+l)/2;
}
}
}
}
import java .util.*;
class w2
{
public static void main(String args[])
{
System.out.println("enter the row and col of m");
Scanner in=new Scanner(System.in);
int m=in.nextInt();
int n=in.nextInt();
int a[][]=new int[m][n];
int b[][]=new int[m][n];
System.out.println("enter the elements of a matrix ");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
a[i][j]=in.nextInt();
}
}
System.out.println("enter the elements of b matrix ");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
b[i][j]=in.nextInt();
}
}
kavya k1=new kavya();
k1.addm(a,b,m,n);
}
}
class kavya
{
void addm(int a[][],int b[][],int m,int n)
{
int sum[][]=new int[m][n];
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
sum[i][j]=a[i][j]+b[i][j];
}
}
System.out.println("addtion = ");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
System.out.print(sum[i][j]+"\t" );
System.out.print("\n");
}
}
}
}
import java.util.*;
class w2
{
public static void main(String args[])
{
Scanner in =new Scanner(System.in);
System.out.println("enter the row and col of a matrix ");
int m=in.nextInt();
int n=in.nextInt();
System.out.println("enter the row and col of a matrix ");
int p=in.nextInt();
int q=in.nextInt();
int a[][]=new int[m][n];
int b[][]=new int[p][q];
int t[][]=new int[m][q];
System.out.println("enter 1 elements ");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
a[i][j]=in.nextInt();
}
}
for(int i=0;i<p;i++)
{
for(int j=0;j<q;j++)
{
b[i][j]=in.nextInt();
}
}
kavya k1=new kavya();
k1.m(a,b,t,m,n,p,q);
}
}
class kavya 
{
int sum=0;
void m(int a[][],int b[][],int t[][],int m,int n, int p,int q)
{
if(n!=p)
{
System.out.println("not possible ");
}
else
{
for(int i=0;i<m;i++)
{
for(int j=0;j<q;j++)
{
for(int k=0;k<p;k++)
{
sum=sum+a[i][k]*b[k][j];
}
t[i][j]=sum;
sum=0;
}
}
for(int i=0;i<m;i++)
{
for(int j=0;j<q;j++)
{
System.out.print(t[i][j] +"\t");
}
System.out.print("\n");
}
}}
}
import java.util.*;
class w2
{
public static void main(String args[])
{
System.out.println("enter size ");
Scanner in=new Scanner(System.in);
int s=in.nextInt();
int n=s+1;
String a[]=new String[n];
System.out.println("enter the names ");
for(int i=0;i<n;i++)
{
a[i]=in.next();
}
kavya k1=new kavya();
k1.compare(a,n);
}
}
class kavya{
void compare(String a[],int n)
{
String temp;
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(a[i].compareTo(a[j])>0)
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(a[i]);
}
}
}*/
import java.util.*;
class w2
{
public static void main(String args[])
{
for(int i=0;i<args.length;i++)
{
System.out.println(args[i]);
}
}
}




