package p1;
public class C1
{
public void print()
{
System.out.println("welcome ");
}
}

