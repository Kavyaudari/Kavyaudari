package kav;
public class apple
{
public void display1()
{
System.out.println("i am apple ");
}
}

