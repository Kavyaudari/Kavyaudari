package shape ;
public class sq
{
public void area(double a)
{
System.out.println(a*a);
}
public void perimeter(double s)
{
System.out.println(4*s);
}
}

