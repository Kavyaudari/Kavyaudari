import java.util.*;
class entrance
{
synchronized public void enter(int y)
{
System.out.println(y + "showed ticket");
 System.out.println(y+ "entered the theatre");
 }
 }
 class person extends Thread
 {
 int y;
 entrance s;
 person(int x,entrance e)
 {
 s=e;
 y=x;
 }
 public void buy()
 {
 System.out.println(y +"bought");
 }
 public void run()
 {
 buy();
 s.enter(y);
 }
}
public class ex10_4
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the no ");
int n=in.nextInt();
person p[]=new person[n+1];
entrance e=new entrance();
for(int i=1;i<=n;i++)
p[i]=new person(i,e);
for(int i=0;i<=n;i++)
p[i].start();
}
}










