import java.util.*;
class parent
{
void display()
{
System.out.println("kavya ");
}
}
class child extends parent
{
void display()
{
System.out.println("kavya rangaiah");
}
}
class week6_2
{
public static void main(String args[])
{
child c1=new child();
c1.display();
}
}

