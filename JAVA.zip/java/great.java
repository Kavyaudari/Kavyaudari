//greatest among three
import java.util.*;
class great
{
public static void main(String args[])
{
int a,b,c;
System.out.println("enter values");
Scanner in=new Scanner(System.in);
a=in.nextInt();
b=in.nextInt();
c=in.nextInt();
if(a>b&&a>c)
System.out.println(a);
else if(b>c)
System.out.println(b);
else
System.out.println(c);
}
}
