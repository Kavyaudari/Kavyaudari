#include<stdio.h>
int main()
{
int n;
int c=0;
printf("enter any value");
scanf("%d",&n);
while(n!=0)
{
n=n/10;
c++;
}
printf("number of digits=%d",c);
}
