//this keyword used as a variable
import java.util.*;
/*class student
{
String name;
int roll;
void s1(int roll,String name)
{
this.name=name;
this.roll=roll;
}
void display()
{
System.out.println("name="+name+" "+"roll="+roll);
}
}
class testthis
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("name and roll");
String name=in.nextLine();
int roll=in.nextInt();
//testthis s=new testthis();
student s=new student();

s.s1(roll,name);
s.display();
}
}*/
//this keyword as a current method
/*class student
{
void display()
{
System.out.println("hello");
}
void show()
{
String branch="cse";
System.out.println(branch);
this.display();
}
}
class testthis
{
public static void main(String args[])
{
student s=new student();
s.show();
}
}*/

