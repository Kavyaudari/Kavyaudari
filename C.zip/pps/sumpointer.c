//sum of pointer
#include<stdio.h>
int main()
{
int n,i;
int sum=0;
printf("enter the arrray size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
int *p;
p=&a[0];
for(i=0;i<n;i++)
{
scanf("%d",p+i);
sum=sum+*(p+i);
}
printf("%d",sum);
}

