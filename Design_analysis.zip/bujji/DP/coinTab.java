import java.util.*;
class coin{
    int arr[];
    int n;
    int sum;
    int s[][];
    Scanner in=new Scanner(System.in);
    coin(int n,int sum)
    {
        this.n=n;
        this.sum=sum;
        arr=new int[n];
        s=new int[n+1][sum+1];
    
    System.out.println("enter the values of arrays");

    for(int i=0;i<n;i++)
    {
        arr[i]=in.nextInt();

    }
}
    int ss(int n,int sum)
    {
        for(int i=0;i<=n;i++)
        {
            for(int j=0;j<=sum;j++)
            {
                if(j==0)
                {
                    s[i][j]=1;
                    continue;
                }
                if(i==0)
                {
                    s[i][j]=0;
                    continue;
                }
                if(arr[i-1]<=j)
                {
                    
                 s[i][j]=s[i][j-arr[i-1]]+s[i-1][j];
                }
                else
                {
                     s[i][j]=s[i-1][j];
                }
            }
        }
            return s[n][sum];

        
    }
}
class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of items");
        int n=in.nextInt();
        System.out.println("enter the sum  value of the subset");
        int sum=in.nextInt();
        coin s=new coin(n,sum);
       
        System.out.println("the  no of ways is:"+s.ss(n,sum));
        

        
    
    }
}
