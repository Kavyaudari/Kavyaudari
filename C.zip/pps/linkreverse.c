#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*header,*ptr,*new,*previousnode=0,*nextnode;
int read()
{
int a;
printf("enter the details");
scanf("%d",&a);
return a;
}
void insertbeg()
{
new=malloc(sizeof(struct node));
int a=read();
new->data=a;
ptr=header;
if(ptr==NULL)
{
new->next=NULL;
header=new;
}
else
{
new->next=header;
header=new;
}
}
void reverse()
{
ptr=header;
nextnode=header;
ptr=nextnode;
//while(nextnode!=0)
//{
//ptr=header;
//previousnode=NULL;
//nextnode=NULL;
while(ptr!=NULL)
{
nextnode=ptr->next;
ptr->next=previousnode;
previousnode=ptr;
ptr=nextnode;
}
header=previousnode;
}
void traverse()
{
ptr =header;
if(ptr==NULL)
{
printf("no list\n");
}
while(ptr!=NULL)
{
printf("%d",ptr->data);
ptr=ptr->next;
}
//printf("\n");
}
int main()
{
int ch;
while(ch!=5)
{
printf("enter the choice\n1=insertbeg\n2=reverse\n3=traverse");
//printf("5=stop\exit\n");
scanf("%d",&ch);
switch(ch)
{
case 1:insertbeg();
break;
case 2:reverse();
       traverse();
break;
case 3:traverse();
break;
case 4:exit(0);
default:printf("enter the correct choice");
break;
}
}
}
