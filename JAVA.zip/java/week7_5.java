import java.util.*;
interface sfee
{
void getAmount(int clgfee);
void getFirstname(String fname);
void getLastname(String lname);
void getAddress(String address);
void getContact(double contact);
}
class hosteler implements sfee
{
public void getAmount(int clgfee)
{
int hfee=3000;
System.out.println("total fees = " +(hfee+clgfee));
}
public void getFirstname(String fname)
{
System.out.println(" the name " +fname);
}
public void getLastname(String lname)
{
System.out.println(" the last name "+lname);
}
public void getAddress(String address)
{
System.out.println(" the address = "+address);
}
public void getContact(double contact)
{
System.out.println("the contact ="+contact);
}
}
class nonhosteler implements sfee
{
public void getAmount(int clgfee)
{
System.out.println("total fees = " +(clgfee));
}
public void getFirstname(String fname)
{
System.out.println(" the name " +fname);
}
public void getLastname(String lname)
{
System.out.println(" the last name "+lname);
}
public void getAddress(String address)
{
System.out.println(" the address = "+address);
}
public void getContact(double contact)
{
System.out.println("the contact ="+contact);
}
}
class week7_5
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
sfee h1=new hosteler();
System.out.println("enter the details of hosteler ");
int clgfee=in.nextInt();
h1.getAmount(clgfee);
String fname=in.next();
h1.getFirstname(fname);
String lname=in.next();
h1.getLastname(lname);
String address=in.next();
h1.getAddress(address);
double contact=in.nextDouble();
h1.getContact(contact);
}
}

