class mine2
{
public static void main(String args[])
{
try
{
one();
}
catch(Exception e)
{
System.out.println("main");
}
}
static void one() throws Exception
{
try
{
two();
}
catch(Exception e)
{
System.out.println("one ");
throw e;
}
}
static void two() throws Exception
{
System.out.println("two");
throw new Exception("two");
}
}

