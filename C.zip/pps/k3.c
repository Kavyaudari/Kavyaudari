//fab
#include<stdio.h>
int main()
{
int n,t1=0,t2=1,t3,i;
printf("enter n value");
scanf("%d",&n);
printf("the series");
for(i=0;i<=n;i++)
{
printf("%d",t1);
t3=t1+t2;
t1=t2;
t2=t3;
}
}
