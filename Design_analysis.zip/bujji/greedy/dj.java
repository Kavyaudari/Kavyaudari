import java.util.*;
class dj
{
int n;
int ed[][];
int vist[];
int cost[];
int k;
int p[];
dj(int ed[][], int vist[], int cost[])
{
this.ed=ed;
this.cost=cost;
this.vist=vist;
p=new int[n];
path();
k=ed.length;
path();
}
void path()
{
while(k>0)
{
int min=Integer.MAX_VALUE;
int index=-1;
for(int i=0;i<ed.length;i++)
{
if(vist[i]==-1)
{
if(cost[i]<min)
{
min=cost[i];
index=i;
}
}
}
vist[index]=1;
for(int j=0;j<ed.length;j++)
{
if(ed[index][j]!=-1)
{
if(cost[index]+ed[index][j]<cost[j])
{
cost[j]=(ed[index][j]+cost[index]);

}
}
}
k--;
}
    for(int i=0; i<ed.length; i++){
            System.out.println(cost[i]);
            
            
        }
}
}

class test
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size");
int n=in.nextInt();
int ed[][]=new int[n][n];
int vist[]=new int[n];
int cost[]=new int[n];
cost[0]=0;
vist[0]=-1;
for(int i=1;i<n;i++)
{
cost[i]=Integer.MAX_VALUE;
vist[i]=-1;
}
for(int i=0;i<n;i++)
{
for(int j=0;j<n;j++)
{
ed[i][j]=-1;
}
}
System.out.println("enter the graph");
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
System.out.println(i+"row" +j+ "col");
ed[i][j]=ed[j][i]=in.nextInt();
}
}
new dj(ed,vist,cost);
 in.close();
}
}

