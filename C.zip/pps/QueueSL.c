#include<stdio.h>
#include<stdlib.h>
//void enqueue()
//void dequeue()
//void display()
struct node
{
int data;
struct node *next;
}*new,*ptr,*head,*front=NULL,*rear=NULL;

void enqueue()
{
new=malloc(sizeof(struct node));
new->next=NULL;
printf("enter the data");
scanf("%d",&new->data);
if(front==NULL&&rear==NULL)
{
front=rear=new;
}
else
{
rear->next=new;
rear=new;
}
}
void dequeue()
{
ptr=front;
if(front==NULL&&rear==NULL)
{
printf("empty list");
}
else if(front==rear)
{
free(ptr);
}
else
{
front=front->next;
free(ptr);
}
}
void display()
{
ptr=front;
if(front==NULL)
{
printf("empty list");
}
else
{
printf("the elements in the list:         \n");
while(ptr->next!=NULL)
{
printf("%d",ptr->data);
ptr=ptr->next;
}
printf("%d",ptr->data);
}
}
int main()
{
int ch;
printf("\n1=enquque\n2=dequeue\n3=display");
while(ch!=4)
{
printf("enter the choice");
scanf("%d",&ch);
switch(ch)
{
case 1: enqueue();
break;
case 2: dequeue();
break;
case 3: display();
break;
default:printf("wrong");
break;
}
}
}
