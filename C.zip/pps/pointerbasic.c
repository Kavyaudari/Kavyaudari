//basic pointers
#include<stdio.h>
int main()
{
int x=5, *p;
p=&x;
printf("%d",x);
printf("%u",&x);
printf("%u",p);
printf("%u",*p);

}
