//marks
#include<stdio.h>
int main()
{
int maths,phy,chem,total,mathphy;
printf("enter your marks");
scanf("%d%d%d",&maths,&phy,&chem);
if((maths>=65)&&(phy>=55)&&(chem>=50))
{
if(total>=190)
{
if(mathphy>=140)
{
printf("admission will be given to u");
}
}
}
else
{
printf("admission is not given to u");
}
return 0;
}
