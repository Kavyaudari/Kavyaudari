#include<stdio.h>
#include<ctype.h>
#include<math.h>
char postfix[20];
float stack[20];
int top=-1;
void push(float ch)
{
top++;
stack[top]=ch;
}
float pop()
{
float x;
x=stack[top];
top--;
return x;
}
void main()
{
float op1,op2;
int i;
printf("ente rthe postfix expression");
scanf("%s",postfix);
for(i=0;postfix[i]!='\0';i++)
{
if(isdigit(postfix[i]))
{
push(postfix[i]-48);
}
else
{
op2=pop();
op1=pop();
switch(postfix[i])
{
case '+':push(op1+op2);
break;
case '-':push(op1-op2);
break;
case '*':push(op1*op2);
break;
case '/':if(op2==0)
printf("divide by zero");
else
push((float)(op1/op2));
break;
case '^':push(pow(op1,op2));
break;
default:
printf("wrong");
}
}
}
printf("%f",stack[top]);
}
