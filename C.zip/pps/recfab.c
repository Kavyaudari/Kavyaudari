//fabanocci
#include<stdio.h>
int fabanocci(int);
int main()
{
int n,term;
printf("enter the value");
scanf("%d",&n);
term=fabanocci(n);
printf("%d",term);
}
int fabanocci(int x)
{
if(x==0||x==1)
return(x);
else
return(fabanocci(x-1)+fabanocci(x-2));
}
