//equation5xpow3-7xpow2+9x-8,4ypow4-8ypow3-3ypow2+y-9
#include<stdio.h>
#include<math.h>
int main()
{
int x,y,one,two;
printf("enter the value of x,y");
scanf("%d%d",&x,&y);
one=pow(5*x,3)-pow(7*x,2)+9*x-8;
two=pow(4*y,4)-pow(8*y,3)-pow(3*y,2)+y-9;
printf("solution1=%d\n",one);
printf("solution2=%d",two);
return 0;
}
