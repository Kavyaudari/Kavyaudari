//dynamic method dispatching
import java.util.*;
class parent
{
void meth1()
{
System.out.println("1 meth");
}
void meth2()
{
System.out.println("2 meth");
}
}
class child extends parent
{
void meth2()
{
System.out.println("2 meth from child");
}
void meth3()
{
System.out.println("3 meth");
}
}
class textf
{
public static void main(String args[])
{
parent p=new child();
p.meth1();
p.meth2();//it cannot display the meth3 because it is not present in parent class
}
}

