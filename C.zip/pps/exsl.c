#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*temp,*top=0;
void push()
{
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&new->data);
new->next=0;
if(top==0)
{
top=new;
}
else
{
new->next=top;
top=new;
}
}
void pop()
{
if(top==0)
printf("empty");
else
{
temp=top;
printf("%d",top->data);
top=top->next;
free(temp);
}
}
void display()
{
temp=top;
while(temp!=0)
{
printf("%d",temp->data);
temp=temp->next;
}
}
void main()
{
int ch;
printf("\n1=push\n2=pop\n3=display");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:
push();
break;
case 2:pop();
break;
case 3:display();
break;
default:printf("wrong");
break;
}
}
}
