#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *left,*right;
}*root=0,*temp;
struct node *create(int x)
{
temp=malloc(sizeof(struct node ));
temp->data=x;
temp->left=0;
temp->right=0;
return temp;
}
struct node *insert(struct node *root,int x)
{
if(root==0)
return create(x);
else if(x<root->data)
root->left=insert(root->left,x);
else if(x>root->data)
root->right=insert(root->right,x);
return root;
}
struct node *search(struct node *root ,int x)
{
if(root==0)
return 0;
else
{
if(root->data==x)
return root;
else if(root->data>x)
return search(root->left,x);
else if(root->data<x)
return search(root->right,x);
}
}
void inorder(struct node *temp)
{
if(temp!=0)
{
inorder(temp->left);
printf("%d",temp->data);
inorder(temp->right);
}
}
void main()
{
int x,n;
printf("enter -1 to stop");
printf("enter the data");
scanf("%d",&x);
root=create(x);
while(x!=-1)
{
insert(root,x);
printf("enter the data");
scanf("%d",&x);
}
inorder(root);
printf("enter the ele to serach");
scanf("%d",&n);
if(search(root,n)==0)
printf("not");
else
{
printf("found");
}
}
