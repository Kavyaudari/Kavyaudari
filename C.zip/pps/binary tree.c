#include<stdio.h>
#define MAX=8
int bt[MAX],i=0;
int main()
{
printf("enter the elemets");
for(i=0;i<MAX;i++)
{
scanf("%d",&bt[i]);
}
inorder(0);
}
int getleftchild index(int i)
{
return(2*i+1);
}
int getrightchild index(int i)
{
return(2*i+2)
}
inorder(int index)
{
if(index<i)
{
inorder(getleftchild index(index));
printf("%d",bt(index));
inorder(get rightchild index(index));
}
}

