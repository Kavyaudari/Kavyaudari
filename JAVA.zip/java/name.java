package family;
public class name
{
public void display()
{
System.out.println("this is chinnu ");
}
}
