//method overriding
class main
{
void display()
{
System.out.println("hii");
}
}
class sub extends main
{
void display()
{
System.out.println("hii kavya rangaiah");
}
}
class teste
{
public static void main(String args[])
{
main m=new main();
m.display();
sub sb=new sub();
sb.display();
}
}

