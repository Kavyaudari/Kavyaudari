#many words in one print function 
print("hello \n kavya rangaiah \n how are you? ")
#concatination of strings
 #print("hello"+" "+"kavya")
#above case will give indetation error
print("hello"+" "+"kavya")
#asssignment
print("string" +" "+"manuplation"+" "+"excercise")
print("conactination"+"is"+"done"+"with "+"+"+"sign")

