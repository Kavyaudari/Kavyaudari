//my first program in java
class Hello{
public static void main(String args[])
{
System.out.println("Hello World");
}
}

