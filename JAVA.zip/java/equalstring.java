import java.util.*;
class equalstring
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the two Strings ");
String s1=in.nextLine();
String s2=in.nextLine();
if(s1.equals(s2))
{
System.out.println("both are equal ");
}
else if(s1.equalsIgnoreCase(s2))
{
System.out.println("equal by ignoring case ");
}
else
{
System.out.println("not equal ");
}
}
}

