import java.util.*;
class coin
{
int n;
int[] value;
int sum;
int[][] a;
public coin(int n,int sum)
{
value=new int[n];
this.n=n;
this.sum=sum;
a=new int[n+1][sum+1];
for(int i=0;i<=n;i++)
{
for(int j=0;j<=sum;j++)
{
a[i][j]=-1;
}
}
}
int ss(int n,int sum)
{
if(a[n][sum]!=-1)
{
return(a[n][sum]);
}
if(sum==0)
{
return(a[n][sum]=1);
}
if(n==0)
{
return(a[n][sum]=Integer.MAX_VALUE-1000);
}
if(value[n-1]<=sum)
{
return(a[n][sum]=Math.min(1+ss(n,sum-value[n-1]), ss(n-1,sum)));
}
else
{
return(a[n][sum]=ss(n-1,sum));
}
}
} 
class msubsetsum
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter no.of numbers in array=");
int n=sc.nextInt();
System.out.println("enter required sum value=");
int sum=sc.nextInt();
coin s=new coin(n,sum);
for(int i=0;i<n;i++)
{
System.out.println("enter element"+(i+1));
s.value[i]=sc.nextInt();
}
System.out.println(s.ss(n,sum));
}


}

