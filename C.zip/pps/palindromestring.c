//palindrome
#include<stdio.h>
#include<string.h>
int main()
{
char s[10];
int i,j,n,flag=0;
printf("enter any string");
scanf("%s",s);
n=strlen(s);
printf("length of string %d",n);
for(i=0,j=n-1;i<=j;i++,j--)
{
if(s[i]!=s[j])
{
printf("not a palindrome");
flag=1;//for checking condition
break;
}
}
if(flag==0)
printf("it is a palindrome");
}


