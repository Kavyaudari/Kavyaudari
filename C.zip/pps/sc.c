#include<stdio.h>
#include<stdlib.h>
void main()
{
int stack[100];
int top=-1;
void push()
{
int x;
printf("enter the data");
scanf("%d",&x);
if(top==-1)
{
printf("over flow");
}
else
{
top=top+1;
stack[top]=x;
}
}
}
