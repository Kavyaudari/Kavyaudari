//example for inheritance
import java.util.*;
class rectangle
{
int l;
int b;
rectangle()
{
l=b;
}
rectangle(int l,int b)
{
this.l=l;
this.b=b;
}
int area()
{
return(l*b);
}
int perimeter()
{
return(2*(l+b));
}
}
class cuboid extends rectangle
{
int h;
cuboid()
{
h=l=b;
}
cuboid(int h)
{
this.h=h;
}
}
cuboid(int l,int b,int h)
{
super(l,b);
this.h=h;
}
int volume()
{
return(l*b*h);
}
}
void display()
{
System.out.println("area="+area());
System.out.println("perimeter="+perimeter());
System.out.println("volume="+volume());
class testd
{
public static void main(String args[])
{
cuboid c=new cuboid();
Scanner in=new Scanner(System.in);
int z=in.nextInt();
cuboid c1=new cuboid(z);
int x=in.nextInt();
int y=in.nextInt();

cuboid c2=new cuboid(x,y,z);
}
}



