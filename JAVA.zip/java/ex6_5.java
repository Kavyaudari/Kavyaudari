import java.util.*;
class vehicle
{
int vno;
int ino;
String color;
double fuel;
void set(int vno,int ino,String color)
{
this.vno=vno;
this.ino=ino;
this.color=color;
}
void getCons(double fuel)
{
this.fuel=fuel;
}
void displayCons()
{
System.out.println(fuel);
}
void display()
{
System.out.println(vno);
System.out.println(ino);
System.out.println(color);
}
}
class two extends vehicle
{
double mt;
double avg;
void get(double mt,double avg)
{
this.mt=mt;
this.avg=avg;
}
void maintain()
{
System.out.println(mt);
}
void average()
{
System.out.println(avg);
}
}
class four extends vehicle
{
double mt;
double avg;
void get1(double mt,double avg)
{
this.mt=mt;
this.avg=avg;
}
void maintain()
{
System.out.println(mt);
}
void average()
{
System.out.println(avg);
}
}
class ex6_5
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
two t1=new two();
int vno=in.nextInt();
int ino=in.nextInt();
String color=in.next();
double fuel=in.nextDouble();
t1.set(vno,ino,color);
t1.getCons(fuel);
t1.displayCons();
t1.display();
double mt=in.nextDouble();
double avg=in.nextDouble();
t1.get(mt,avg);
t1.maintain();
t1.average();
four f1=new four();
int vno1=in.nextInt();
int ino1=in.nextInt();
String color1=in.next();
double fuel1=in.nextDouble();
f1.set(vno1,ino1,color1);
f1.getCons(fuel1);
f1.displayCons();
f1.display();
double mt1=in.nextDouble();
double avg1=in.nextDouble();
f1.get1(mt1,avg1);
f1.maintain();
f1.average();
}
}


