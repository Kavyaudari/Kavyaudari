//sum of even and odd
#include<stdio.h>
int main()
{
int n,evens=0,odds=0,i;
printf("enter the elements");
scanf("%d",&n);
for(i=0;i<=n;i++)
{
if(i%2==0)
{
evens=evens+i;
} 
else
{
odds=odds+i;
}
}
printf("%d%d",evens,odds);
}
