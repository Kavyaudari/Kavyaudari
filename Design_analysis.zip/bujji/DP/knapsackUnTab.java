import java.util.*;
import java.math.*;
class knapsack
{
    int w,n;
    int wt[];
    int val[];
    int a[][];
    public knapsack(int n,int w)
    {
        this.n=n;
        this.w=w;
        wt=new int[n];
        val=new int[n];
        Scanner in=new Scanner(System.in);
        a=new int[n+1][w+1];
        /*for(int i=0;i<n;i++)
        {
        System.out.println("enter the weight of "+(i+1)+ "item ");
        wt[i]=in.nextInt();
        }
        for(int i=0;i<n;i++)
        {
        System.out.println("enter the value of "+(i+1)+ "item ");
        al[i]=in.nextInt();
        }*/
    }
    int ks(int n,int w)
    {
        for(int i=0;i<=n;i++)
        {
            for(int j=0;j<=w;j++)
            {
                if(i==0||j==0)
                {
                    a[i][j]=0;
                    continue;
                    
                }
                if(wt[i-1]<=j)
                {
                    a[i][j]=Math.max(val[i-1]+a[i][j-wt[i-1]],a[i-1][j]);
                }
                else
                {
                    a[i][j]=a[i-1][j];
        
                }
            }
        }
        return a[n][w];
    }
}
class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter no.of items");
        int n=in.nextInt();
        System.out.println("enter the weight of the bag");
        int w=in.nextInt();
        knapsack k=new knapsack(n,w);
       // System.out.println("the max value of bag:"+k.ks(n,w));
        for(int i=0;i<n;i++)
        {
        System.out.println("enter the weight of "+(i+1)+ "item ");
        k.wt[i]=in.nextInt();
        }
        for(int i=0;i<n;i++)
        {
        System.out.println("enter the value of "+(i+1)+ "item ");
        k.val[i]=in.nextInt();
        }
         System.out.println("the max value of bag:"+k.ks(n,w));
        
    
    }
}
