#include<stdio.h>
int main()
{
int n,i,j;
printf("enter the value");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
for(j=1;j<=i;j++)
{
printf("*");
}
printf("\n");
if(n==i)
continue;
}
for(i=n;i>=1;i--)
{
for(j=1;j<=i;j++)
{
printf("*");
}
printf("\n");
}
}
