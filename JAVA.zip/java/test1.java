import java.util.*;
//this keyword
class kavya
{
int id;
String name;
kavya()
{
id=0;name="";
} 
kavya(int id ,String name)
{
this.id=id;
this.name=name;
}
void print()
{
System.out.println(id+name);
}
}
class test1{
public static void main(String args[])
{
kavya k1=new kavya();
kavya k2=new kavya(1,"kavya");
kavya k3=new kavya(2,"chinnu");
k1.print();
k2.print();
k3.print();
}
}


