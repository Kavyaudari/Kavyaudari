import java.util.*;
class student
{
int id;
String name;
student()
{
id=0;
name=null;
}
student(int id)
{
this.id=id;
//id=id;
}
student(int id,String name)
{
this(id);
this.name=name;
}
void display()
{
System.out.println(id+name);
}
}
class cse extends stduent{
cse()
{
super(40,"kavya");
this.id=47;
this.name="vfhd";
sub="oops";
}
cse(int id,String name)
{
super(id,name);
}
String sub;
void print()
{
System.out.println(id+name+sub);
}
void display()
{
System.out.println(id+name+sub);
}
}
class encap1{
public static void main(String args[])
{
cse c1=new cse();
student s1=new student(78,"hkj");
cse c2[]=new cse[3];
c2[0]=new cse(8,"hij");
c2[1]=new cse();
c2[2]=new cse();
c2[0].display();
c2[1].display();
}
}
