/*
6. Create an Interface StudentFee with method getAmount() ,getFirstName()
,getLastName(), getAddress(), getContact(). Calculate the amount paid by the
Hostler and NonHostler student by implementing interface Student Fee
import java.util.*;
interface sfee
{
void getAmount(int clgfee);
void getFirstname(String fname);
void getLastname(String name);
void getAddress(String address);
void getContact(int contact);
}
class hosteler implements sfee
{
public void getAmount(int clgfee)
{
int hfee=3000;
System.out.println("total fee for a hosteler = " +(hfee+clgfee));
}
public void getFirstname(String fname)
{
System.out.print("name= " +fname);
}
public void getLastname(String lname)
{
System.out.println("  "+lname);
}
public void getAddress(String address)
{
System.out.println("address = "+address);
}
public void getContact(int contact)
{
System.out.println("contact no = " +contact);
}
}
class internal
{
public static void main(String args[])
{
sfee s1=new hosteler();
Scanner in=new Scanner(System.in);
System.out.println("enter the details for hosteler ");
int clgfee=in.nextInt();
String fname=in.next();
String lname=in.next();
String address=in.next();
int contact=in.nextInt();
s1.getAmount(clgfee);
s1.getFirstname(fname);
s1.getLastname(lname);
s1.getAddress(address);
s1.getContact(contact);
}
}

5. Create an Interface Fare with method getAmount() to get the amount paid for
fare Calculate the fare paid by bus and train implementing interface Fare.
of travelling.
Program:

import java.util.*;
interface fare
{
void getAmount(int k,int c);
}
class bus implements fare
{
public void getAmount(int k,int c)
{
System.out.println("total fare price for a bus " +(k*c));
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
fare f1=new bus();
System.out.println("enter the kilometers travelled and fare of it ");
int k=in.nextInt();
int c=in.nextInt();
f1.getAmount(k,c);
}
}
4. Create an Interface Vehicle with method getColor(),getNumber(),
getConsumption() calculate the fuel consumed , name and color for TwoWheeler
and Four Wheeler By implementing interface Vehicle.
Program:

import java.util.*;
interface vehicle
{
void getColor(String color );
void getNumber(int n);
void getConsumption(int con,int l);
}
class two implements vehicle
{
public void getColor(String color)
{
System.out.println("color of two wheeler = "+color);
}
public void getNumber(int n)
{
System.out.println("number of two wheeler = "+n);
}
public void getConsumption(int con,int l)
{
System.out.println("the fuel consumed by two = " +(l*con));
}
}
class internal
{
public static void main(String args[])
{
vehicle v1=new two();
Scanner in=new Scanner(System.in);
System.out.println("enter the details ");
String color=in.next();
int n=in.nextInt();
System.out.println("enter the liters of fuel consumed ");
int l=in.nextInt();
System.out.println("enter the cost of each liter of fuel ");
int con=in.nextInt();
v1.getColor(color);
v1.getNumber(n);
v1.getConsumption(con,l);
}
}
3.Create an Interface payable with method getAmount ().Calculate the amount
to be and Employee by implementing Interface.paid to Invoice
Program: 
import java.util.*;
interface payable
{
void getAmount(int m,int n);
}
class emp implements payable
{
public void getAmount(int m,int n)
{
System.out.println("paid = "+(m*100));
System.out.println("invoice = "+((m*100)+n));
}
}
class internal 
{
public static void main(String args[])
{
payable p1=new emp();
Scanner in=new Scanner(System.in);
System.out.println("enter the details ");
int m=in.nextInt();
int n=in.nextInt();
p1.getAmount(m,n);
}
}
2. Create an abstract class Employee with methods getAmount() which displays
the amount paid to employee. Reuse this class to calculate the amount to be paid
to WeeklyEmployeed and HourlyEmployee according to no. of hours and total
hours for HourlyEmployee and no. of weeks and total weeks for
WeeklyEmployee.
Program:
import java.util.Scanner;

import java.util.*;
abstract class emp
{
abstract void getAmount(int m,int n);
}
class we extends emp
{
public void getAmount(int w,int wages1)
{
System.out.println("total paid amount for a we =" +(w*wages1));
}
}
class he extends emp
{
public void getAmount(int h,int wages2)
{
System.out.println("total paid amount for he = "+(h*wages2));
}
}
class internal 
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
emp e1=new we();
System.out.println("enter the no of weeks and wages per week ");
int w=in.nextInt();
int wages1=in.nextInt();
e1.getAmount(w,wages1);
System.out.println("enter the no of hours and wages per hour ");
emp e2=new he();
int h=in.nextInt();
int wages2=in.nextInt();
e2.getAmount(h,wages2);
}
}

. Create an abstract class Shape which calculate the area and volume of 2-d and
3-d shapes with methods getArea() and getVolume(). Reuse this class to calculate
the area and volume of square,circle ,cube and sphere.
Program:
import java.util.Scanner; 
import java.util.*;
abstract class shape
{
abstract void getArea(int r,int a);
abstract void getVolume(int r,int a);
}
class area extends shape
{
public void getArea(int r,int a)
{
System.out.println("circle area= "+(3.14*r*r));
System.out.println("square area= "+(a*a));
System.out.println("sphere area= "+(4*3.14*r*r));
System.out.println("cube area = "+(a*a*6));
}
public void getVolume(int r,int a)
{
System.out.println("vloume of cube = "+(a*a*a));
System.out.println("sphere = "+((4/3)*3.14*r*r*r));
}
}
class internal
{
public static void main(String args[])
{
shape s1=new area();
Scanner in=new Scanner(System.in);
System.out.println("enter the r and a values ");
int r=in.nextInt();
int a=in.nextInt();
s1.getArea(r,a);
}
}

. Write an application to create a super class Vehicle with information vehicle
number,insurance number,color and methods getConsumption()
displayConsumption(). Derive the sub-classes TwoWheeler and FourWheeler
with method maintenance() and average() to print the maintenance And average
of vehicle.
Program

import java.util.*;
class vehicle
{
int vno;
int ino;
String color;
double fuel;
void get1(int vno,int ino,String color)
{
this.vno=vno;
this.ino=ino;
this.color=color;
}
void display()
{
System.out.println("vehicle no = "+vno);
System.out.println("insuranance no ="+ino);
System.out.println("color=" +color);
}
void getConsumption(double fuel)
{
this.fuel=fuel;
}
void displayc()
{
System.out.println("consumption = "+fuel);
}
}
class two extends vehicle
{
double maintainance;
double avg;
void get2(double maintainance,double avg)
{
this.maintainance=maintainance;
this.avg=avg;
}
double getmaintainance()
{
return maintainance;
}
double getaverage()
{
return avg;
}
}
class four extends vehicle
{
double maintainance;
double avg;
void get3(double maintainance,double avg)
{
this.maintainance=maintainance;
this.avg=avg;
}
double getmaintainance()
{
return maintainance;
}
double getaverage()
{
return avg;
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
two t=new two();
System.out.println("enter the details ");
int vno=in.nextInt();
int ino=in.nextInt();
String color=in.next();
double fuel=in.nextDouble();
t.get1(vno,ino,color);
t.display();
t.getConsumption(fuel);
t.displayc();
System.out.println("enter the maintainance and avg ");
double maintainance=in.nextDouble();
double avg=in.nextDouble();
t.get2(maintainance,avg);
t.getmaintainance();
t.getaverage();
four f=new four();
System.out.println("enter the details ");
int vno1=in.nextInt();
int ino1=in.nextInt();
String color1=in.next();
double fuel1=in.nextDouble();
f.get1(vno1,ino1,color1);
f.display();
f.getConsumption(fuel1);
f.displayc();
System.out.println("enter the maintainance and avg ");
double maintainance1=in.nextDouble();
double avg1=in.nextDouble();
f.get3(maintainance1,avg1);
f.getmaintainance();
f.getaverage();
}
}

import java.util.*;
class vehicle
{
int vno;
int ino;
String color;
double fuel;
void get1(int vno,int ino,String color)
{
this.vno=vno;
this.ino=ino;
this.color=color;
}
void display()
{
System.out.println("vehicle no = "+vno);
System.out.println("insuranance no ="+ino);
System.out.println("color=" +color);
}
void getConsumption(double fuel)
{
this.fuel=fuel;
}
void displayc()
{
System.out.println("consumption = "+fuel);
}
}
class two extends vehicle
{
double maintainance;
double avg;
void get2(double maintainance,double avg)
{
this.maintainance=maintainance;
this.avg=avg;
}
double getmaintainance()
{
return maintainance;
}
double getaverage()
{
return avg;
}
}
class geared extends two
{
String name;
String type;
geared(String name,String type)
{
this.name=name;
this.type=type;
}
String getname()
{
return name;
}
String getype()
{
return type;
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
two t=new two();
System.out.println("enter the details ");
int vno=in.nextInt();
int ino=in.nextInt();
String color=in.next();
double fuel=in.nextDouble();
t.get1(vno,ino,color);
t.display();
t.getConsumption(fuel);
t.displayc();
System.out.println("enter the maintainance and avg ");
double maintainance=in.nextDouble();
double avg=in.nextDouble();
t.get2(maintainance,avg);
t.getmaintainance();
t.getaverage();
System.out.println("enter the name and type ");
String name=in.next();
String type=in.next();
geared g=new geared(name,type);
System.out.println(g.getname());
System.out.println(g.getype());
}
}
3. Write an application to create a super class Employee with information first
name & last name and methods getFirstName(), getLastName() derive the sub-
classes ContractEmployee and RegularEmployee with the information about
department, designation & method displayFullName() , getDepartment(),
getDesig() to print the salary and to set department name & designation of the
corresponding sub-class objects respectively 

import java.util.*;
class emp
{
String fname;
String lname;
void getFirstname(String f)
{
fname=f;
System.out.println("name= "+f);
}
void getLastname(String l)
{
lname=l;
System.out.println("name= "+l);
}
}
class cemp extends emp
{
String depart;
String desig;
double salary;
void getSalary(double salary)
{
System.out.println("salary = "+salary);
}
void getFullname(String name)
{
System.out.println("full name of emp =" +name);
}
void getDepartment(String depart)
{
System.out.println("department= "+depart);
}
void getDesig(String desig)
{
System.out.println("designation ="+desig);
}
 }
 class internal 
 {
 public static void main(String args[])
 {
Scanner in=new Scanner(System.in);
cemp c1=new cemp();
System.out.println("enter the details");
String fname=in.next();
String lname=in.next();
c1.getFirstname(fname);
c1.getLastname(lname);
System.out.println("enter the desid and depart ");
String depart=in.next();
String desig=in.next();
double salary=in.nextDouble();
String name=fname+" " +lname;
c1.getFullname(name);
c1.getDepartment(depart);
c1.getDesig(desig);
c1.getSalary(salary);

}
}
4. Derive sub-classes of ContractEmployee namely HourlyEmployee &
WeeklyEmployee with information number of hours & wages per hour, number
of weeks & wages per week respectively & method calculateWages() to calculate
their monthly salary. Also override getDesig () method depending on the type of
contract employee.
Program:
class contractemployee
import java.util.*;
class emp
{
String fname;
String lname;
void getFirstname(String f)
{
fname=f;
System.out.println("name= "+f);
}
void getLastname(String l)
{
lname=l;
System.out.println("name= "+l);
}
}
class cemp extends emp
{
String depart;
String desig;
double salary;
void getSalary(double salary)
{
System.out.println("salary = "+salary);
}
void getFullname(String name)
{
System.out.println("full name of emp =" +name);
}
void getDepartment(String depart)
{
System.out.println("department= "+depart);
}
void getDesig(String desig)
{
System.out.println("designation ="+desig);
}
 }
 class hour extends cemp
 {
int wages,hours;
hour(int wages,int hours)
{
this.wages=wages;
this.hours=hours;
System.out.println("no of hours ="+hours);
System.out.println("no of wages ="+wages);
}
int calculations()
{
return (wages*hours*30);
}
public String getDesignation()
{
return super.desig;
}
}
 class internal 
 {public static void main(String args[])
 {
Scanner in=new Scanner(System.in);
cemp c1=new cemp();
System.out.println("enter the details");
String fname=in.next();
String lname=in.next();
c1.getFirstname(fname);
c1.getLastname(lname);
System.out.println("enter the desid and depart ");
String depart=in.next();
String desig=in.next();
double salary=in.nextDouble();
String name=fname+" " +lname;
c1.getFullname(name);
c1.getDepartment(depart);
c1.getDesig(desig);
c1.getSalary(salary);
System.out.println("enter wages and hours ");
int wages=in.nextInt();
int hours=in.nextInt();
hour h=new hour(wages,hours);
h.getDesignation();
h.calculations();
}
}

import java.util.*;
class a
{
void display()
{
System.out.println("hii");
}
}
class b extends a
{
void display()
{
System.out.println("hello");
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
b k=new b();
k.display();
}
}

class internal
{
static
{
System.out.println("static block");
}
static void display()
{
System.out.println("static method ");
}
static int a=9;
public static void main(String args[])
{
internal n=new internal();
System.out.println(n.a);
n.display();
}
}

import java.util.*;
class a
{
int x=7;
void display()
{
System.out.println(x);
}
}
class b extends a
{
int x=8;
void display()
{
System.out.println(super.x);
}
}
class internal
{
public static void main(String args[])
{
b k=new b();
k.display();
}
}


import java.util.*;
class a
{
int x,y,z;
a(int x,int y,int z)
{
this.x=x;
this.y=y;
System.out.println(z);
}
a(int x,int y)
{
this.x=x;
System.out.println(y);
}
a(int x)
{
System.out.println(x);
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the values ");
int x=in.nextInt();
int y=in.nextInt();
int z=in.nextInt();
a k=new a(x,y,z);
}
}
4. Create a class Account with an instance variable balance (double). It
shouldcontain a constructor that initializes the balance, ensure that the initial
balance is
greater than 0.0. Acct details : Acct_Name, Acct_acctno, Acct_Bal,
Acct_Address.
Create two methods namely credit and debit, getBalance.
The Credit adds the amount (passed as parameter) to balance and does not
return any
data. Debit method withdraws money from an Account. GetBalance displays the
amount. Ensure that the debit amount does not exceed the Account’s balance. In
that case the balance should be left unchanged and the method should print a
message indicating “Debit amount exceeded account balanc

import java.util.*;
class account
{
int ano;
String name;
double balance;
double withdraw;
double deposit;
account(int a,String n,double b,double w,double d)
{
ano=a;
name=n;
balance=b;
withdraw=w;
deposit=d;
}
void debit(double w)
{
if(balance<w)
{
System.out.println("sorry  ");
}
else
{
balance=balance-w;
System.out.println("balnace is =" +balance);
System.out.println("withdrawed amount= " +w);
}
}
void credit(double d)
{
balance=balance+d;
System.out.println("total deposited money = "+d);
System.out.println("total amount= "+balance);
double m=0.0;
m=(balance-withdraw)+deposit;
System.out.println("current amount= "+m);
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the details");
int ano=in.nextInt();
String name=in.next();
double balance=in.nextDouble();
double withdraw=in.nextDouble();
double deposit=in.nextDouble();
account x=new account(ano,name,balance,withdraw,deposit);
x.debit(withdraw);
x.credit(deposit);
}
}
2. Write an application that prompts the user for the radius of a circle and uses a
method called circleArea to calculate the area of the circle and uses a method
circlePerimeter to calculate the perimeter of the circle

import java.util.*;
class circle
{
double r;
double area()
{
return (3.14*r*r);
}
double perimeter()
{
return (2*3.14*r);
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the radius ");
double R=in.nextDouble();
circle x=new circle();
x.r=R;
System.out.println(x.area());
x.perimeter();
}
}
upper case to lower case

import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the String ");
String s=in.next();
String s1=s.toLowerCase();
System.out.println(s1);
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the string ");
String s=in.next();
System.out.println("enter the substring at :"+(s.length()));
int n=in.nextInt();
String s1=s.substring(n);
System.out.println(s1);
System.out.println("enter the substring at :"+(s.length()));
int a=in.nextInt();
int b=in.nextInt();
String s2=s.substring(a,b);
System.out.println(s2);
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the string ");
String s=in.next();
int n;
n=s.length();
for(int i=n-1;i>=0;i--)
{
char rev=s.charAt(i);
System.out.print(rev);
}
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the string ");
String s=in.next();
int n=s.length();
System.out.println("length of string = "+n);
}
}
import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the string");
String s=in.next();
int v=0;int c=0;
String s1=s.toLowerCase();
System.out.println(s1);
for(int i=0;i<s1.length();i++)
{
char k=s1.charAt(i);
if(k=='a'||k=='i'||k=='o'||k=='u'||k=='e')
{
v++;
System.out.println(k +"is a vowel ");
}
else
{
c++;
System.out.println(k +"is a consonant ");
}
}
System.out.println("total = " +v);
System.out.println("total = "+c);
}
}
import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the string ");
String s1=in.next();
System.out.println(s1);
String s2=in.next();
System.out.println(s2);
String s3=s1.concat(s2);
System.out.println(s3);
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the string and char");
String s=in.next();
char k=in.next().charAt(0);
int c=0;
for(int i=0;i<s.length();i++)
{
if(s.charAt(i)==s.charAt(s.indexOf(k)))
{
c++;
}
else
{
System.out.println("no ");
}
}
System.out.println(c);
}
}


import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the string ");
String s1=in.next();
String s2=in.next();
if(s1.equals(s2))
{
System.out.println("are equal ");
}
else if(s1.equalsIgnoreCase(s2))
{
System.out.println("equal ");
}
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the string ");
String s1=in.next();
String s2=in.next();
if(s1.compareTo(s2)>0)
{
System.out.println("s1 >s2");
}
else if(s1.compareTo(s2)<0)
{
System.out.println("s1<s2");
}
else
{
System.out.println("equal ");
}
}
}

import java.util.*;
import java.util.Random;
class internal
{
public static void main(String args[]){
int i,dice1,dice2;
int m=0;
int n=0;
Random r=new Random();
dice1=r.nextInt(6);
dice2=r.nextInt(6);
for(i=0;i<3;i++)
{
Scanner in=new Scanner(System.in);
dice1=in.nextInt();
dice2=in.nextInt();
if((dice1>=1&&dice1<=6)&&(dice2>=1&&dice2<=6))
{
if(dice1==dice2)
{
n++;
}
else
{
m++;
}
}
else
{
System.out.println("invalid ");
}
}
System.out.println(m);
System.out.println(n);
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int a[]=new int[5];
for(int i=0;i<5;i++)
{
int c=0;
System.out.println("enter element ");
int e=in.nextInt();
for(int j=0;j<a.length;j++)
{
if(a[j]==e)
{
System.out.println("repeated");
i=i-1;
c=1;
break;
}
else if(e<=10||e>=100)
{
System.out.println("not in range ");
i=i-1;
c=1;
break;
}
}
if(c!=1)
{
a[i]=e;
for(int k=0;k<=i;k++)
{
System.out.println(a[k]);
}
}
}
}
}

import java.util.*;
class product
{
int id;
String name;
int qty;
int price;
int tprice(int q)
{
return q*price;
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
product p[]=new product[3];
p[0]=new product();
p[1]=new product();
p[2]=new product();
for(int i=0;i<3;i++)
{
System.out.println("enter the details ");
p[i].id=in.nextInt();
p[i].name=in.next();
p[i].qty=in.nextInt();
p[i].price=in.nextInt();
}
int total=0;
int x;
do
{
System.out.println("enter the id and qty");
int Id=in.nextInt();
int q=in.nextInt();
switch(Id)
{
case 1:total+=p[0].tprice(q);
break;
case 2:total+=p[1].tprice(q);
break;
case 3:total+=p[2].tprice(q);
break;
default:
System.out.println("invalid ");
}
System.out.println("do you want ");
x=in.nextInt();
}
while(x==1);
System.out.println(total);
}
}

import java.util.*;
class emp
{
int id;
String name;
String address;
double salary;
void display()
{
System.out.println(id+name+address+salary);
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
emp e[]=new emp[3];
e[0]=new emp();
e[1]=new emp();
e[2]=new emp();
System.out.println("enter ");
for(int i=0;i<3;i++)
{
e[i].id=in.nextInt();
e[i].name=in.next();
e[i].address=in.next();
e[i].salary=in.nextDouble();
}
System.out.println("enter the id ");
int Id=in.nextInt();
for(int i=0;i<3;i++)
{
if(e[i].id==Id)
{
e[i].display();
}
}
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
for(int i=0;i<args.length;i++)
{
System.out.println(args[i]);
}
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
System.out.println("enter the size ");
Scanner in=new Scanner(System.in);
int n=in.nextInt();
int a[]=new int[n];
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
check c1=new check();
c1.sorting(a,n);
}
}
class check
{
void sorting(int a[],int n)
{
int temp;
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(a[i]>=a[j])
{
temp=a[j];
a[j]=a[i];
a[i]=temp;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(a[i]);
}
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the row and col of 1 ");
int m=in.nextInt();
int n=in.nextInt();
int a[][]=new int[m][n];
System.out.println("enter the row nad col of 2 ");
int p=in.nextInt();
int q=in.nextInt();
int b[][]=new int[p][q];
System.out.println("enter the elements ");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
a[i][j]=in.nextInt();
}
}
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
b[i][j]=in.nextInt();
}
}
int c[][]=new int[m][q];
check c1=new check();
c1.mult(a,b,c,m,n,p,q);
}
}
class check
{
int sum=0;
void mult(int a[][],int b[][],int c[][],int m,int n,int p,int q)
{
if(n!=p)
{
System.out.println("invalid ");
}
else
{
for(int i=0;i<m;i++)
{
for(int j=0;j<q;j++)
{
for(int k=0;k<p;k++)
{
sum=sum+a[i][k]*b[k][j];
}
c[i][j]=sum;
sum=0;
}
}
}
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
System.out.println(c[i][j]);
}
}
}
}

import java.util.*;
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n=in.nextInt();
String s[]=new String[n];
System.out.println("enter the string ");
for(int i=0;i<n;i++)
{
s[i]=in.next();
}
check c1=new check();
c1.sort(s,n);
}
}
class check
{
String temp;
void sort(String s[],int n)
{
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(s[i].compareTo(s[j])>0)
{
temp=s[i];
s[i]=s[j];
s[j]=temp;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(s[i]);
}
}
}

import java.util.*;
class book
{
String name;
int id;
String author;
int count;
void set(String name,int id,String author,int count)
{
this.name=name;
this.id=id;
this.author=author;
this.count=count;
}
void sell(int n)
{
if(n<=count)
{
count=count-n;
System.out.println("remaining books are = "+count);
}
else
{
System.out.println("not available ");
}
}
}
class customer
{
String cname;
int cid;
void set1(String cname,int cid)
{
this.cname=cname;
this.cid=cid;
}
void buy(book b,int n)
{
System.out.println(cname +"is buying a book ");
b.sell(n);
}
}
class internal
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter rhe details of book ");
String name=in.next();
int id=in.nextInt();
String author=in.next();
int count =in.nextInt();
book b1=new book();
b1.set(name,id,author,count);
String cname=in.next();
int cid=in.nextInt();
customer c1=new customer();
c1.set1(cname,cid);
c1.buy(b1,3);
}
}
*/ 
