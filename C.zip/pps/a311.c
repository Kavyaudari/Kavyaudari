#include<stdio.h>
struct employee
{
int id;
char name;
char designation;
char department;
};
int main()
{
struct employee e1={2340,"Ramesh","SP","Police"};
printf("ID-%dNAME-%sDESIGNATION-%sDEPARTMENT-%s\N",e1.id,e1.name,e1.designation,e1.department);
}
