import java.util.*;
class commandine
{
public static void main(string args[])
{
for(int i=0;i<args.length;i++)
System.out.println(args[i]);
}
}
