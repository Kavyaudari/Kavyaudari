//leap yr
#include<stdio.h>
int main()
{
int y;
printf("enter ");
scanf("%d",&y);
if((y%400==0||y%100!=0&&y%4==0))
{
printf("leap y");
}
else
printf("not a leap y");
}

