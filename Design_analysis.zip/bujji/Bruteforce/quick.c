#include<stdio.h>
void quick(int a[],int ,int);
void main()
{
    int i, a[100],n;
    printf("enter the size of array");
    scanf("%d",&n);
    printf("enter the elements in array");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    quick(a,0,n-1);
    printf("the sorted array is ");
    for(i=0;i<n;i++)
    {
       printf("%d ",a[i]);

    }
}
    void quick(int a[],int beg,int end)
    {
        int i,j,pivot,t;
        if(beg<end)
        {
        i=beg;
        j=end;
        pivot=beg;
  
        while(i<j)
        {
            while(a[i]<=a[pivot]&&i<end)
            i++;
            while(a[j]>a[pivot])
            j--;
            if(i<j)
            {
                t=a[i];
                a[i]=a[j];
                a[j]=t;
           }
           }
                t=a[pivot];
                a[pivot]=a[j];
                a[j]=t;
                quick(a,beg,j-1);
                quick(a,j+1,end);
                }
                }
            
