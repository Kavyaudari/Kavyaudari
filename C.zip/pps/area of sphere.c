//area of sphere 4 pirsq
#include<stdio.h>
float main()
{
float a,b,c,d;
printf("enter c value");
scanf("%f",&c);
a=4;
b=3.14;
d=a*b*c*c;
printf("%f",d);
return 0;
}
