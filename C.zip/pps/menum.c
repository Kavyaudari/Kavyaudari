include<stdio.h>
int minfun();
int maxfun();
int sum();
float average();
void main()
{
int n, i,check=-1;
int sum=0;
printf("enter array size");
scanf("%d",&n);
int a[n];
printf("enter array elements");
for(i=0;i<n,i++)
{
scanf("%d",&a[i])
}
while(check!=0)
{
printf("\n enter for choices\n1 for minimum number\n2 for maximum number\n3 for average\n");
scanf("%d",&check);
switch(check)
{
case 1:
printf("\n minimum=%d\n",minfun(a,n);
break;
printf("\n maximum=%d\n",max fun(a,n);
break;
default:printf("invalid:\n");
}
printf(".......");
}
return 0;
int minfun(int a[],int n)
{
int i,min=a[0];
for(i=0;i<n;i++)
{
if(a[i]<min)
{
min=a[i];
}
}
return min;
}
int maxfun(int a[],int n);
int i,max=a[0];
for(i=1;i<n;i++)
{
if (a[i]>max)
{
max=a[i];
}
}
return  max;
float avgfun(int a[],int sum, int n)
{
int i;
sum=0;
for(i=0;i<n;i++)
{
sum =sum+a[i];
}
printf("%d=sum",sum);
return(sum\n);
}
}

