package biscuit;
public interface inter1
{
public void m2();
}

