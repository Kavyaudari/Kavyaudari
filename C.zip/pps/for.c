#include<stdio.h>
#include<math.h>
void main()
{
int a,i;
float n;
printf('enter the value of a");
scanf("%d",&a);
for(i=1;i<=10;i++)
{
n=sqrt(n);
printf("sqrt of n =%f",n);
}
}
