//c program for double linked list
#include<stdio.h>
#include<stdlib.h>
//linked list node
struct node 
{
int info;
struct node *prev, *next;
};
struct node * start=NULL;
//function to traverse the linked list
void traverse()
{
//list is empty
if(start==NULL)
{
printf("list is empty");
return;
}
//else print data
struct node * temp;
temp=start;
while(temp!=NULL)
{
printf("data=%d\n",temp->info);
temp=temp->next;
}
}
//inserting at front
void insertbeg()
{
int data;
struct node *temp;
temp=(struct node*)malloc(sizeof(struct node));
printf("enter the number to be inserted :  ");
scanf("%d",&data);
temp->info=data;
temp->prev=NULL;
//pointer of temp will be assigned to start
temp->next=start;
start=temp;
}
void insertend()
{
int data;
struct node *temp, *trav;
temp=(struct node*)malloc(sizeof(struct node));
temp->prev=NULL;
temp->next=NULL;
printf("enter the number to be inserted :  ");
scanf("%d",&data);
temp->info=data;
temp->next=NULL;
trav=start;
//if start is null
if(start==NULL)
{
start=temp;
}
//changes links
else {
while(trav->next!=NULL)
trav=trav->next;
temp->prev=trav;
trav->next=temp;
}
}
void insertpos()
{
int data,pos,i=1;
struct node *temp,*newnode;
newnode=malloc(sizeof(struct node));
newnode->next=NULL;
newnode->prev=NULL;
//enter the pos
printf("\n enter the position:  ");
scanf("%d",&pos);
//if start==null
if(start ==NULL)
{
start =newnode;
newnode->prev=NULL;
newnode->next=NULL;
}
else if(pos==1)
{
insertbeg();
}
else
{
printf("\nenter the number to be inserted:  ");
scanf("%d",&data);
newnode->info=data;
temp=start;
while(i<pos-1)
{
temp=temp->next;
i++;
}
newnode->next =temp->next;
newnode->prev=temp;
temp->next=newnode;
temp->next->prev=newnode;
}
}
void deletebeg()
{
struct node*temp;
if(start==NULL)
{
printf("empty");
}
else
{
temp=start;
start=start->next;
if(start!=NULL)
{
start->prev=NULL;
}
free(temp);
}
}
void deleteend()
{
struct node*temp;
if(start==NULL)
{
printf("empty");
}
temp=start;
while(temp->next!=NULL)
temp=temp->next;
if(start->next!=NULL)
start=NULL;
else
{
temp->prev->next=NULL;
free(temp);
}
}
void deletepos()
{
int pos,i=1;
struct node *temp,*position;
temp=start;
if(start==NULL)
printf("empty");
else
{
printf("enter the pos");
scanf("%d",&pos);
if(pos==1){
deletebeg();
if(start!=NULL){
start->prev=NULL;
}
free(position);
return;
}
//traverse till position
while(i<pos-1)
{
temp=temp->next;
i++;
}
//change links
position=temp->next;
if(position->next!=NULL)
position->next->prev=temp;
temp->next=position->next;
//free memory
free(position);
}
}
//driver code
int main()
{
int choice;
while(1){
printf("\n\t1 To see list \n");
printf("\n\t2 For insertion at beg\n");
printf("\n\t3 For insertion at end\n");
printf("\n\t4 For insertion at position\n");
printf("\n\t5 For deletion beg\n");
printf("\n\t6 For deleion end\n");
printf("\n\t7 for deletion pos\n");
printf("\n\t8 To exit\n");
printf("\n Enter the choice\n");
scanf("%d",&choice);
switch(choice)
{
case1:
traverse();
break;
case2:
insertbeg();
break;
case3:
insertend();
break;
case4:
insertpos();
break;
case5:
deletebeg();
break;
case6:
deleteend();
break;
case7:
deletepos();
break;
case8:
exit(1);
break;
default:
printf("inncorrect choice\n");
continue;
}
}
return 0;
}








