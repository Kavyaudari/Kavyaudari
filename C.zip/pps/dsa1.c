#include<stdio.h>
#include<stdlib.h>
struct node
{
int num;
struct node *nextptr;
}*stnode;
void createNodelist(int n);
void displaylist();
int main()
{
int n;
printf("enter the data of nodes:  ");
scanf("%d",&n);
createNodelist(n);
printf("data entered in the list:");
displaylist();
return 0;
}
void createNodelist(int n)
{
struct node *fnNode,*tmp;
int num,i;
stnode=(struct node*)malloc(sizeof(struct node));
if(stnode==NULL)
{
printf("not allocated");
}
else 
{
printf("input data 1:  ");
scanf("%d",&num);
stnode->num=num;
stnode->nextptr=NULL;
tmp=stnode;
for(i=2;i<=n;i++)
{
fnNode=(struct node*)malloc(sizeof(struct node));
 if(fnNode==NULL)
 {
 printf("memory not");
 break;
 }
 else
 {
 printf("intput data %d:  ",i);
 scanf("%d",&num);
 fnNode->num=num;
 fnNode->nextptr=NULL;
 tmp->nextptr=fnNode;
 tmp=tmp->nextptr;
 }
 }
 }
 }
 void displaylist()
 {
 struct node *tmp;
 if(stnode==NULL)
 {
 printf("not");
 }
 else {
 tmp=stnode;
 while(tmp!=NULL);
 {
 printf("data=%d\n",tmp->num);
 tmp=tmp->nextptr;
 }
 }}
