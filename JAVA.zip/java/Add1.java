//addition 
import java.util.*;
class Add
{
public static void main(String[] args)
{
int a,b,c;
Scanner in=new Scanner(System.in);
System.out.println("enter  the values");
a=in.nextInt();
b=in.nextInt();
c=a+b;
System.out.println("sum"+c);
}
}
