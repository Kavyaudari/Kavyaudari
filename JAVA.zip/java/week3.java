import java.util.*;
class emp
{
int id;
String name;
int age;
int salary;
String gender;
String dis;
String add;
void display()
{
System.out.println(+id+name+age+salary+gender+dis+add);
}
}
class week3
{
public static void main(String args[])
{
emp e[]=new emp[3];
e[0]=new emp();
e[1]=new emp();
e[2]=new emp();
Scanner in=new Scanner(System.in);
for(int i=0;i<3;i++)
{
System.out.println("enter the details");
e[i].id=in.nextInt();
e[i].name=in.next();
e[i].age=in.nextInt();
e[i].salary=in.nextInt();
e[i].gender=in.next();
e[i].dis=in.next();
e[i].add=in.next();
}
int search;
System.out.println("enter the id");
search=in.nextInt();
for(int i=0;i<3;i++)
{
if(e[i].id==search)
{
e[i].display();break;
}}
}
}
