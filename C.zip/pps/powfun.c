//power
#include<stdio.h>
int exp(int,int);
int main()
{
int a,b,power;
printf("enter two values");
scanf("%d%d",&a,&b);
power=exp(a,b);
printf("%d",power);
}
int exp(int x,int y)
{
int z=1,i;
for(i=1;i<=y;i++)
{
z=z*x;
}
return(z);
}
