import java.util.*;
class addm
{
public static void main(String args[])
{
int m,n;
System.out.println("enter the rows and col ");
Scanner in=new Scanner(System.in);
m=in.nextInt();
n=in.nextInt();
int a[][]=new int[m][n];
int b[][]=new int[m][n];
int s[][]=new int[m][n];
System.out.println("enter the elements of 1st");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
a[i][j]=in.nextInt();
}
}
System.out.println("enter the elements of 2 ");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
b[i][j]=in.nextInt();
}
}
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
s[i][j]=a[i][j]+b[i][j];
}
}
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
System.out.print(s[i][j]+"\t");
System.out.println();
}
}
}
}

