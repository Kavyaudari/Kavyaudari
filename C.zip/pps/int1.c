//sum of a number
#include<stdio.h>
int main()
{
int n ,s=0,r;
printf("enter the value of n");
scanf("%d",&n);
while(n>0)
{
r=n%10;
s=s+r;
n=n/10;
}
printf("sum of %d = %d",n,s);
}

