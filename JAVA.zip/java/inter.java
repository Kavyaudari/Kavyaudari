package interface1;
public interface inter
{
public void display();
}

