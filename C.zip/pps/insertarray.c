//inserting number 
#include<stdio.h>
int main()
{
int n,i,p,val;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("enter the position");
scanf("%d",&p);
printf("enter the position val");
scanf("%d",&val);
for(i=n;i>=p;i--)
{
a[i=1]=a[i];
}
a[p]=val;
printf("after inserting");
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
}
