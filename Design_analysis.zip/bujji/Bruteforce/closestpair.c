 #include<stdio.h>
#include<math.h>
#include<limits.h>
struct pair{
int x,y;
};
 
 int main()
 {
  int n;
  printf("enter no.of pairs");
  scanf("%d",&n);
  struct pair point[n];
  printf("enter pais");
  float d1,d2;
  float res;
  for(int i=0;i<n;i++)
  {
  scanf("%d %d",&point[i].x,&point[i].y);
  }
  float min=INT_MAX;
  for(int i=0;i<n-1;i++)
  {
  for(int j=i+1;j<n;j++)
  {
  d1=pow((point[i].x)-(point[j].x),2);
  d2=((point[i].y)-(point[j].y),2);
  res=sqrt(d1+d2);
 
  //res=sqrt(d1*d1)+(d2*d2);*/
  //res=sqrt(pow(point[i].x-point[j].x,2)+pow(point[i].y-point[j].y,2));
  if(res<min)
  {
  min=res;
  }
  }
  }
  printf("%f",min );
  }
  
  
  

