package org.shapes;
import java.util.*;
public class square
{
public int s;
public void set(int s)
{
this.s=s;
}
public void display()
{
System.out.println("area="+s*s);
}
}

