//printing n numbers
#include<stdio.h>
int main()
{
int n,i;
printf("enter the values of n");
scanf("%d",&n);
for(i=0;i<=n;i++)
{
printf("%d\n",i);
}
return 0;
}
