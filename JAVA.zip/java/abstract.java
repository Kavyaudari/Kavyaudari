//abstraction
import java.util.*;
abstract class animal//hiding the impelementation details 
{
abstract void sound();
void print()//normal form
{
System.out.println("animals lover");
}
animal()//constructor
{
System.out.println("kavya");
}
}
class dog extends  animal//child
{
void sound()
{
System.out.println("dogs barks");
}
}
class lion extends animal
{
void sound()
{
System.out.println("lion roars");
}
}
class abstract{
public static void main(String args[])
{
dog d=new dog();
lion l=new lion();
d.sound();
l.sound();
d.print();
}
}

