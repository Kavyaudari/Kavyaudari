import rudra.inter4;
public class ex8_4 implements inter4
{
public void display()
{
System.out.println("this is package interface ");
}
public static void main(String args[])
{
ex8_4 e1=new ex8_4();
e1.display();
}
}

