import java.util.*;
/*class circle
{
double r;
double getArea()
{
return (3.14*r*r);
}
double getPerimeter()
{
return(2+3.14*r);
}
}
class w5
{
public static void main(String args[])
{
circle c1=new circle();
Scanner in=new Scanner(System.in);
System.out.println("enter the radius ");
double R=in.nextDouble();
c1.r=R;
System.out.println("area = " +c1.getArea());
System.out.println("perimeter= "+c1.getPerimeter());
}
}
class account
{
int acno;
String name;
double balance;
double withdraw,deposit;
account(int a,String n,double b,double w,double d)
{
acno=a;
name=n;
balance=b;
withdraw=w;
deposit=d;
}
void getWithdraw(double w)
{
if(balance<=w)
{
System.out.println("impossible ");
}
else
{
balance=balance-w;
System.out.println("the withdrawed amount="+w);
System.out.println("after withdrawing=" +balance);
}
}
void getDeposit(double d)
{
balance=balance+d;
System.out.println("after depositing " +balance);
}
void display()
{
System.out.println(acno+name);
double m=0.0;
m=((balance+deposit)-withdraw);
System.out.println(m);
}
}
class w5
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the details ");
int a=in.nextInt();
String n=in.next();
double b=in.nextDouble();
double w=in.nextDouble();
double d=in.nextDouble();
account a1=new account(a,n,b,w,d);
a1.getWithdraw(w);
a1.getDeposit(d);
a1.display();
}
}

class a
{
int x,y,z;
a(int x,int y,int z)
{
this.x=x;
this.y=y;
System.out.println(z);
System.out.println(x);
}
a(int x,int y)
{
this.x=x;
System.out.println(y);
}
a(int x)
{
System.out.println(x);
}
}
class w5
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the values ");
int x=in.nextInt();
int y=in.nextInt();
int z=in.nextInt();
a a1=new a(x,y,z);
}
}


class parent
{
int x=5;
void display()
{
System.out.println("kavya udari ");
}
}
class child extends parent
{
int x=6;
void display()
{
System.out.println(super.x);
}
}
class w5
{
public static void main(String args[])
{
child c1=new child();
c1.display();
}
}
*/
class w5
{
static
{
System.out.println("iam static bloack ");
}
static void display()
{
System.out.println("static method ");
}
static int a=13;`
public static void main(String args[])
{
System.out.println(w5.a);
w5.display();
}
}


