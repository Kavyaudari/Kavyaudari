#include<stdio.h>
int factorial(int);
int main()
{
int n,fact=1;
printf("enter the n value");
scanf("%d",&n);
fact=factorial(n);
printf("%d",fact);
}
int factorial(int x)
{
int i,y=1;
for(i=1;i<=x;i++)
{
y=y*i;
}
return(y);
}
