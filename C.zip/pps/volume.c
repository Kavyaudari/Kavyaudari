//volume of sphere
#include<stdio.h>
float main()
{
 float a,b,c;
 printf("enter a,b values");
 scanf("%f%f",&a,&b);
 c=(4/3)*a*b*b*b;
 printf("%f",c);
 return 0;
}
