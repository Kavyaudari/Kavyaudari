import java.util.*;
class kavya
{
int n;
int a[];
int res=0;
Scanner in =new Scanner(System.in);
kavya(int n)
{
this.n=n;
a=new int[n];
System.out.println("enter the array value ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
System.out.println(opt(a,n));
}
int opt(int a[],int n)
{

if(n==2)
{
res+=a[n-1]+a[n-2];
}
else{
int val=0;
sort(a);
val=a[n-1]+a[n-2];
a[n-2]=val;
res+=val;
n=n-1;
opt(a,n);

}
return res;
}
void sort(int a[])
{
int d=0;
for(int i=n-1;i>=0;i--)
{
for(int j=0;j<=i-1;j++)
{
if(a[j]<a[j+1])
{
int t=a[j];
a[j]=a[j+1];
a[j+1]=t;
d=1;
}
}
if(d==0)
break;
}
 for(  int i=0;i<n;i++)
    {
    System.out.println(a[i]);
    }
}
}

 class test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number :");
        int n=sc.nextInt();
        kavya op=new kavya(n);
        
        }}
        
