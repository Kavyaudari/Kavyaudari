//selective sort
#include<stdio.h>
int main()
{
int a[10],i,j,n,temp;
printf("enter the elements\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n-1;i++)
{
int min=i;
for(j=i+1;j<n-1;j++)
{
if(a[j]>a[min])
{
min=j;
}
}
if(min!=i)
{
temp=a[i];
a[i]=a[min];
a[min]=temp;
}
}
}
