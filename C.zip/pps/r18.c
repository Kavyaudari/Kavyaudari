//palindrome
#include<stdio.h>
#include<string.h>
int main()
{
char s[10];
int n,i,j,flag=0;
printf("s");
scanf("%s",s);
n=strlen(s);
for(i=0,j=n-1;i<=j;i++,j--)
{
if(s[i]!=s[j])
{
printf("not a palindtome");
flag=1;
break;
}
}
if(flag==0)
{
printf("palindrome");
}
}
