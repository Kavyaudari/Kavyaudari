//fun fabannoci
#include<stdio.h>
int fab(int);
int main()
{
int n,term;
printf("enter n");
scanf("%d",&n);
term=fab(n);
printf("%d",term);
}
int fab(int x)
{
if(x==0||x==1)
return x;
else
return(fab(x-1)+fab(x-2));
}
