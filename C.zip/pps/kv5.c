//building
#include<stdio.h>
#include<math.h>
int main()
{
int s=30;
float a=9.8;
float t;
t=sqrt(2*s/a);
printf("%fsec",t);
}
