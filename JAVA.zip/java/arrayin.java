//array intilisation
import java.util.*;
class arrayin{
/*
public static void main(String args[])
{
int n,i;
System.out.println("size");
Scanner in=new Scanner(System.in);
n=in.nextInt();
int a[]=new int[n];
System.out.println("enter elements");
for(i=0;i<=n;i++)
{
a[i]=in.nextInt();
}
for(i=0;i<=n;i++)
{
System.out.println(a[i]);
}
}
}*/
public static void main(String args[])
{
int n,i;
System.out.println("size");
Scanner in=new Scanner(System.in);
n=in.nextInt();
int a[]=new int[n];
for(i=0;i<=n;i++)
{
a[i]=in.nextInt();
}
test t=new test();
t.sum(a,n);
}
}
class test
{
void sum(int a[],int n)
{
int s=0;
for(int i=0;i<=n;i++)
{
s=s+a[i];
}
System.out.println(s);
}
}
