package p1;
import java.util.*;
class A
{
void display()
{
System.out.println("kavya rangaiah");
}
}

