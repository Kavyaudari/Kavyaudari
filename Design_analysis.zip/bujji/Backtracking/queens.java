import java.util.*;
import java.math.*;
class back{
    int n;
    int a[];
    Scanner in=new Scanner(System.in);
    public back(int n)
    {
        this.n=n;
        a=new int[n];
       

    }
     void  fill(int n,int k)
     {
        if(k==n)
        {
            for(int i=0;i<n;i++)
        {
            System.out.print(a[i]);
    
        }
        System.out.println();
        return;
        }
        
        
        for(int i=1;i<=n;i++)
        {
            if(isSafe(k,i))
            {
                a[k]=i;
                 fill(n,k+1);
            }
            
        }
    //return;
}
     
      
     boolean isSafe(int k,int i)
     {
        for(int j=0;j<k;j++)
        {
            if(a[j]==i)
            return false;
            if(Math.abs(j-k)==Math.abs(a[j]-i))
            return false;
    }
     return true;
     }
    }

class queens{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter the n");
        int n=in.nextInt();
        

        
        back b=new back(n);
    
        b.fill(n,0);
    }
}
