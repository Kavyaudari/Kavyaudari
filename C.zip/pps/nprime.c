// nprime
#include<stdio.h>
int main()
{
int n,j,count,i;
printf("enter a number");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
count=0;
for(j=1;j<=i;j++)
{
if(i%j==0)
count=count+1;
}
if(count==2)
printf("%d\n",i);
}
}
