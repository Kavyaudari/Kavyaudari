class throw_exception
{
/*int meth1(int a,int b)
{
int c;
c=a/b;
return c;
}
void meth2()
{
int r=meth1(10,0);
System.out.println(r);
}
public static void main(String args[])
{
throw_exception t=new throw_exception();
t.meth2();
}
}*/

int area(int l,int b) throws Exception
{
if(l<0||b<0){
throw new Exception("length and breadth cannot be negative ");
int a=l*b;
return a;
}
}
int m1()
{
try
{
int area(10,-6);
System.out.println(a);
}
catch (Exception e)
{
System.out.println(e);
}
}
public static void main(String args[]) 
{
throw_exception t=new throw_exception();
t.m1();
}
}








