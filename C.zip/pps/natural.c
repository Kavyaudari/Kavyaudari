//sum of n natural numbers
#include<stdio.h>
int main()
{
int n,t;
printf("enter n value");
scanf("%d",&n);
t=(n*n+1*n+2)/6;
printf("%d",t);
return 0;
}
