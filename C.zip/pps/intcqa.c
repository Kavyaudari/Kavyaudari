#include<stdio.h>
#include<stdlib.h>
#define n 8
int q[n];
int front=-1,rear=-1;
void eq(int);
void dq();
void di();
void eq(int x)
{
if(front==-1&&rear==-1)
{
front=rear=0;
q[rear]=x;
}
else if(front==(rear+1)%n)
{
printf("full");
}
else
{
rear=(rear+1)%n;
q[rear]=x;
}
}
void dq()
{
if(front==-1&&rear==-1)
{
printf("null");
}
else if(front==rear)
{
front=rear=-1;
}
else
{
printf("%d",q[front]);
front=(front+1)%n;
}
}
void di()
{
int i;
if(front==-1&&rear==-1)
printf("null");
else
{
for(i=front;i!=rear;i=(i+1)%n)
{
printf("%d",q[i]);
}
printf("%d",q[rear]);
}
}
void main()
{
int ch,x;
printf("\n1=eq\n2=dq\n3=di");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the data");
scanf("%d",&x);
eq(x);
break;
case 2:dq();
break;
case 3:di();
break;
default:printf("wrong");
break;
}
}
}

