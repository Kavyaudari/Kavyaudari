#include<stdio.h>
int main()
{
int a[10][10],t[10][10],r,c,i,j;
printf("enter the rows and columns:");
scanf("%d%d",&r,&c);
printf("\nenter matrix elements:\n");
for(int i=0;i<r;i++)
for(int j=0;j<c;j++){
scanf("%d",&a[i][j]);
}
printf("\nentered matrix:\n");
for(int i=0;i<r;i++)
for(int j=0;j<c;j++){
printf("%d",a[i][j]);
if(j==c - 1)
printf("\n");
}
for(int i=0;i<r;i++)
for(int j=0;j<c;j++){
t[j][i]=a[i][j];
}
printf("\ntranspose:\n");
for(int i=0;i<c;i++)
for(int j=0;j<r;j++);
{
printf("%d",t[i][j]);
if(j==r - 1)
printf("\n");
}
return 0;
}
