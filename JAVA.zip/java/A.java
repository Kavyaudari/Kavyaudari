package p1;
import java.util.*;
public class A
{
public void display()
{
System.out.println("kavya rangaiah");
}
}

