import biscuit.p;
import biscuit.inter1;
public class q implements inter1
{
public void m2()
{
System.out.println("i am kavya ");
}
public static void main(String args[])
{
p p1=new p();
p1.m1();
q q1=new q();
q1.m2();
}
}

