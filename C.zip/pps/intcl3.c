#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}*new,*temp,*tail,*prev;
struct node *create()
{
int n;
new=malloc(sizeof(struct node));
printf("enter the data");
scanf("%d",&n);
if(n==-1)
{
return 0;
}
else
{
new->data=n;
}
}
void inbeg()
{
new=create();
if(tail==0)
{
tail=new;
tail->next=new;
}
else
{
new->next=tail->next;
tail->next=new;
}
}
void inend()
{
temp=tail->next;
new=create();
if(tail==0)
{
tail=new;
tail->next=new;
}
else
{
new->next=tail->next;
tail->next=new;
tail=new;
}
}
void inpo()
{
int p,i;
printf("enter the pos");
scanf("%d",&p);
temp=tail->next;
new=create();
if(tail==0)
{
tail=new;
tail->next=new;
}
else
{
for(i=1;i<p-1;i++)
{
temp=temp->next;
}
new->next=temp->next;
temp->next=new;
}
}
void tra()
{
temp=tail->next;
if(tail==0)
printf("null");
else
{
do
{
printf("%d",temp->data);
temp=temp->next;
}while(temp!=tail->next);
}
}
void debeg()
{
temp=tail->next;
if(tail==0)
printf("null");
else if(temp->next==temp)
{
free(temp);
}
else
{
tail->next=temp->next;
free(temp);
}
}
void deend()
{
temp=tail->next;
if(tail==0)
printf("null");
else if(temp->next==temp)
{
free(temp);
}
else
{
while(temp->next!=tail->next)
{
prev=temp;
temp=temp->next;
}
prev->next=tail->next;
tail=prev;
}
}
void depo()
{
int p,i;
printf("enter the po");
scanf("%d",&p);
temp=tail->next;
if(tail==0)
printf("null");
else if(temp->next==temp)
{
free(temp);
}
else
{
for(i=1;i<p-1;i++)
{
temp=temp->next;
}
prev=temp->next;
temp->next=prev->next;
}
}
void main()
{
int ch;
printf("\n1=b\n2=e\n3=p\n4=t\n5=b\n6=e\n7=p");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:inbeg();
break;
case 2:inend();
break;
case 3:inpo();
break;
case 4:tra();
break;
case 5:debeg();
break;
case 6:deend();
break;
case 7:depo();
break;
default:printf("wrong");
break;
}
}
}
