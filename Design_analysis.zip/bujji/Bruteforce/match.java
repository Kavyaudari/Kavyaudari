import java.util.*;

class str{
public static void  main(String args[])
{
String str;
String b;
Scanner in=new Scanner(System.in);
System.out.println("string");
str=in.nextLine();
System.out.println("sub");
b=in.nextLine();
int m=str.length();
int n=b.length();
int c=0;
for(int i=0;i<=m-n;i++)
{
    if(str.charAt(i)==b.charAt(0))
    {
        int flag=0;
        for(int j=0;j<n;j++)
        {
            if(b.charAt(j)!=str.charAt(i+j))
            {
                flag=1;
                break;

            }
        }
        if(flag==0)
        {
            System.out.println(i);
            c++;

        }
    }
}
System.out.println(c);
}
}