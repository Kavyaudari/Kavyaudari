import java.util.*;
class Stringmethod
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the name");
String name=in.nextLine();
int value=name.length();
System.out.println("the length =" +value);
//lowercase 
//String lstring=name.toLowerCase();
//System.out.println(lstring);
//uppercase
//String ustring=name.toUpperCase();
//System.out.println(ustring);
//String nontrimmed ="	udari 	";
//System.out.println(nontrimmed);
//String trimmed=nontrimmed.trim();
//System.out.println(trimmed); removes extra spaces
//System.out.println(name.substring(2));returns the letters from that index
//System.out.println(name.substring(0,3));returns the letters from that index start to end
//System.out.println(name.replace('a','i');error
System.out.println(name.startsWith("kav"));//returns true or false values
System.out.println(name.charAt(3));
System.out.println(name.indexOf('k'));
System.out.println(name.equals("kavya"));
System.out.println(name.lastindexOf("kavya"));//error
}
}
