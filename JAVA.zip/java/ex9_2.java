import java.util.*;
class ex9_2
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
try
{
int a=in.nextInt();
int b=in.nextInt();
System.out.println("division " +(a/b));
}
catch(Exception e)
{
System.out.println("exception");
}
catch(ArithmeticException ae)
{
System.out.println("exception");
}
}
}

