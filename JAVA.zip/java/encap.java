//encapusulation
import java.util.*;
/*class student
{
//strudent class
private String name ;
String getName()
{
return name;
}
void setName(String name)
{
this.name=name;
}
}
class encap
{
public static void main(String args[])
{
student s=new student();
s.setName("kavya");
System.out.println(s.getName());
}
}*/
class student
{
private  int id;
private String name;
void set(int id,String name)//to get private values
{
this.id=id;//this refers to currentobject
this.name=name;
}
int getId()
{
return(id);
}
int getName()
{
return(Name);//to return the private values
}
class encap
{
public static void main(String args[])
{
student s=new student();
s.set(40 ,"kavya");
System.out.println(s.getId()+s.getName());
}
}
class cse extends student
{
//constructor
cse()
{
super(37,"varshini");//used to access the varaiables in child class
sub="oops";
}
cse(int id,String name)
{
super(id,name);
}
String sub;
void print()
{
System.out.println("id:"+id+"\n"+"name:"+name+"\n"+"sub"+sub);
}
void display()
{
System.out.println("id:"+id+"\n"+"name:"+name+"\n"+"sub"+sub);
}
}

