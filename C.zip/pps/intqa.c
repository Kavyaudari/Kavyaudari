#include<stdio.h>
#include<stdlib.h>
#define n 30
int q[n];
int rear=-1,front=-1;
void eq(int);
int dq();
void di();
void eq(int x)
{
if(rear>=n-1)
printf("overflow");
else if(front==-1&&rear==-1)
{
front=rear=0;
q[rear]=x;
}
else
{
rear++;
q[rear]=x;
}
}
int dq()
{
if(front==-1&&rear==-1)
{
printf("underflow");
}
else if(front==rear)
{
printf("%d",q[rear]);
front=rear=-1;
}
else
{
printf("%d",q[front]);
front++;
}
}
void di()
{
int i;
if(front==-1)
printf("null");
else
{
for(i=front;i<=rear;i++)
{
printf("%d",q[i]);
}
}
}
void main()
{
int ch,x;
printf("\n1=eq\n2=dq\n3=di");
while(ch!=-1)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("enter the data");
scanf("%d",&x);
eq(x);
break;
case 2:dq();
break;
case 3:di();
break;
default:printf("wrong");
break;
}
}
}

