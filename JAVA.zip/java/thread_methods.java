class myThread extends Thread
{
public myThread(String name)
{
super(name);
//    setPriority(Thread.Max_PRIORITY);
}
public void run()
{
int c=1;
while(true)
{
System.out.println(c++);
}
}
}
class thread_methods
{
public static void main(String args[]) throws Exception
{
Thread t1=new Thread("My First Thread ");
/*System.out.println("Id = "+t1.getId());
System.out.println("Name = "+t1.getName());
System.out.println("priority = "+t1.getPriority());
//t1.start();
System.out.println("State = "+t1.getState());
System.out.println("Alive = " +t1.isAlive());
System.out.println("daemon = "+t1.isDaemon());*/
t1.start();

}
}


