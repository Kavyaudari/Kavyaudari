//without arguments and without return type
#include<stdio.h>
#include<math.h>
void p(void);
void main()
{
p();
}
void p()
{
int a,b,c;
printf("enter a ,b values");
scanf("%d%d",&a,&b);
c=pow(a,b);
printf("%d",c);
}

