//inheritance concept
import java.util.*;
class circle
{
int rad;
double area()
{
return(3.14*rad*rad);
}
double perimeter()
{
return(2*3.14*rad);
}
}
class cylinder extends circle
{
int height;
double volume()
{
return (area()*height);
}
void display()
{
System.out.println("area="+area());
System.out.println("volume="+volume());
}
}
class testa
{
public static void main(String args[])
{
cylinder c=new cylinder();
Scanner in=new Scanner(System.in);
System.out.println("enter the radius and height");
c.rad=in.nextInt();
c.height=in.nextInt();
//System.out.println("area="+c.area());
//System.out.println("volume="+c.volume());
c.display();
}
}

