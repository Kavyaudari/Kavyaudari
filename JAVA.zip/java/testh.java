import java.util.*;
abstract class shape
{
abstract void area();
abstract void perimeter();
}
class circle extends shape
{
void area(int r)
{
System.out.println(3.14*r*r);
}
void perimeter(int r)
{
System.out.println(2*3.14*r);
}
}
class rectangle extends shape
{
void area(int l,int b)
{
System.out.println(l*b);
}
void perimeter()
{
System.out.println(2*(l+b));
}
}
class testh
{
public static void main(String args[])
{
rectangle r=new rectangle();
circle c =new circle();
Scanner in=new Scanner(System.in);
System.out.println("enter the radius");
int r=in.nextInt();
c.area(r);
c.perimeter(r);
System.out.println("enter the length and breadth");
int l,b;
l=in.nextInt();
b=in.nextInt();
r.area(l,b);r.perimeter(l,b);}
}

