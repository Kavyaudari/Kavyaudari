class Calci{
int a=8;
int b=7;
float res;
float Add(){
res=a+b;
return res;//DEFAULT 0
}
float Sub(){
res=a-b;
return res;
}
float Mult(){
res=a*b;
return res;
}
float Div(){
res=a/b;
return res;
}
public static void main(String args[])
{
int res;
Calci calciobj=new Calci();
res=calciobj.Add();
System.out.println(res);
}
}
