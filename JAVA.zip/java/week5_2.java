import java.util.*;
class a
{
double r;
double area(double r)
{
return(3.14*r*r);
}
double perimeter(double r)
{
return(2*3.14*r);
}
}
class week5_2
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the radius");
double r1=in.nextDouble();
a a1=new a();
System.out.println("area of circle="+a1.area(r1));
System.out.println("perimeter of circle="+a1.perimeter(r1));
}
}

