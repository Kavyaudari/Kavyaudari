import java.util.*;
class ex4_7
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter str");
String s=in.next();
int n=s.length();
for(int i=n-1;i>=0;i--)
{
char rev=s.charAt(i);
System.out.println(rev);
}
}
}

