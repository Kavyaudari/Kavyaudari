//check whether char or dig
#include<stdio.h>
int main()
{
char ch;
printf("enter any character");
scanf("%c",&ch);
if((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z'))
{
printf("\n%c is a alphabet",ch);
}
else if(ch>='0'&&ch<='9')
{
printf("\n%c is a digit",ch);
}
else
{
printf("\n%c is not  an alphabet and digit");
}
return 0;
}
