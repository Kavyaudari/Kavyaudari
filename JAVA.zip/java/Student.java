import java.util.*;
class Stud
{
int id;
String name;
String branch;
Stud()
{
id=1044;
name="Kavya";
branch="CSE";
}
Stud(int x)
{
id=x;
}
Stud(int x,String y,String z)
{
id=x;
name=y;
branch=z;
}
void display()
{
System.out.println(id+""+name+""+branch);
}
}
class Student
{
public static void main(String[] args)
{
Stud s1=new Stud();
Stud s1=new Stud(1234);
Stud s1=new Stud(40,"Kavya","cse");
s1.display();
s2.display();
s3.display();
}
}
