#include<stdio.h>
#include<stdlib.h>
#define n 20
int q[n];
int front=-1;
int rear=-1;
void enq(int);
void deq();
void dis();
void enq(int ele)
{
if(front=(rear+1)%n)
printf("overflow");
else if(front==-1&&rear==-1)
{
front=rear=0;
q[rear]=ele;
}
else
{
rear=(rear+1)%n;
q[rear]=ele;
}
}
void deq()
{
if(front==-1&&rear==-1)
printf("underflow");
else if(front==rear)
{
front=rear=0;
}
else
{
printf("%d",q[front]);
front=(front+1)%n;
}
}
void dis()
{
int i;
for(i=front;i!=rear;i=(i+1)%n)
{
printf("%d",q[i]);
}
printf("%d",q[rear]);
}
void main()
{
int ch,ele;
printf("\n1=enq\n2=deq\n3=dis\n");
while(ch!=4)
{
printf("enter the ch");
scanf("%d",&ch);
switch(ch)
{
case 1:printf("ente rth enumber");
scanf("%d",&ele);
enq(ele);
break;
case 2:deq();
break;
case 3:dis();
break;
}
}
}


