//unions
#include<stdio.h>
union c4
{
int x; 
float y;
char z;
}a;
int main()
{
a.x=5;
a.y=90.8;
printf("%d",a.x);
}
