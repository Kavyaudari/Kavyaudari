import java.util.*;
class Linearsearch
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size of array");
search obj=new search();
int n=in.nextInt();
int[] array=new int[n];
System.out.println("enter the elements");
for(int i=0;i<n;i++)
{
array[i]=in.nextInt();
}
obj.test(array,n);
//obj.display(array,n);
}
}
class search
{
void test(int array[],int n)
{
System.out.println("enter the number to be searched");
Scanner in=new Scanner(System.in);
int x=in.nextInt();
int flag=0;
for(int i=0;i<n;i++)
{
if(array[i]==x)
{
flag=1;
break;
}
}
if(flag==1)
{
System.out.println("found"+x);
}
else 
{
System.out.println("not found");
}
}

}
