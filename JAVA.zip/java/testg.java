//super key
class p
{
int a=45;
void display()
{
System.out.println("it is a parent class");
}
}
class c extends p
{
int a=89;
void display()
{
System.out.println("it is child class");
System.out.println(a);//we can access the value of rthe child because of overriding
System.out.println(super.a);//super is a keyword which can access the parent values
super.display();
}
}
class testg
{
public static void main(String args[])
{
c c1=new c();
c1.display();
}
}


