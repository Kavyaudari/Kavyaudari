package biscuit;
public class p
{
public void m1()
{
System.out.println("Hii ");
}
}

