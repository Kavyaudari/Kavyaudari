//passing arrays to functions
#include<stdio.h>
int largest(int[],int);
int main()
{
int a[10],i,large;
printf("enter 10 elemants");
for(i=0;i<10;i++)
{
scanf("%d",&a[i]);
}
large=largest(a,10);
printf("largest=%d",large);
}
int largest(int b[10],int x)
{
int max=b[0],i;
for(i=0;i<x;i++)
{
if(max<b[i])
max=b[i];
}
return(max);
}

