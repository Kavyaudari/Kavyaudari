import java.util.*;
class Circle
{
int radius;
double area;
double circum;
void circle()
{
area=(3.14*radius*radius);
circum=(2*3.14*radius);
}
}
class Circle1
{
public static void main(String args[])
{
System.out.println("area of a circle");
Scanner in=new Scanner(System.in);
System.out.println("enter the radius");
c1.radius=in.nextInt();
circle c1=new circle();
c1.circle(radius);
System.out.println(c1.area);
System.out.println(c1.circum);
}
}
