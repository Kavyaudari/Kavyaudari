import java.util.*;
class ex4_5
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter str");
String s=in.next();
int v=0;int c=0;
s=s.toLowerCase();
char ch;
for(int i=0;i<s.length();i++)
{
ch=s.charAt(i);
if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
{
v++;
}
else if(ch>'a'&&ch<='z')
{
c++;
}
}
System.out.println(v);
System.out.println(c);
}
}

