//palindrome
#include<stdio.h>
int main()
{
int n,rev=0,r,t;
printf("enter n value");
scanf("%d",&n);
t=n;
while(n>0)
{
r=n%10;
rev=(rev*10)+r;
n=n/10;
}
if(t==rev)
{
printf("it is a palindrome");
}
else
printf("it is not palindrome");
}
