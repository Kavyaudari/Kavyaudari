//mean variance,std
#include<stdio.h>
#include<math.h>
int main()
{
int n,i,sum=0,s1=0;
float v,std,avg=0;
printf("enter array size");
scanf("%d",&n);
int a[n];
printf("enter the elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
sum=sum+a[i];
avg=sum/n;
}
{
s1=sum+pow((a[i]-avg),2);
}
{
v=s1/n;
}
std=sqrt(v);
printf("avg=%f\n",avg);
printf("v=%f\n",v);
printf("std=%f\n",std);
}
