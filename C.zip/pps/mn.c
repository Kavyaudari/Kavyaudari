tg#include<stdio.h>
int minfun();
int maxfun();
int sum();
float avgfun();
int main()
{
int n,i,check=-1;
printf("enter array size\n");
scanf("%d",&n);
int a[n]
printf("enter array elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
while(check!=0)
{
printf("\n enter the choices\n1 for minimum function\n2 for maximum function\n3 for avg\n");
scanf("%d",&check);
}
switch(check)
{
case 1:printf("minimum function= %d\n",minfun(a,n));
break;
case 2:printf("maximum function=%d\n",maxfun(a,n));
break;
case 3:printf("avgfun=%f\n",avgfun(a,&sum,n));
break;
case 0;printf("\nprogram sucessfully executed");
break;
default:printf("\ninvalid\n");
}
printf(".........");
}
return 0;
}
int minfun(int a[],int n)
{
int i,min=a[0];
for(i=0;i<n;i++)
{
if(a[i]<min)
{
min=a[i];
}
}
return min;
}
int maxfun(int a[],int n)
{
int i,max=a[0];
for(i=0;i<n;i++)
{
if(a[i]>max)
{
max=a[i];
}
}
return max;
}
float avgfun(int a[],int sum,int n)
{
int i;
 sum=0;
 for(i=0;i<n;i++)
 {
 sum=sum+a[i];
 }
 printf("%d=sum",sum);
 return((sum/n));
 }
 
 

