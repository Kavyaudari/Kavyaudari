//without arguments with return type
#include<stdio.h>
int fact(void);
int main()
{
int c;
c=fact();
printf("%d",c);
}
int fact()
{
int x,y,z;
printf("enter the values");
scanf("%d%d",&x,&y);
z=x*y;
return z;
}
