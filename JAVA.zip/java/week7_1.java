import java.util.*;
abstract class shape
{
abstract void getArea(int r,int a);
abstract void getVolume(int r,int a);
}
class calculations extends shape
{
public void getArea(int r,int a)
{
System.out.println("area of circle = " +(3.14*r*r));
System.out.println("surface area of cube = " +(6*a*a));
System.out.println("surface area of sphere = "+(4*3.14*r*r));
}
public void getVolume(int r,int a)
{
System.out.println("volume of cube = "+(a*a*a));
System.out.println("volume of sphere ="+((4/3)*3.14*r*r*r));
}
}
class week7_1
{
public static void main(String args[])
{
shape s1=new calculations();
Scanner in=new Scanner(System.in);
System.out.println("enter the r,a values ");
int r=in.nextInt();
int a=in.nextInt();
s1.getArea(r,a);
s1.getVolume(r,a);
}
}
