import java.util.*;
class prime
{
public static void main(String args[])
{
System.out.println("enter the number to find its prime factors");
Scanner in=new Scanner(System.in);
int a=in.nextInt();
int count=0;
if(a>=2&&a%2==0)
{
System.out.println("2");
}
for(int i=1;i<=a;i++)
{
if(a%i==0)
{
for(int j=2;j<i;j++)
{
if(i%j==0)
{
count=0;
break;
}
else
{
count=1;
}
}
if(count==1)
{
System.out.println(i);
}
}
}
}
}





