import java.util.*;
/*Scanner in=new Scanner(System.in);
System.out.println("enter the values");
int a=in.nextInt();
int b=in.nextInt();
int c=in.nextInt();
double det,r1,r2;
det=b*b-4*a*c;
if(det<0)
{
System.out.println("roots are imaginary ");
}
else if(det==0)
{
r1=-b/2*a;
r2=-b/2*a;
System.out.println("roots are equal "+r1);
System.out.println(r2);
}
else
{
r1=(-b+(Math.sqrt(det))/(2*a));
r2=(-b-(Math.sqrt(det))/(2*a));
System.out.println("roots are real ");
System.out.println(r1);
System.out.println(r2);
}
}
}
*/
//calculator
/*
System.out.println("enter the values ");
Scanner in=new Scanner(System.in);
int a=in.nextInt();
int b=in.nextInt();
System.out.println(" enter the option ");
System.out.println("1=addition,2=sub,3=mult,4=division,5=modulo");
int n=in.nextInt();
switch(n)
{
case 1:System.out.println("add=" +(a+b));
break;
case 2:System.out.println("sub= "+(a-b));
break;
case 3:System.out.println("mult= " +(a*b));
break;
case 4:System.out.println("div= "+(a/b));
break;
case 5:System.out.println("modulo= "+(a%b));
break;
}
}
}
*/
//prime numbers
/*
Scanner in=new Scanner(System.in);
System.out.println("enter the num ");
int a=in.nextInt();
int c=0;
if(a>=2&&a%2==0)
{
System.out.println("2");
}
for(int i=1;i<=a;i++)
{
	if(a%i==0)
	{
		for(int j=2;j<i;j++)
		{
		if(i%j==0)
		{
		 c=0;
		 break;	
		}
		else
		{
		c=1;
		}
		}
	if(c==1)
	{
	System.out.println(i);
	}
	}
	}
}
}
*/
	/*Scanner in=new Scanner(System.in);
System.out.println("enter the number ");
int a=in.nextInt();
int t=a;
int sum=0;
while(a>0)
{
sum=sum*10;
int rem=a%10;
sum=sum+rem;
}
if(t==sum)
{
System.out.println("palindrome " +t);
}
else
{
System.out.println("not a palindrome ");
}
}
}

public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n=in.nextInt();
int a[]= new int[n];
System.out.println("enter the elements ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
System.out.println("sorted ");
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(a[i]>a[j])
{
int t=a[i];
a[i]=a[j];
a[j]=t;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(a[i]);
}

}
}
-> WEEK-2
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
check c1=new check();
System.out.println("enter the size ");
int n=in.nextInt();
int a[]=new int[n];
System.out.println("enter the elements ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
c1.sort(a,n);
}
}
class check
{
void sort(int a[],int n)
{
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(a[i]>a[j])
{
int t=a[i];
a[i]=a[j];
a[j]=t;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(a[i]);
}
}
}

   
   //linear search
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
check c1=new check();
System.out.println("enter the size ");
int n=in.nextInt();
int a[]=new int[n];
System.out.println("enter the elements ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
System.out.println("enter the element ");
int e=in.nextInt();
c1.search(a,n,e);
}
}
class check
{
void search(int a[],int n,int e)
{
for(int i=0;i<n;i++)
{
if(a[i]==e)
{
System.out.println(a[i]);
break;
}
}
}
}

 
 // binary search
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
check c1=new check();
int n=in.nextInt();
int a[]=new int[n];
System.out.println("enter the elements ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
System.out.println("enter the element");
int e=in.nextInt();
c1.search(a,n,e);
}
}
class check
{
void search(int a[],int n,int e)
{
int f=0;
int l=n-1;
int m=(f+l)/2;
while(f<=l)
{
if(a[m]<e)
{
f=m+1;
}
else if(a[m]==e)
{
System.out.println("found " +a[m]);
break;
}
else
{
l=m-1;
m=(f+l)/2;
}
}
if(l<f)
{
System.out.println("not found ");
}
}
}


    //add matrix
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the row and col");
int r=in.nextInt();
check c1=new check();
int c=in.nextInt();
int a[][]=new int[r][c];
System.out.println("enter the elements of a");
for(int i=0;i<r;i++)
{
for(int j=0;j<c;j++)
{
a[i][j]=in.nextInt();
}
}
int b[][]=new int[r][c];
System.out.println("enter the ekements of b");
for(int i=0;i<r;i++)
{
for(int j=0;j<c;j++)
{
b[i][j]=in.nextInt();
}
}
c1.add(a,b,r,c);
}
}
class check
{
void add(int a[][],int b[][],int r,int c)
{
int sum[][]=new int[r][c];
for(int i=0;i<r;i++)
{
for(int j=0;j<c;j++)
{
sum[i][j]=a[i][j]+b[i][j];
}
}
for(int i=0;i<r;i++)
{
for(int j=0;j<c;j++)
{
System.out.println(sum[i][j]);
}
}
}
}


  //mult
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the row and col of 1st");
int r=in.nextInt();
check c1=new check();
int c=in.nextInt();
int a[][]=new int[r][c];
System.out.println("enter the elements of a");
for(int i=0;i<r;i++)
{
for(int j=0;j<c;j++)
{
a[i][j]=in.nextInt();
}
}
System.out.println("enter the row and col of 2nd");
int p=in.nextInt();
int q=in.nextInt();
if(c!=p)
{
System.out.println("not ");
}
else
{
int b[][]=new int[p][q];
System.out.println("enter the elements of a");
for(int i=0;i<p;i++)
{
for(int j=0;j<q;j++)
{
b[i][j]=in.nextInt();
}
}
c1.mult(a,b,r,c,p,q);
}
}
}
class check
{
void mult(int a[][],int b[][],int r,int c,int p,int q)
{
int m[][]=new int[r][q];

int s=0;
for(int i=0;i<r;i++)
{
for(int j=0;j<q;j++)
{
for(int k=0;k<p;k++)
{
s=s+a[i][k]*b[k][j];
}
m[i][j]=s;
s=0;
}
}
for(int i=0;i<r;i++)
{
for(int j=0;j<q;j++)
{
System.out.print(m[i][j]+ "\t ");
System.out.println();
}
}
}
}


//string 
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int s=in.nextInt();
int n;
n=s+1;
System.out.println("enter the names ");
String a[]=new String[n];
for(int i=0;i<n;i++)
{
a[i]=in.nextLine();
}
check c1=new check();
c1.search(a,n);
}
}
class check
{
void search(String a[],int n)
{
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(a[i].compareTo(a[j])>0)
{
String t=a[i];
a[i]=a[j];
a[j]=t;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(a[i]);
}
}
}
*/
//WEEK-3

