import java.util.*;
class account
{
int a_no;
String name;
double am;
account(int a_no,String name,double am)
{
this.a_no=a_no;
this.name=name;
this.am=am;
}
void debit(double w)
{
if(am>w)
{
am=am-w;
System.out.println("remain = " +am);
}
else
{
System.out.println("insufficent ");
}
}
void credit(double d)
{
am=am+d;
System.out.println("amount = " +am);
}
void current(double w,double d)
{
double m=(am-w)+d;
System.out.println("current = " +m);
}
}
class ex5_4
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the details");
int ano=in.nextInt();
String name=in.next();
double am=in.nextDouble();
account a1=new account(ano,name,am);
System.out.println("enter the amount to withdraw");
int w=in.nextInt();
a1.debit(w);
System.out.println("enter the amount to deposit");
int d=in.nextInt();
a1.credit(d);
a1.current(w,d);
}
}


