import java.util.*;
class str{
char arr[];
char a[];
int n;
Scanner in=new Scanner(System.in);
public str(int n)
{
this.n=n;
a=new char[n];
arr=new char[n];
System.out.println("enter");
for(int i=0;i<n;i++)
{
arr[i]=in.nextLine().charAt(0);
}
}
void fill(int n,int k)
{
if(n==k)
{
for(int i=0;i<n;i++)
{
System.out.print(a[i]);
}
System.out.println();
return ;

}
for(int i=0;i<n;i++)
{
if(isSafe(k,arr[i]))
{
a[k]=arr[i];
fill(n,k+1);
}
}
}
 
 
 boolean isSafe(int k,char i)
 {
 for(int j=0;j<k;j++)
 {
 if(a[j]==i)
 return false;
 }
 return true;
 }
 }
 
 
 class test{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        int n;
        System.out.println("enter size");
        n=in.nextInt();
        str b=new str(n);
        b.fill(n,0);

    }
}
