import java.util.*;
/*class emp
{
int id;
String name;
double salary;
String address;
String desig;
int age;
void display()
{
System.out.println("details are " +name+id+salary+address+desig+age);
}
}
class w2
{
public static void main(String args[])
{
emp e[]=new emp[3];
e[0]=new emp();
e[1]=new emp();
e[2]=new emp();
Scanner in=new Scanner(System.in);
for(int i=0;i<3;i++)
{
System.out.println("enter the details ");
e[i].id=in.nextInt();
e[i].name=in.next();
e[i].salary=in.nextDouble();
e[i].address=in.next();
e[i].desig=in.next();
e[i].age=in.nextInt();
}
System.out.println("enter the id ");
int search=in.nextInt();
for(int i=0;i<3;i++)
{
if(e[i].id==search)
{
e[i].display();
break;
}
}
}
}
class product
{
int id;
String name;
int price ;
int qty;
int tprice(int q)
{
return(q*price );
}
}
class w3
{
public static void main(String args[])
{
product p[]=new product[3];
p[0]=new product();
p[1]=new product();
p[2]=new product();
Scanner in=new Scanner(System.in);
for(int i=0;i<3;i++)
{
System.out.println("enter the details ");
p[i].id=in.nextInt();
p[i].name=in.next();
p[i].price=in.nextInt();
p[i].qty=in.nextInt();
}
int total=0;
int x;
do
{
System.out.println("enter the id ");
int id=in.nextInt();
System.out.println("enter the qty ");
int q=in.nextInt();
switch(id)
{
case 1:total+=p[0].tprice(q);
break;
case 2:total+=p[1].tprice(q);
break;
case 3:total+=p[2].tprice(q);
break;
default:
System.out.println("invalid ");
}
System.out.println("do u want ");
x=in.nextInt();
}
while(x==1);
System.out.println("total="+total );
}
} 
class product
{
int id; 
String name;
int price ;
int qty;
int tprice(int q)
{
return(q*price);
}
}
class w3
{
public static void main(String args[])
{
product p[]=new product[3];
p[0]=new product();
p[1]=new product();
p[2]=new product();
Scanner in=new Scanner(System.in);
for(int i=0;i<3;i++)
{
System.out.println("enter the details ");
p[i].id=in.nextInt();
p[i].name=in.next();
p[i].price=in.nextInt();
p[i].qty=in.nextInt();
}
int total=0;
int x;
do
{
System.out.println("enter the id and q");
int id=in.nextInt();
int q=in.nextInt();
switch(id)
{
case 1:total+=p[0].tprice(q);
break;
case 2:total+=p[1].tprice(q);
break;
case 3:total+=p[2].tprice(q);
break;
default:
System.out.println("invalid ");
}
System.out.println("do you want ");
x=in.nextInt();
}
while(x==1);
System.out.println("total= "+total);
}
}

class w3
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int a[]=new int[5];
for(int i=0;i<5;i++)
{
System.out.println("ente rthe elements ");
int e=in.nextInt();
int c=0;
for(int j=0;j<a.length;j++)
{
if(e==a[j])
{
c=1;
i=i-1;
System.out.println("repeated ");
break;
}
else if(e<10||e>100)
{
System.out.println("not in range ");
c=1;
i=i-1;
break;
}
}
if(c!=1)
{
a[i]=e;
for(int k=0;k<=i;k++)
{
System.out.println(a[k]);
}
}
}
}
}

import java.util.Random;
class w3
{
public static void main(String args[])
{
int i,dice1,dice2;
int m=0;
int n=0;
Scanner in=new Scanner(System.in);
Random r=new Random();
dice1=r.nextInt(6);
dice2=r.nextInt(6);
for(i=0;i<3;i++)
{
dice1=in.nextInt();
dice2=in.nextInt();
if((dice1>=1&&dice1<=6)&&(dice2>=1&&dice2<=6))
{
if(dice1==dice2)
{
n++;
}
else
{
m++;
}}
else
{
System.out.println("invalid ");
}
}
System.out.println("matched = " +n);
System.out.println("not matched = "+m);
}
}

class product
{
int id;
String name;
int price ;
int qty;
int tprice(int q)
{
return(price*q);
}
}
class w3
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
product p[]=new product[3];
p[0]=new product();
p[1]=new product();
p[2]=new product();
System.out.println("enter the deatils ");
for(int i=0;i<3;i++)
{
p[i].id=in.nextInt();
p[i].name=in.next();
p[i].price=in.nextInt();
p[i].qty=in.nextInt();
}
int total=0;
int x;
do
{
System.out.println("enter the id ");
int id=in.nextInt();
System.out.println("enter the quantity ");
int q=in.nextInt();
switch(id)
{
case 1:total+=p[0].tprice(q);
break;
case 2:total+=p[2].tprice(q);
break;
case 3:total+=p[3].tprice(q);
break;
default:
System.out.println("invalid ");
}
System.out.println("do you want ");
x=in.nextInt();
}while(x==1);
System.out.println("total= " +total);
}
}

class w3
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
int a[]=new int[5];
for(int i=0;i<5;i++)
{
System.out.println("enter the element ");
int e=in.nextInt();
int c=0;
for(int j=0;j<a.length;j++)
{
if(e==a[j])
{
System.out.println("repeated ");
c=1;
i=i-1;
break;
}
else if(e<10||e>100)
{
System.out.println("not in range ");
c=1;
i=i-1;
break;
}
}
if(c!=1)
{
a[i]=e;
for(int k=0;k<=i;k++)
{
System.out.println(a[k]);
}
}
}
}
}

import java.util.Random;
class w3
{
public static void main(String args[])
{
int dice1,dice2,i;
int m=0;
int n=0;
Random r=new Random();
dice1=r.nextInt(6);
dice2=r.nextInt(6);
for(i=0;i<3;i++)
{
Scanner in=new Scanner(System.in);
dice1=in.nextInt();
dice2=in.nextInt();
if((dice1>=1&&dice1<=6)&&(dice2>=1&&dice2<=6))
{
if(dice1==dice2){
n++;
}
else
{
m++;
}
}
else
{
System.out.println("invalid ");
}
}
System.out.println(m);
System.out.println(n);
}
}*/

