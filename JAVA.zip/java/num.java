import motu.cal1;
public class num
{
public static void main(String args[])
{
cal1 c1=new cal1();
System.out.println("addition " +c1.add(2,3));
System.out.println("addition " +c1.sub(2,3));
System.out.println("addition " +c1.mult(2,3));
}
}

