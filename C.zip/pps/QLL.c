#include<stdio.h>
#include<stdlib.h>
void enqueue();
void dequeue();
void display();
struct node
{
int data;
struct node *next;
}*front=0,*rear=0,*ptr,*new;
void enqueue()
{
new=malloc(sizeof(struct node));
new->next=NULL;
printf("ente rthe data");
scanf("%d",&new->data);
if(front==NULL&&rear==NULL)
{
front=rear=new;
}
else
{
rear->next=new;
rear=new;
}
}
void dequeue()
{
ptr=front;
if(front==NULL&&rear==NULL)
{
printf("emptyy list");
}
else if(front ==rear)
{
printf("%d",front->data);
free(ptr);
}
else
{
printf("%d",ptr->data);
front=front->next;
free(ptr);
}
}
void display()
{
ptr=front;
if(front==NULL)
{
printf("empty list");
}
else
{
while(ptr->next!=NULL)
{
printf("%d",ptr->data);
ptr=ptr->next;
}
printf("%d",ptr->data);
}
}
void main()
{
int ch;
while(ch!=5)
{
printf("\n1=enqueue\n2=dequeue\n3=display\n4=exit");
scanf("%d",&ch);
switch(ch)
{
case 1:enqueue();
break;
case 2:dequeue();
break;
case 3:display();
break;
case 4:printf("enter the valid choice\n");
break;
}
}
}
