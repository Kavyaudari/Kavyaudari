import java.util.*;
class namesort
{
public static void main(string args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n=in.nextInt();
String s[]=new String[n];
System.out.println("enter the strings ");
for(int i=0;i<n;i++)
{
s[i]=in.nextLine();
}
System.out.println("after sorting");
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(s[i].compareTo(s[j])>0)
{
String t;
t=s[i];
s[i]=s[j];
s[j]=t;
}
}
}
for(int i=0;i<n;i++)
{
System.out.println(s[i]);
}
}
}

