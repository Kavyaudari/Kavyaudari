import java.util.*;
class subset
{
int n;
int[] value;
int sum;
int[][] a;
public subset(int n,int sum)
{
value=new int[n];
this.n=n;
this.sum=sum;
a=new int[n+1][sum+1];
for(int i=0;i<=n;i++)
{
for(int j=0;j<=sum;j++)
{
a[i][j]=-1;
}
}
}
int ss(int n,int sum)
{
if(a[n][sum]!=-1)
{
return(a[n][sum]);
}
if(sum==0)
{
return(a[n][sum]=1);
}
if(n==0)
{
return(a[n][sum]=0);
}
if(value[n-1]<=sum)
{
return(a[n][sum]=(ss(n,sum-value[n-1])+ ss(n-1,sum)));
}
else
{
return(a[n][sum]=ss(n-1,sum));
}
}
} 
class msubsetsum
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter no.of numbers in array=");
int n=sc.nextInt();
System.out.println("enter required sum value=");
int sum=sc.nextInt();
subset s=new subset(n,sum);
for(int i=0;i<n;i++)
{
System.out.println("enter element"+(i+1));
s.value[i]=sc.nextInt();
}
System.out.println(s.ss(n,sum));
}


}

