//binary value
#include<stdio.h>
int main()
{
int a[8],n,i,j;
printf("enter the n value");
scanf("%d",&n);
for(i=0;n!=0;i++)
{
a[i]=n%2;//lcm
n=n/2;
}
for(j=i-1;j>=0;j--)//reverse
{
printf("%d",a[j]);
}
}
