//double pointer
#include<stdio.h>
int main()
{
int a;
printf("enter the a value");
scanf("%d",&a);
int * p;
p=&a;
int * * d;
d=&p;
printf("%d %d %d %d %d",p,d,a, * p,* * d);
}
