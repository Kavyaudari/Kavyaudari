//binary tree program
#include<stdio.h>
#define MAX 100
int bt[MAX],i=0;
void insertnode(int n)
{
if(i>MAX-1)
{
printf("full");
}
else
{
bt[i]=n;
i++;
}
}
  int getleftchild(int i)
 {
  return(2*i+1);
  }
  int getrightchild(int i)
  {
  return(2*i+2);
  }
  void inorder(int index)
  {
 // printf("inorder=");
  if(index<i)
  {
 // printf("inorder is ");
  inorder(getleftchild(index));
  printf("%d ",bt[index]);
  inorder(getrightchild(index));
  }
  }
    void postorder(int index)
  {
 // printf("postorder=");
  if(index<i)
  {
  inorder(getleftchild(index));
  inorder(getrightchild(index));
   printf("%d ",bt[index]);
  }
  }
    void preorder(int index)
  {
  if(index<i)
  {
  //printf("preorder is ");
  printf(" %d ",bt[index]);
  inorder(getleftchild(index));
  inorder(getrightchild(index));
  }
  }
  int main()
  {
  int n,i,num;
  printf("enter the size");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
  printf("enter a number");
  scanf("%d",&num);
  insertnode(num);
  }
  printf("inorder");
  inorder(0);
  printf("postorder");
  postorder(0);
  printf("preorder");
  preorder(0);
  }
 
  
