import java.util.*;
class entrance
{
public void enter(int y)
{
System.out.println(y+ "showed");
System.out.println(y+ "entere");
}
}
class person extends Thread
{
int y;
entrance e;
person(int y,entrance e)
{
this.e=e;
this.y=y;
}
public void buy(int y)
{
System.out.println(y+ "bought");
}
public void run()
{
buy(y);
e.enter(y);
}
}
class theatre
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter");
entrance e=new entrance();
int n=in.nextInt();
person p[]=new person[n+1];
for(int i=1;i<=n;i++)
{
p[i]=new person(i,e);
p[i].start();
}
}
}
