class week10_4
{
public static void main(String args[])
{
System.out.println("hii ");
try
{
class.ForName("kavya udari ");
}
catch(Exception e)
{
System.out.println(e);
}
}
}
