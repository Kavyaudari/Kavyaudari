//voting
#include<stdio.h>
int main()
{
int age,a;
printf("enter your age");
scanf("%d",&age);
if(age>18)
{
printf("your are eligible for voting");
}
else
{
a=18-age;
printf("sorry! you have %d years to cast your vote",a);
}
return 0;
}
