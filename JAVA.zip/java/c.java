import p1.*;
class B
{
public static void main(String args[])
{
A a=new A();
a.display();
}
}

