//this keyword
import java.util.*;
class student
{
String name;
int roll;
void s1(int roll,String name)
{
this.name=name;
this.roll=roll;
}
void display()
{
System.out.println("name="+name+" "+roll="+roll);
}
}
class test
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
String name=in.nextLine();
int roll=in.nextInt();
this s=new this();
s.s1(name,roll);
s.display();
}
}

