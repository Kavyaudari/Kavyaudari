#include<stdio.h>
#include<stdlib.h>
#define n 4
int q[n];
int front=-1,rear=-1;
void bfs(int[][n],int[]);
void enqueue(int);
int dequeue();
int main()
{
int graph[n][n],i,j;
int v[n]={0};
printf("enter the adjacencey matrix");
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
scanf("%d",&graph[i][j]);
}
}
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
printf("%d",graph[i][j]);
}
printf("\n");
}
bfs(graph,v);
}
void bfs(int graph[][n],int v[])
{
front=rear=0;
enqueue(0);
v[0]=1;
while(front!=rear)
{
int c=q[front];
printf("%d",q[front]);
dequeue();
for(int i=0;i<n;i++)
{
if(graph[c][i]==1&&v[i]==0)
{
enqueue(i);
v[i]=1;
}
}
}
}
void enqueue(int x)
{
q[rear]=x;
rear++;
}
int dequeue()
{
int x;
x=q[front];
front++;
return x;
}
