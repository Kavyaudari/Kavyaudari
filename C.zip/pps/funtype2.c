//without arguments and with return type
#include<stdio.h>
int fun(void);
int main()
{
int z;
z=fun();
printf("z=%d",z);
}
int fun()
{
int a=3,b=2;
int c;
c=a*b;
return(c);
}
