//inheritance 
import java.util.*;
class sample
{
int x=10;
void print()
{
System.out.println("parent");
System.out.println(x);
}
class s1 extends sample
{
int y=27;
void display()
{
System.out.println("child");
System.out.println(x);
System.out.println(y);
}
public static void main(String args[])
{
s1 k1=new s1();
k1.display();
k1.print();
}
}
}
