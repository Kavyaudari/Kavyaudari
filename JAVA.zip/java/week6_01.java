import java.util.*;
class shape
{
void area(int x)
{
System.out.println("the area of the square = " +(x*x));
}
void area(float m,float n)
{
System.out.println("the area of the rectangle = " +(m*n));
}
void area(double r)
{
System.out.println("the area of the circle = " +(3.14*r*r));
}
void area(int a,int b)
{
System.out.println("the area of the triangle  = " +((a*b)/2));
}
}
class week6_01
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
shape s=new shape();
System.out.println("enter the details = ");
int x=in.nextInt();
float m=in.nextFloat();
float n=in.nextFloat();
double r=in.nextDouble();
int a=in.nextInt();
int b=in.nextInt();
s.area(x);
s.area(m,n);
s.area(r);
s.area(a,b);
}
}
