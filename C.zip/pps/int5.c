//factors of a number
#include<stdio.h>
int main()
{
int i,n,c=0;
printf("enter value of n");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
if(n%i==0)
{
c=c+1;
}
}
printf("factors=%d",c);
}
