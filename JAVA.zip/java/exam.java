import java.util.*;
/*class exam
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n=in.nextInt();
System.out.println("enter the emplyees details ");
int id[]=new int[n];
String name[]=new String[n];
String address[]=new String[n];
double salary[]=new double[n];
String des[]=new String[n];
for(int i=0;i<n;i++)
{
id[i]=in.nextInt();
name[i]=in.next();
address[i]=in.next();
salary[i]=in.nextDouble();
des[i]=in.next();
}
System.out.println("enter the id ");
int ID=in.nextInt();
for(int i=0;i<n;i++)
{
if(ID==id[i])
{
System.out.println("name=" +name[i] +"id=" +id[i] +"address=" +address[i] +"des=" +des[i] +"salary=" +salary[i] );
}
}
}
}*/
/*class exam
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
double p1,p2,p3;
double p4,p5;
System.out.println("enter the price of each product ");
p1=in.nextDouble();
p2=in.nextDouble();
p3=in.nextDouble();
p4=in.nextDouble();
p5=in.nextDouble();
double total=0.0;
System.out.println("enter the which product you want ? ");
int n=in.nextInt();
System.out.println("enter the quantity you need ");
double q=in.nextDouble();
System.out.println("do you want another ");
int m=in.nextInt();
switch(n)
{
case 1:total=(p1*q);
break;
case 2:total=(p2*q);
break;
case 3:total=(p3*q);
break;
case 4:total=(p4*q);
break;
case 5:total=(p5*q);
break;

}
System.out.println("the total cost =" +total);
}
}*/
/*class exam
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n=in.nextInt();
int a[]=new int[n];
for(int i=0;i<n;i++)
{
System.out.println("enter the element ");
int e=in.nextInt();
int c=0;
for(int j=0;j<a.length;j++)
{
if(e==a[j])
{
c=1;
System.out.println("repeated ");
i=i-1;
break;
}
else if(e<10||e>100)
{
System.out.println("not in range ");
c=1;
i=i-1;
break;
}
}
if(c!=1)
{
a[i]=e;
for(int k=0;k<=i;k++)
{
System.out.println(a[k]);
}
}
}
}
}*/
/*class exam
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the radius ");
double r=in.nextDouble();
circle c1=new circle();
c1.radius=r;
System.out.println("area =" +c1.area());
System.out.println("perimeter ="+c1.perimeter());
}
}

class circle
{
double radius;
double area()
{
return 3.14*radius*radius;
}
double perimeter()
{
return 2*3.14*radius;
}
}*/
/*interface fee
{
void getamount(int clgfee);
void getfullname(String name);
void getaddress(String address);
void getcontact(double contact);
}
class hosteler implements fee
{
Scanner in=new Scanner(System.in);
int h_fee=in.nextInt();
void getamount(int clgfee)
{
System.out.println("total fee =" +(h_fee+clgfee));
}
void getfullname(String name)
{
System.out.println("the name= "+name);
}
void getaddress(String address)
{
System.out.println("address ="+address);
}
void getcontact(double contact)
{
System.out.println("contact ="+contact);
}}
class nonhosteler implements fee
{
void getamount(int clgfee)
{
System.out.println("total fee =" +(h_fee+clgfee));
}
void getfullname(String name)
{
System.out.println("the name= "+name);
}
void getaddress(String address)
{
System.out.println("address ="+address);
}
void getcontact(double contact)
{
System.out.println("contact ="+contact);
}}
class exam
{
public static void main(String args[])
{
System.out.println("enter the details of hostelers ");
fee h1=new hosteler();
int clgfee=in.nextInt();
String name=in.next();
String address=in.next();
double contact=in.nextDouble();
h1.getamount(clgfee);
h1.getfullname(name);
h1.getaddress(address);
h1.getcontact(contact);
}
}*/


interface Studentfee
{
void getAmount(int clgfee);
void getFirstname(String fname);
void getLastname(String lname);
void getAddress(String address);
void getContact(double contact);
}
class Hostler implements Studentfee
{
public void getAmount(int clgfee)
{
int hostelfee=5000;
System.out.println("fee payed by hostler:"+(clgfee+hostelfee));
}
public void getFirstname(String fname)
{
System.out.println("first name of the student:"+fname);
}
public void getLastname(String lname)
{
System.out.println("last name of the student:"+lname);
}
public void getAddress(String address)
{
System.out.println("Address of the student:"+address);
}
public void getContact(double contact)
{
System.out.println("contact number of the student:"+contact);
}
}
class NonHostler implements Studentfee
{public void getAmount(int clgfee)
{
System.out.println("fee payed by nonhostler:"+(clgfee));
}
public void getFirstname(String fname)
{
System.out.println("first name of the student:"+fname);
}
public void getLastname(String lname)
{
System.out.println("last name of the student:"+lname);
}
public void getAddress(String address)
{
System.out.println("Address of the student:"+address);
}
public void getContact(double contact)
{
System.out.println("contact number of the student:"+contact);
}
}
class Main
{
public static void main(String args[])
{
Studentfee h= new Hostler();
h.getAmount(23000);
h.getFirstname("Mounika");
h.getLastname("Erra");
h.getAddress("Bhimaram,Mancherial,Telangana");
h.getContact(504204);
System.out.println("\n");
Studentfee h1= new NonHostler();
h1.getAmount(20000);
h1.getFirstname("Hyma");
h1.getLastname("Nilagiri");
h1.getAddress("Anakapal");
h1.getContact(4578);
}
}




