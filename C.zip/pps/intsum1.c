//sum od digits
#include<stdio.h>
int main()
{
int n,s=0,r;
printf("enter n");
scanf("%d",&n);
do
{
r=n%10;
s=s+r;
n=n/10;
}
while(n>0);
printf("s=%d",s);
}
